<!DOCTYPE html>
<html lang="ru">
<head>
  <?php
    $website_title = 'ИС.ГлавнаяСтраница';
    require 'blocks/head.php';
  ?>
</head>
<body class="bg-light text-start">
  <?php
  if($_COOKIE['СотрудникID'] == '') {
    header("Location: auth.php");
  }
  if($_COOKIE['Должность'] == "Администратор") {
    $num = 3;
  }
  else {
    $num = 4;
  }
  ?>
  <header class="container d-flex flex-column flex-md-row align-items-center p-3 px-md-6 mb-3 bg-body border-bottom shadow-sm">
    <div class="mt-1 mb-1 my-0 me-md-auto fw-normal text-start">Добро пожаловать, <?=$_COOKIE['Имя']?> <?=$_COOKIE['Фамилия']?>!</div>
    <div class="my-2 my-md-0 me-md-3 text-end">Ваша должность: <?=$_COOKIE['Должность']?></div>
    <button class="btn btn-outline-primary" id="exit_btn">Выйти</button>
  </header>
  <main class="container bg-white shadow-sm">
  <div class="row">
    <div class="col-md-<?=$num?> mt-1">
      <h4 class="mb-5 mt-3"><b>Формы</b></h4>
      <p><a href="/forms/clients.php">Клиенты</a></p>
      <p><a href="/forms/cars.php">Автомобили</a></p>
      <p><a href="/forms/reprequests.php">Заявки на ремонт</a></p>
      <?php if ($_COOKIE['Должность'] == "Администратор"): ?>
      <p><a href="/forms/employees.php">Сотрудники сервиса</a></p>
      <?php endif; ?>
      <p><a href="/forms/buyreqs.php">Заявки на покупку запчастей</a></p>
      <p><a href="/forms/check.php">Склад</a></p>
      <p>Прайс лист работ</p>
      <p>Расходы/доходы</p>
    </div>
    <div class="col-md-<?=$num?> mt-1">
      <h4 class="mb-5 mt-3"><b>Отчеты</b></h4>
      <p>Клиенты</p>
      <p>Автомобили</p>
      <p>Ремонты</p>
      <p>Покупки</p>
    </div>
  </div>
</main>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script>
    $('#exit_btn').click(function () {
      $.ajax({
        url: 'ajax/exit.php',
        type: 'POST',
        cache: false,
        data: {},
        dataType: 'html',
        success: function (data) {
          document.location.reload(true);
        }
      });
    });
  </script>
</body>
</html>
