<?php
  setcookie('Должность', $user->Должность, time() - 3600 * 24, "/");
  setcookie('СотрудникID', $user->СотрудникID, time() - 3600 * 24, "/");
  setcookie('Имя', $user->Имя, time() - 3600 * 24, "/");
  setcookie('Фамилия', $user->Фамилия, time() - 3600 * 24, "/");
  echo true;
?>
