<?php
  require_once '../../mysql_connect.php';
  $new_work = $_POST['new_work'];

  if (strlen($new_work) != 0) {
    require_once '../../mysql_connect.php';
    $sql = 'INSERT INTO `работы_по_ремонту_temp` ( `РаботаID` ) VALUES( :new_work )';
    $query = $pdo->prepare($sql);
    $query->execute(['new_work' => $new_work]);

  }

  $sql = 'SELECT * FROM `работы_по_ремонту_temp`
          INNER JOIN прайс_лист_работ ON работы_по_ремонту_temp.РаботаID = прайс_лист_работ.РаботаID';
  $query = $pdo->prepare($sql);
  $query->execute();
  $users = $query->fetchALL(PDO::FETCH_ASSOC);
  if (count($users) == 0) {
    echo "Здесь будут отображаться выбранные работы";
  }
  else {
    foreach ($users as $user) {
      echo $user['Название'] . '</br>';
    }
  }
?>
