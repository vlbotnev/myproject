<?php
date_default_timezone_set("Europe/Moscow");
$today = date("Y-m-d H:i:s");
$descfull = $_POST['descfull'];
$descsm = $_POST['descsm'];
$masterID = $_POST['masterID'];
$carID = $_COOKIE['АвтомобильID'];
$managerID = $_COOKIE['СотрудникID'];

$statusID = 1;
$vis = "1";

if (strlen($descsm) == 0) {
  echo "Введите краткое описание";
  exit();
}
if (strlen($descfull) == 0) {
  echo "Введите полное описание";
  exit();
}
if (strlen($masterID) == 0) {
  echo "Выберите мастера";
  exit();
}
else {
  require_once '../../mysql_connect.php';
  $sql = 'INSERT INTO `запрос_на_ремонт` ( `АвтомобильID`, `Описание_Полн`, `Описание_Крктк`, `СотрудникID_Мастер`, `СотрудникID_Менеджер`, `СтатусID`, `Дата`, `Видимость`)
          VALUES( :carID, :descfull, :descsm, :masterID, :managerID, :statusID, :today, :vis )';
  $query = $pdo->prepare($sql);
  $query->execute(['carID' => $carID, 'descfull' => $descfull, 'descsm' => $descsm, 'masterID' => $masterID, 'managerID' => $managerID, 'today' => $today, 'statusID' => $statusID, 'vis' => $vis]);

  $sql = 'SELECT `Запрос_На_РемонтID` FROM `запрос_на_ремонт` ORDER BY `запрос_на_ремонт`.`Дата` DESC';
  $query = $pdo->prepare($sql);
  $query->execute();
  $users = $query->fetch(PDO::FETCH_ASSOC);
  $repreqID = $users['Запрос_На_РемонтID'];

  $sql = 'SELECT * FROM `работы_по_ремонту_temp`';
  $query = $pdo->prepare($sql);
  $query->execute();
  $users = $query->fetchALL(PDO::FETCH_ASSOC);

  foreach ($users as $user) {
      $sql = 'INSERT INTO `работы_по_ремонту` ( `Запрос_На_РемонтID`, `РаботаID` ) VALUES (:repreqID, :workid)';
      $query = $pdo->prepare($sql);
      $query->execute(['repreqID' => $repreqID, 'workid' => $user['РаботаID']]);
  }

  $sql = 'SELECT * FROM `запчасти_для_ремонта_temp`';
  $query = $pdo->prepare($sql);
  $query->execute();

  $users = $query->fetchALL(PDO::FETCH_ASSOC);



  foreach ($users as $user) {
      $sql = 'INSERT INTO `запчасти_для_ремонта` ( `Запрос_На_РемонтID`, `ЗапчастьID`, `Количество_Для_Ремонта`) VALUES (:repreqID, :pieceID, :amount)';
      $query = $pdo->prepare($sql);
      $query->execute(['repreqID' => $repreqID, 'pieceID' => $user['ЗапчастьID'], 'amount' => $user['Количество_temp'] ]);
  }

  $sql = 'TRUNCATE TABLE `работы_по_ремонту_temp`';
  $query = $pdo->prepare($sql);
  $query->execute();

  $sql = 'TRUNCATE TABLE `запчасти_для_ремонта_temp`';
  $query = $pdo->prepare($sql);
  $query->execute();


  echo "Все готово";
}




?>
