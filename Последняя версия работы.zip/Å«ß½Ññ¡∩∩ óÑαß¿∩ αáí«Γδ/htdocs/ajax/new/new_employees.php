<?php
date_default_timezone_set("Europe/Moscow");
$checksurname = trim($_POST['checksurname']);
$checkname = trim($_POST['checkname']);
$checkfname = trim($_POST['checkfname']);
$checkphone = trim($_POST['checkphone']);
$checklogin = trim($_POST['checklogin']);
$checkpassword = trim($_POST['checkpassword']);
$checkpassser = trim($_POST['checkpassser']);
$checkpassnum = trim($_POST['checkpassnum']);
$today = date("Y-m-d H:i:s");
$vis = 1;

$checkdol = $_POST['checkdol'];

require '../../mysql_connect.php';

try {
  $sql = 'SELECT `login` FROM `сотрудники` WHERE `Видимость` = :vis';
  $query = $pdo->prepare($sql);
  $query->execute(['vis' => $vis]);
  $logins = $query->fetchALL(PDO::FETCH_ASSOC);
}
catch(PDOException $e){
      $return = "Your fail message: " . $e->getMessage();
      echo $return;
      exit();
}
foreach ($logins as $row) {
  if ($row['login'] == $checklogin) {
    echo "Пользователь с таким логином уже существует";
    exit();
  }
}

if (strlen($checksurname) == 0) {
  echo "Введите фамилию сотрудника";
  exit();
}
else if(strlen($checkname) == 0) {
  echo "Введите имя сотрудника";
  exit();
}
else if (strlen($checkfname) == 0) {
  echo "Введите отчество сотрудника";
  exit();
}
else if (strlen($checkphone) != 12 ) {
  echo "Телефон введен некорректно";
  exit();
}
else if ($checkdol == "0" ) {
  echo "Введите должность сотрудника";
  exit();
}
else if (strlen($checklogin)  == 0) {
  echo "Введите логин сотрудника";
  exit();
}
else if (strlen($checkpassword)  == 0) {
  echo "Введите пароль сотрудника";
  exit();
}
else if (strlen($checkpassser)  != 4) {
  echo "Серия паспорта введена некорректно";
  exit();
}
else if (strlen($checkpassnum)  != 6) {
  echo "Номер паспорта введена некорректно";
  exit();
}
else {
  try {
  $sql = 'INSERT INTO `сотрудники` ( `login`, `password`, `Сотрудники_Фамилия`, `Имя`, `Отчество`, `Телефон`, `Серия_Паспорта`, `Номер_Паспорта`, `Должность`, `Видимость`, `Дата`)
          VALUES(:checklogin, :checkpassword, :checksurname, :checkname, :checkfname, :checkphone, :checkpassser, :checkpassnum, :checkdol, :vis, :today)';
  $query = $pdo->prepare($sql);
  $query->execute(['checklogin' => $checklogin, 'checkpassword' => $checkpassword, 'checksurname' => $checksurname, 'checkname' => $checkname, 'checkfname' => $checkfname, 'checkphone' => $checkphone,
                  'checkpassser' => $checkpassser, 'checkpassnum' => $checkpassnum, 'checkdol' => $checkdol, 'vis' => $vis, 'today' => $today]);
  }
  catch(PDOException $e){
        $return = "Your fail message: " . $e->getMessage();
        echo $return;
        exit();
  }
  echo "Все готово";
}
?>
