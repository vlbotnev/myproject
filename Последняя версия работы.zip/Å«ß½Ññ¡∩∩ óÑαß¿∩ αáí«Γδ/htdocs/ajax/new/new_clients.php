<?php
date_default_timezone_set("Europe/Moscow");
$name = trim($_POST['name']);
$surname = trim($_POST['surname']);
$fname = trim($_POST['fname']);
$phone = trim($_POST['phone']);
$today = date("Y-m-d H:i:s");
$vis = 1;

if (strlen($surname) == 0) {
  echo "Введите фамилию клиента";
  exit();
}
else if(strlen($name) == 0) {
  echo "Введите имя клиента";
  exit();
}
 if (strlen($fname) == 0) {
  echo "Введите отчество клиента";
  exit();
}
else if (strlen($phone) == 0) {
  echo "Введите телефон клиента";
  exit();
}
else {
  require_once '../../mysql_connect.php';
  $sql = 'INSERT INTO `клиенты` ( `Имя`, `Фамилия`, `Отчество`, `Телефон`, `Видимость`, `Дата`) VALUES(:name, :surname, :fname, :phone, :vis, :today)';
  $query = $pdo->prepare($sql);
  $query->execute(['name' => $name, 'surname' => $surname, 'fname' => $fname, 'phone' => $phone, 'vis' => $vis, 'today' => $today]);
  echo "Все готово";
}
?>
