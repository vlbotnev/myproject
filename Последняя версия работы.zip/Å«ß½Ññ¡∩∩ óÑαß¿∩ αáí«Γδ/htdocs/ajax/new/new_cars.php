<?php
date_default_timezone_set("Europe/Moscow");
$plate = trim($_POST['checkplate']);
$VIN = trim($_POST['checkVIN']);
$surname = trim($_POST['checksurname']);
$year = trim($_POST['checkyear']);
$date1 = trim($_POST['checkdate']);
$name = trim($_POST['checkname']);
$brand = trim($_POST['checkbrand']);
$model = trim($_POST['checkmodel']);
$fname = trim($_POST['checkfname']);
$CTCser = trim($_POST['checkCTCser']);
$CTCnum = trim($_POST['checkCTCnum']);
$phone = trim($_POST['checkphone']);
$carID = trim($_POST['checkcarID']);
$clientID = trim($_POST['checkclientID']);
$today = date("Y-m-d H:i:s");
$vis = 1;

$clientID = $_COOKIE['КлиентID'];

require_once '../../mysql_connect.php';

if (strlen($clientID) == 0) {
  echo "Оставьте в таблице только одного клиента к которому вы хотите добавить автомобиль";
}
else if (strlen($VIN) == 0) {
  echo "Введите VIN автомобиля";
}
else if (strlen($year) == 0) {
  echo "Введите год выпуска автомобиля";
}
else if (strlen($brand) == 0) {
  echo "Введите марку автомобиля";
}
else if (strlen($model) == 0) {
  echo "Введите модель автомобиля";
}
else if (strlen($CTCser) == 0) {
  echo "Введите серию СТС автомобиля";
}
else if (strlen($CTCnum) == 0) {
  echo "Введите номер СТС автомобиля";
}
else if (strlen($CTCser) != 4) {
  echo "Серия СТС должена состоять из 4 чисел";
}
else if (strlen($CTCnum) != 6) {
  echo "Номер СТС должен состоять из 6 чисел";
}
else if (strlen($VIN) != 17) {
  echo "VIN должен содержать 17 знаков";
}
else if (strlen($year) != 4) {
  echo "Год указан неправильно";
}

else {
  $sql = 'INSERT INTO `машины` ( `КлиентID`, `VIN`, `НомерТС`, `Марка`, `Модель`, `Год_Выпуска`, `Серия_СТС`, `Номер_СТС`, `Дата`, `Видимость`)
  VALUES(:clientID, :checkVIN, :plate, :brand, :model, :year, :CTCser, :CTCnum, :today, :vis)';
  $query = $pdo->prepare($sql);
  $query->execute(['clientID' => $clientID, 'checkVIN' => $VIN, 'plate' => $plate, 'brand' => $brand, 'model' => $model, 'year' => $year,
  'CTCser' => $CTCser, 'CTCnum' => $CTCnum, 'today' => $today, 'vis' => $vis]);

  setcookie('АвтомобильID', $user['АвтомобильID'], time() - 3600 * 24, "/");

  echo "Все готово";
}
?>
