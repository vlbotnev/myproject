<?php

$carID = $_COOKIE['АвтомобильID'];

if($_COOKIE['АвтомобильID'] == '') {
  echo "Отфильтруйте таблицу так чтобы в ней остался только один автомобиль";
}
else {
  require_once '../../mysql_connect.php';

  $vis = 0;

  $sql = 'UPDATE `машины` SET `Видимость` = :vis WHERE `АвтомобильID` = :carID';
  $query = $pdo->prepare($sql);
  $query->execute(['vis' => $vis, 'carID' => $carID]);

  echo "Все готово";
}
?>
