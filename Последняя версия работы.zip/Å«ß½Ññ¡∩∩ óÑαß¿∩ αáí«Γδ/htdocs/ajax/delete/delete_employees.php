<?php

$id = $_COOKIE['СотрудникID_check'];

if($_COOKIE['СотрудникID_check'] == '') {
  echo "Отфильтруйте таблицу так чтобы в ней остался только один сотрудник";
}
else {
  require_once '../../mysql_connect.php';

  $vis = 0;
  try {

  $sql = 'UPDATE `сотрудники` SET `Видимость` = :vis WHERE `СотрудникID` = :id';
  $query = $pdo->prepare($sql);
  $query->execute(['vis' => $vis, 'id' => $id]);
}
  catch(PDOException $e){
        $return = "Your fail message: " . $e->getMessage();
        echo $return;
        exit();
  }
  echo "Все готово";
}
?>
