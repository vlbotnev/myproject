<?php

$id = $_COOKIE['Запрос_На_РемонтID'];

if($_COOKIE['Запрос_На_РемонтID'] == '') {
  echo "Отфильтруйте таблицу так чтобы в ней остался только один заказ";
}
else {
  require_once '../../mysql_connect.php';

  $vis = 0;
  try {

  $sql = 'UPDATE `запрос_на_ремонт` SET `Видимость` = :vis WHERE `Запрос_На_РемонтID` = :id';
  $query = $pdo->prepare($sql);
  $query->execute(['vis' => $vis, 'id' => $id]);
}
  catch(PDOException $e){
        $return = "Your fail message: " . $e->getMessage();
        echo $return;
        exit();
  }
  echo "Все готово";
}
?>
