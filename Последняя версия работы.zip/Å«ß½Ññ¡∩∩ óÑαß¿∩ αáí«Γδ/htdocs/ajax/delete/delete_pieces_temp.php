<?php
require_once '../../mysql_connect.php';
$sql = 'TRUNCATE TABLE `запчасти_для_ремонта_temp`';
$query = $pdo->prepare($sql);
$query->execute();
?>
