<?php
require '../../mysql_connect.php';
$sql = 'TRUNCATE TABLE `работы_по_ремонту_temp`';
$query = $pdo->prepare($sql);
$query->execute();
?>
