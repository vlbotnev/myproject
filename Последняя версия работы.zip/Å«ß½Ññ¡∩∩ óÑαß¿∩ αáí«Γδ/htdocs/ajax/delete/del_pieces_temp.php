<?php
  $del_piece = $_POST['del_piece'];
  $amount = $_POST['amount'];

  require_once '../../mysql_connect.php';
  $sql = 'DELETE FROM `запчасти_для_ремонта_temp` WHERE `запчасти_для_ремонта_temp`.`ЗапчастьID` = :del_piece && `запчасти_для_ремонта_temp`.`Количество_temp` = :amount' ;
  $query = $pdo->prepare($sql);
  $query->execute(['del_piece' => $del_piece, 'amount' => $amount]);

  $sql = 'SELECT * FROM `запчасти_для_ремонта_temp`
          INNER JOIN склад ON запчасти_для_ремонта_temp.ЗапчастьID = склад.ЗапчастьID';
  $query = $pdo->prepare($sql);
  $query->execute();
  $users = $query->fetchALL(PDO::FETCH_ASSOC);
  if (count($users) == 0) {
    echo "Здесь будут отображаться выбранные запчасти";
  }
  else {
    foreach ($users as $user) {
      echo "Название: " . $user['Название'] . " " . "Кол-во: " . $user['Количество_temp'] . '</br>';
    }
  }

?>
