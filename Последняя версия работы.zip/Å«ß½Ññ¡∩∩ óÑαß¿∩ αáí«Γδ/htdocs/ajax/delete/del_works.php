<?php
  $del_work = $_POST['del_work'];

  $id = $_COOKIE['Запрос_На_РемонтID'];

  require_once '../../mysql_connect.php';
  $sql = 'DELETE FROM `работы_по_ремонту` WHERE `работы_по_ремонту`.`РаботаID` = :del_work && `работы_по_ремонту`.`Запрос_На_РемонтID` = :id';
  $query = $pdo->prepare($sql);
  $query->execute(['del_work' => $del_work, 'id' => $id]);

  $sql = 'SELECT * FROM `работы_по_ремонту`
          INNER JOIN прайс_лист_работ ON работы_по_ремонту.РаботаID = прайс_лист_работ.РаботаID
          WHERE работы_по_ремонту.Запрос_На_РемонтID = :id';
  $query = $pdo->prepare($sql);
  $query->execute(['id' => $id]);
  $users = $query->fetchALL(PDO::FETCH_ASSOC);
  if (count($users) == 0) {
    echo "Здесь будут отображаться выбранные работы";
  }
  else {
    foreach ($users as $user) {
      echo "Название: " . $user['Название'] . '</br>';
    }
  }

?>
