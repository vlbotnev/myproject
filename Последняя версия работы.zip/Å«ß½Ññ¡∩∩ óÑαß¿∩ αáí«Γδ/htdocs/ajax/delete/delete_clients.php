<?php

$clientID = $_COOKIE['КлиентID'];

if($_COOKIE['КлиентID'] == '') {
  echo "Отфильтруйте таблицу так чтобы в ней остался только один клиент";
}
else {
  require_once '../../mysql_connect.php';

  $vis = 0;

  $sql = 'UPDATE `клиенты` SET `Видимость` = :vis WHERE `КлиентID` = :clientID';
  $query = $pdo->prepare($sql);
  $query->execute(['vis' => $vis, 'clientID' => $clientID]);

  echo "Все готово";
}
?>
