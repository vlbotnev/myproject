<?php
  $checksurname = trim($_POST['checksurname']);
  $checkname = trim($_POST['checkname']);
  $checkfname = trim($_POST['checkfname']);
  $checkphone = trim($_POST['checkphone']);
  $checklogin = trim($_POST['checklogin']);
  $checkpassword = trim($_POST['checkpassword']);
  $checkpassser = trim($_POST['checkpassser']);
  $checkpassnum = trim($_POST['checkpassnum']);
  $employeeID = trim($_POST['employeeID']);
  $checkdate = $_POST['checkdate'];

  $checksurname = "%$checksurname%";
  $checkname = "%$checkname%";
  $checkfname = "%$checkfname%";
  $checkphone = "%$checkphone%";
  $checklogin = "%$checklogin%";
  $checkpassword = "%$checkpassword%";
  $checkpassser = "%$checkpassser%";
  $checkpassnum = "%$checkpassnum%";
  $employeeID = "%$employeeID%";
  $checkdate = "%$checkdate%";

  $vis = 1;

  $checkdol = trim($_POST['checkdol']);
  if ($checkdol == "0") {
    $checkdol = "%%";
  }

  require '../../mysql_connect.php';

  $sql = 'SELECT * FROM `сотрудники` WHERE
          `СотрудникID` LIKE :employeeID &&
          `login` LIKE :checklogin &&
          `password` LIKE :checkpassword &&
          `Сотрудники_Фамилия` LIKE :checksurname &&
          `Имя` LIKE :checkname &&
          `Отчество` LIKE :checkfname &&
          `Телефон` LIKE :checkphone &&
          `Серия_Паспорта` LIKE :checkpassser &&
          `Номер_Паспорта` LIKE :checkpassnum &&
          `Должность` LIKE :checkdol &&
          `Дата` LIKE :checkdate &&
          `Видимость` LIKE :vis
          ORDER BY `сотрудники`.`СотрудникID` DESC';
  $query = $pdo->prepare($sql);
  $query->execute(['employeeID' => $employeeID, 'checklogin' => $checklogin, 'checkpassword' => $checkpassword, 'checksurname' => $checksurname, 'checkname' => $checkname, 'checkfname' => $checkfname,
  'checkphone' => $checkphone, 'checkpassser' => $checkpassser, 'checkpassnum' => $checkpassnum, 'checkdol' => $checkdol, 'checkdate' => $checkdate, 'vis' => $vis]);
  $users = $query->fetchALL(PDO::FETCH_ASSOC);
  $scrollspy = "";
  setcookie('СотрудникID_check', $user['СотрудникID'], time() - 3600 * 24, "/");
  if(count($users) > 1) {
    $scrollspy = "scrollspy";
  }
  if (count($users) == 0) {
    echo '<div class="' . $scrollspy . '">
          <table class="text-center table table-striped " >
            <thead>
              <tr class="align-top">
              <th>#</th>
              <th>Фамилия</th>
              <th>Имя</th>
              <th>Отчество</th>
              <th>Телефон</th>
              <th>login</th>
              <th>password</th>
              <th>Серия паспорта</th>
              <th>Номер паспорта</th>
              <th>Должность</th>
              </tr>
            </thead>
            <tbody>';
            echo '</tbody></table></div>';
    echo "Сотрудник не найден";

  }
  else {

    echo '<div class="' . $scrollspy . '">
          <table class="text-center table table-striped " >
            <thead>
            <tr class="align-top">
            <th>#</th>
            <th>Фамилия</th>
            <th>Имя</th>
            <th>Отчество</th>
            <th>Телефон</th>
            <th>login</th>
            <th>password</th>
            <th>Серия паспорта</th>
            <th>Номер паспорта</th>
            <th>Должность</th>
            </tr>
            </thead>
            <tbody>';
    foreach ($users as $user) {
      if(count($users) == 1) {
        setcookie('СотрудникID_check', $user['СотрудникID'], time() + 3600 * 24, "/");
      }
      echo '<tr>
      <td>' . $user['СотрудникID'] . '</td>
              <td>' . $user['Сотрудники_Фамилия'] . '</td>
              <td>' . $user['Имя'] . '</td>
              <td>' . $user['Отчество'] . '</td>
              <td>' . $user['Телефон'] . '</td>
              <td>' . $user['login'] . '</td>
              <td>' . $user['password'] . '</td>
              <td>' . $user['Серия_Паспорта'] . '</td>
              <td>' . $user['Номер_Паспорта'] . '</td>
              <td>' . $user['Должность'] . '</td>
            </tr>';
    }
    echo '</tbody></table></div>';
  }
?>
