<?php
  $name = trim($_POST['name']);
  $surname = trim($_POST['surname']);
  $fname = trim($_POST['fname']);
  $phone = trim($_POST['phone']);
  $clientID = trim($_POST['clientID']);
  $plate = trim($_POST['plate']);
  $brand = trim($_POST['brand']);
  $model = trim($_POST['model']);
  $year = trim($_POST['year']);
  $carID = trim($_POST['carID']);
  $repreqID = trim($_POST['repreqID']);
  $checkdate = $_POST['checkdate'];
  $checkmaster = $_POST['checkmaster'];
  $checkmanager = $_POST['checkmanager'];
  $checkstatus = $_POST['checkstatus'];

  $name = "%$name%";
  $surname = "%$surname%";
  $fname = "%$fname%";
  $phone = "%$phone%";
  $clientID = "%$clientID%";
  $plate = "%$plate%";
  $brand = "%$brand%";
  $model = "%$model%";
  $year = "%$year%";
  $carID = "%$carID%";
  $repreqID = "%$repreqID%";
  $checkdate = "%$checkdate%";
  $checkmaster = "%$checkmaster%";
  $checkmanager = "%$checkmanager%";
  $checkstatus = "%$checkstatus%";

  require_once '../../mysql_connect.php';



  $vis = 1;
  try{
    if (strlen($repreqID) == 2 && strlen($checkdate) == 2 && strlen($checkmaster) == 2 && strlen($checkmanager) == 2 && strlen($checkstatus) == 2 ) {
    $sql = 'SELECT DISTINCT
              машины.КлиентID,
              машины.НомерТС,
              машины.Марка,
              машины.Модель,
              машины.АвтомобильID,
              машины.VIN,
              машины.НомерТС,
              машины.Год_Выпуска,
              машины.Серия_СТС,
              машины.Номер_СТС,
              машины.Дата
            FROM клиенты
            INNER JOIN машины ON машины.КлиентID = клиенты.КлиентID
            WHERE клиенты.Фамилия LIKE :surname &&
              клиенты.имя LIKE :name &&
              клиенты.телефон LIKE :phone &&
              клиенты.КлиентID LIKE :clientID &&
              машины.КлиентID LIKE :clientID &&
              машины.НомерТС LIKE :plate &&
              машины.Марка LIKE :brand &&
              машины.Модель LIKE :model &&
              машины.АвтомобильID LIKE :carID &&
              машины.Видимость = :vis
            ORDER BY `машины`.`АвтомобильID` DESC';
            $query = $pdo->prepare($sql);
            $query->execute(['phone' => $phone, 'name' => $name, 'surname' => $surname, 'clientID' => $clientID, 'plate' => $plate, 'brand' => $brand, 'model' => $model, 'carID' => $carID, 'vis' => $vis ]);
    }
    else {
      $sql = 'SELECT DISTINCT
                машины.КлиентID,
                машины.НомерТС,
                машины.Марка,
                машины.Модель,
                машины.АвтомобильID,
                машины.VIN,
                машины.НомерТС,
                машины.Год_Выпуска,
                машины.Серия_СТС,
                машины.Номер_СТС,
                машины.Дата
              FROM клиенты
              INNER JOIN машины ON машины.КлиентID = клиенты.КлиентID
              INNER JOIN запрос_на_ремонт ON машины.АвтомобильID = запрос_на_ремонт.АвтомобильID
              INNER JOIN сотрудники AS ma ON ma.СотрудникID = запрос_на_ремонт.СотрудникID_Мастер
              INNER JOIN сотрудники AS me ON me.СотрудникID = запрос_на_ремонт.СотрудникID_Менеджер
              INNER JOIN статус ON запрос_на_ремонт.СтатусID = статус.СтатусID
              WHERE клиенты.Фамилия LIKE :surname &&
                клиенты.имя LIKE :name &&
                клиенты.телефон LIKE :phone &&
                клиенты.КлиентID LIKE :clientID &&
                машины.КлиентID LIKE :clientID &&
                машины.НомерТС LIKE :plate &&
                машины.Марка LIKE :brand &&
                машины.Модель LIKE :model &&
                машины.АвтомобильID LIKE :carID &&
                машины.Видимость = :vis &&
                запрос_на_ремонт.Дата LIKE :checkdate &&
                ma.СотрудникID LIKE :checkmaster &&
                me.СотрудникID LIKE :checkmanager &&
                статус.СтатусID LIKE :checkstatus &&
                запрос_на_ремонт.Запрос_На_РемонтID LIKE :repreqID
              ORDER BY `машины`.`АвтомобильID` DESC';
              $query = $pdo->prepare($sql);
              $query->execute(['phone' => $phone, 'name' => $name, 'surname' => $surname, 'clientID' => $clientID, 'plate' => $plate, 'brand' => $brand, 'model' => $model, 'carID' => $carID, 'vis' => $vis,
              'repreqID' => $repreqID, 'checkdate' => $checkdate, 'checkmaster' => $checkmaster, 'checkmanager' => $checkmanager, 'checkstatus' => $checkstatus]);
    }
    $users = $query->fetchALL(PDO::FETCH_ASSOC);
  }
    catch(PDOException $e){
          $return = "Your fail message: " . $e->getMessage();
          echo $return;
          exit();
    }
  setcookie('АвтомобильID', null, 1, "/");
  setcookie('carКлиентID', null, 1, "/");
  $scrollspy = "";
  if(count($users) > 1) {
    $scrollspy = "scrollspy";
  }
  if (count($users) == 0) {
    echo '<div class="' . $scrollspy . '">
          <table class="text-center table table-striped " >
            <thead>
              <tr>
              <th>КлиентID</th>
              <th>АвтоID</th>
              <th>VIN</th>
              <th>НомерТС</th>
              <th>Марка</th>
              <th>Модель</th>
              <th>Год выпуска</th>
              <th>Серия СТС</th>
              <th>Номер СТС</th>
              </tr>
            </thead>
            <tbody>';
    echo '</tbody></table></div>';
    echo 'Автомобиль не найден';
  }
  else {
    echo '<div class="' . $scrollspy . '">
          <table class="text-center table table-striped " >
            <thead>
              <tr>
              <th>КлиентID</th>
              <th>АвтоID</th>
              <th>VIN</th>
              <th>НомерТС</th>
              <th>Марка</th>
              <th>Модель</th>
              <th>Год выпуска</th>
              <th>Серия СТС</th>
              <th>Номер СТС</th>
              </tr>
            </thead>
            <tbody>';
    foreach ($users as $user) {
      if (count($users) == 1) {
        setcookie('АвтомобильID', $user['АвтомобильID'], time() + 3600 * 24, "/");
        setcookie('carКлиентID', $user['КлиентID'], time() + 3600 * 24, "/");
      }
      echo '<tr>
              <td>' . $user['КлиентID'] . '</td>
              <td>' . $user['АвтомобильID'] . '</td>
              <td>' . $user['VIN'] . '</td>
              <td>' . $user['НомерТС'] . '</td>
              <td>' . $user['Марка'] . '</td>
              <td>' . $user['Модель'] . '</td>
              <td>' . $user['Год_Выпуска'] . '</td>
              <td>' . $user['Серия_СТС'] . '</td>
              <td>' . $user['Номер_СТС'] . '</td>
            </tr>';
      }
      echo '</tbody></table></div>';
    }

?>
