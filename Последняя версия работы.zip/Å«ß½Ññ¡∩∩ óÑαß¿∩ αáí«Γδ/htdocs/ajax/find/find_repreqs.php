<?php
  $name = trim($_POST['name']);
  $surname = trim($_POST['surname']);
  $fname = trim($_POST['fname']);
  $phone = trim($_POST['phone']);
  $clientID = trim($_POST['clientID']);
  $plate = trim($_POST['plate']);
  $brand = trim($_POST['brand']);
  $model = trim($_POST['model']);
  $year = trim($_POST['year']);
  $carID = trim($_POST['carID']);
  $repreqID = trim($_POST['repreqID']);
  $checkdate = $_POST['checkdate'];
  $checkmaster = $_POST['checkmaster'];
  $checkmanager = $_POST['checkmanager'];
  $checkstatus = $_POST['checkstatus'];

  if (strlen($carID) == 0) {
    $carID = $_COOKIE['АвтомобильID'];
  }

  $name = "%$name%";
  $surname = "%$surname%";
  $fname = "%$fname%";
  $phone = "%$phone%";
  $clientID = "%$clientID%";
  $plate = "%$plate%";
  $brand = "%$brand%";
  $model = "%$model%";
  $year = "%$year%";
  $carID = "%$carID%";
  $repreqID = "%$repreqID%";
  $checkdate = "%$checkdate%";
  $checkmaster = "%$checkmaster%";
  $checkmanager = "%$checkmanager%";
  $checkstatus = "%$checkstatus%";

  require_once '../../mysql_connect.php';

  $vis = 1;
  try{
    $sql = 'SELECT
              запрос_на_ремонт.Дата,
              запрос_на_ремонт.Запрос_На_РемонтID,
              запрос_на_ремонт.АвтомобильID,
              статус.Название,
              запрос_на_ремонт.Описание_Крктк,
              ma.Сотрудники_Фамилия,
              me.Сотрудники_Фамилия AS Менеджер
            FROM клиенты
            INNER JOIN машины ON машины.КлиентID = клиенты.КлиентID
            INNER JOIN запрос_на_ремонт ON машины.АвтомобильID = запрос_на_ремонт.АвтомобильID
            INNER JOIN сотрудники AS ma ON ma.СотрудникID = запрос_на_ремонт.СотрудникID_Мастер
            INNER JOIN сотрудники AS me ON me.СотрудникID = запрос_на_ремонт.СотрудникID_Менеджер
            INNER JOIN статус ON запрос_на_ремонт.СтатусID = статус.СтатусID
            WHERE
              клиенты.Фамилия LIKE :surname &&
              клиенты.имя LIKE :name &&
              клиенты.телефон LIKE :phone &&
              клиенты.КлиентID LIKE :clientID &&
              машины.НомерТС LIKE :plate &&
              машины.Марка LIKE :brand &&
              машины.Модель LIKE :model &&
              машины.АвтомобильID LIKE :carID &&
              машины.Видимость = :vis &&
              запрос_на_ремонт.Запрос_На_РемонтID LIKE :repreqID &&
              запрос_на_ремонт.Дата LIKE :checkdate &&
              ma.СотрудникID LIKE :checkmaster &&
              me.СотрудникID LIKE :checkmanager &&
              статус.СтатусID LIKE :checkstatus
            ORDER BY `запрос_на_ремонт`.`Дата` DESC';
    $query = $pdo->prepare($sql);
    $query->execute(['phone' => $phone, 'name' => $name, 'surname' => $surname, 'clientID' => $clientID, 'plate' => $plate, 'brand' => $brand, 'model' => $model, 'carID' => $carID, 'vis' => $vis,
    'repreqID' => $repreqID, 'checkdate' => $checkdate, 'checkmaster' => $checkmaster, 'checkmanager' => $checkmanager, 'checkstatus' => $checkstatus]);
    $users = $query->fetchALL(PDO::FETCH_ASSOC);
    $query = $pdo->prepare($sql);
  }
  catch(PDOException $e){
    $return = "Your fail message: " . $e->getMessage();
    echo $return;
    exit();
  }
  $scrollspy = "";
  setcookie('Запрос_На_РемонтID', null, 1, "/");
  if(count($users) > 1) {
    $scrollspy = "scrollspy";
  }

  if (count($users) == 0) {
    setcookie('Запрос_На_РемонтID', $user['Запрос_На_РемонтID'], time() - 3600 * 24, "/");
    echo '<div class="' . $scrollspy . '">
          <table class="text-center table table-striped " >
            <thead>
              <tr>
              <th>#</th>
              <th>АвтоID</th>
              <th>Дата</th>
              <th>Стоимость</th>
              <th>Статус</th>
              <th>Описание краткое</th>
              <th>Мастер</th>
              <th>Менеджер</th>
              </tr>
            </thead>
            <tbody>';
    echo '</tbody></table>';
    echo 'Заявка не найдена';
  }
  else {
    echo '<div class="' . $scrollspy . '">
          <table class="text-center table table-striped" >
            <thead>
              <tr>
              <th>#</th>
              <th>АвтоID</th>
              <th>Дата</th>
              <th>Стоимость</th>
              <th>Статус</th>
              <th>Описание краткое</th>
              <th>Мастер</th>
              <th>Менеджер</th>
              </tr>
            </thead>
            <tbody>';
    foreach ($users as $user) {
      try {
      $sql = 'SELECT SUM(`склад`.`Цена_Продажи`) AS pieces FROM запрос_на_ремонт
              INNER JOIN запчасти_для_ремонта ON запчасти_для_ремонта.Запрос_На_РемонтID = запрос_на_ремонт.Запрос_На_РемонтID
              INNER JOIN склад ON склад.ЗапчастьID = запчасти_для_ремонта.ЗапчастьID
              WHERE запрос_на_ремонт.Видимость = 1 && запрос_на_ремонт.Запрос_На_РемонтID = :id';
      $query = $pdo->prepare($sql);
      $query->execute(['id' => $user['Запрос_На_РемонтID']]);
      $pieces = $query->fetch(PDO::FETCH_ASSOC);
      }
      catch(PDOException $e){
            $return = "Your fail message: " . $e->getMessage();
            echo $return;
            exit();
      }
      try {
      $sql = 'SELECT SUM(`прайс_лист_работ`.`Цена продажи`) AS works FROM запрос_на_ремонт
              INNER JOIN работы_по_ремонту ON работы_по_ремонту.Запрос_На_РемонтID = запрос_на_ремонт.Запрос_На_РемонтID
              INNER JOIN прайс_лист_работ ON прайс_лист_работ.РаботаID = работы_по_ремонту.РаботаID
              WHERE запрос_на_ремонт.Видимость = "1" && запрос_на_ремонт.Запрос_На_РемонтID = :id  ';
      $query = $pdo->prepare($sql);
      $query->execute(['id' => $user['Запрос_На_РемонтID']]);
      $works = $query->fetch(PDO::FETCH_ASSOC);
      }
      catch(PDOException $e){
            $return = "Your fail message: " . $e->getMessage();
            echo $return;
            exit();
      }
      if (count($users) == 1) {
        setcookie('Запрос_На_РемонтID', $user['Запрос_На_РемонтID'], time() + 3600 * 24, "/");
      }
        echo '<tr>
                <td>' . $user['Запрос_На_РемонтID'] . '</td>
                <td>' . $user['АвтомобильID'] . '</td>
                <td>' . $user['Дата'] . '</td>
                <td>' . ($works['works'] + $pieces['pieces']) . '</td>
                <td>' . $user['Название'] . '</td>
                <td>' . $user['Описание_Крктк'] . '</td>
                <td>' . $user['Сотрудники_Фамилия'] . '</td>
                <td>' . $user['Менеджер'] . '</td>';
                echo '</tr>';
      }
      echo '</tbody></table></div>';
    }


?>
