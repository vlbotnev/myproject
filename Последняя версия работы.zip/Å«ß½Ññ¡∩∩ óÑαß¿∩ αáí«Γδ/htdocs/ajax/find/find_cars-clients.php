<?php
  $plate = trim($_POST['checkplate']);
  $VIN = trim($_POST['checkvin']);
  $surname = trim($_POST['checksurname']);
  $year = trim($_POST['checkyear']);
  $date1 = trim($_POST['checkdate']);
  $name = trim($_POST['checkname']);
  $brand = trim($_POST['checkbrand']);
  $model = trim($_POST['checkmodel']);
  $fname = trim($_POST['checkfname']);
  $CTCser = trim($_POST['checkCTCser']);
  $CTCnum = trim($_POST['checkCTCnum']);
  $phone = trim($_POST['checkphone']);
  $carID = trim($_POST['checkcarID']);
  $clientID = trim($_POST['checkclientID']);

  $plate = "%$plate%";
  $VIN = "%$VIN%";
  $surname = "%$surname%";
  $year = "%$year%";
  $date1 = "%$date1%";
  $name = "%$name%";
  $brand = "%$brand%";
  $model = "%$model%";
  $fname = "%$fname%";
  $CTCser = "%$CTCser%";
  $CTCnum = "%$CTCnum%";
  $phone = "%$phone%";
  $carID = "%$carID%";
  $clientID = "%$clientID%";

  require_once '../../mysql_connect.php';

  $vis = 1;
  try{
    $sql = 'SELECT * FROM клиенты WHERE
              клиенты.Фамилия LIKE :surname &&
              клиенты.имя LIKE :name &&
              клиенты.отчество LIKE :fname &&
              клиенты.телефон LIKE :phone &&
              клиенты.КлиентID LIKE :clientID &&
              клиенты.Видимость = :vis
            ORDER BY клиенты.КлиентID DESC';
    $query = $pdo->prepare($sql);
    $query->execute(['surname' => $surname, 'name' => $name, 'fname' => $fname, 'phone' => $phone, 'clientID' => $clientID,  'vis' => $vis]);
  }
  catch(PDOException $e){
        $return = "Your fail message: " . $e->getMessage();
        echo $return;
        exit();
  }
  $users = $query->fetchALL(PDO::FETCH_ASSOC);
  $scrollspy = "";
  setcookie('КлиентID', $user['КлиентID'], time() - 3600 * 24, "/");
  if(count($users) > 1) {
    $scrollspy = "scrollspy";
  }
  echo '</div></div></div>';
  echo '<div class="shadow mt">';
  if (count($users) == 0) {
    echo '<div class="'. $scrollspy .'">
          <table class="text-center table table-striped " >
            <thead>
              <tr class="align-top">
              <th>КлиентID</th>
              <th>Фамилия</th>
              <th>Имя</th>
              <th>Отчество</th>
              <th>Телефон</th>
              <th>Дата</th>
              </tr>
            </thead>
            <tbody>';
            echo '</tbody></table></div>';
    echo "Клиент не найден";
  }
  else {
    echo '<div class="'. $scrollspy .'">
          <table class="text-center table table-striped " >
            <thead>
            <tr class="align-top">
            <th>КлиентID</th>
            <th>Фамилия</th>
            <th>Имя</th>
            <th>Отчество</th>
            <th>Телефон</th>
            <th>Дата</th>
            </tr>
            </thead>
            <tbody>';
    foreach ($users as $user) {
      if (count($users) == 1) {
        setcookie('КлиентID', $user['КлиентID'], time() + 3600 * 24, "/");
      }
      echo '<tr>
              <td>' . $user['КлиентID'] . '</td>
              <td>' . $user['Фамилия'] . '</td>
              <td>' . $user['Имя'] . '</td>
              <td>' . $user['Отчество'] . '</td>
              <td>' . $user['Телефон'] . '</td>
              <td>' . $user['Дата'] . '</td>
            </tr>';
    }
    echo '</tbody></table></div>';
  }
?>
