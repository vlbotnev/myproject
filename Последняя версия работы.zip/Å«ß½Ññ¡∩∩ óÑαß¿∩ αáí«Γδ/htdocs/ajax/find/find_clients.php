<?php
$name = trim($_POST['name']);
$surname = trim($_POST['surname']);
$fname = trim($_POST['fname']);
$phone = trim($_POST['phone']);
$clientID = trim($_POST['clientID']);
$date = $_POST['date'];


$name = "%$name%";
$surname = "%$surname%";
$fname = "%$fname%";
$phone = "%$phone%";
$clientID = "%$clientID%";
$date = "%$date%";


$vis = 1;

require_once '../../mysql_connect.php';

$sql = 'SELECT * FROM `клиенты` WHERE
      `Имя` LIKE :name &&
      `Фамилия` LIKE :surname &&
      `Отчество` LIKE :fname &&
      `Телефон` LIKE :phone &&
      `КлиентID` LIKE :clientID &&
      `Дата` LIKE :date1 &&
      `Видимость` = :vis
      ORDER BY `клиенты`.`КлиентID` DESC';
$query = $pdo->prepare($sql);
$query->execute(['name' => $name, 'surname' => $surname, 'fname' => $fname, 'phone' => $phone, 'clientID' => $clientID, 'date1' => $date, 'vis' => $vis]);
$users = $query->fetchALL(PDO::FETCH_ASSOC);
$scrollspy = "";
setcookie('КлиентID', null, 1, "/");
if(count($users) > 1) {
  $scrollspy = "scrollspy";
}
if (count($users) == 0) {
  echo '<div class="' . $scrollspy . '">
        <table class="text-center table table-striped " >
          <thead>
            <tr class="align-top">
            <th>#</th>
            <th>Фамилия</th>
            <th>Имя</th>
            <th>Отчество</th>
            <th>Телефон</th>
            <th>Дата</th>
            </tr>
          </thead>
          <tbody>';
          echo '</tbody></table></div>';
  echo "Сотрудник не найден";

}
else {

  echo '<div class="' . $scrollspy . '">
        <table class="text-center table table-striped " >
          <thead>
            <tr class="align-top">
            <th>#</th>
            <th>Фамилия</th>
            <th>Имя</th>
            <th>Отчество</th>
            <th>Телефон</th>
            <th>Дата</th>
            </tr>
          </thead>
          <tbody>';
  foreach ($users as $user) {
    if(count($users) == 1) {
      setcookie('КлиентID', $user['КлиентID'], time() + 3600 * 24, "/");
    }
    echo '<tr>
            <td>' . $user['КлиентID'] . '</td>
            <td>' . $user['Фамилия'] . '</td>
            <td>' . $user['Имя'] . '</td>
            <td>' . $user['Отчество'] . '</td>
            <td>' . $user['Телефон'] . '</td>
            <td>' . $user['Дата'] . '</td>
          </tr>';
  }
  echo '</tbody></table></div>';
}
?>
