<?php
$plate = trim($_POST['checkplate']);
$VIN = trim($_POST['checkVIN']);
$surname = trim($_POST['checksurname']);
$year = trim($_POST['checkyear']);
$date1 = trim($_POST['checkdate']);
$name = trim($_POST['checkname']);
$brand = trim($_POST['checkbrand']);
$model = trim($_POST['checkmodel']);
$fname = trim($_POST['checkfname']);
$CTCser = trim($_POST['checkCTCser']);
$CTCnum = trim($_POST['checkCTCnum']);
$phone = trim($_POST['checkphone']);
$carID = trim($_POST['checkcarID']);
$clientID = trim($_POST['checkclientID']);

$plate = "%$plate%";
$VIN = "%$VIN%";
$surname = "%$surname%";
$year = "%$year%";
$date1 = "%$date1%";
$name = "%$name%";
$brand = "%$brand%";
$model = "%$model%";
$fname = "%$fname%";
$CTCser = "%$CTCser%";
$CTCnum = "%$CTCnum%";
$phone = "%$phone%";
$carID = "%$carID%";
$clientID = "%$clientID%";

require_once '../../mysql_connect.php';

$vis = 1;
try{
  $sql = 'SELECT * FROM клиенты
          INNER JOIN машины ON машины.КлиентID = клиенты.КлиентID WHERE
            клиенты.Фамилия LIKE :surname &&
            клиенты.имя LIKE :name &&
            клиенты.отчество LIKE :fname &&
            клиенты.телефон LIKE :phone &&
            клиенты.КлиентID LIKE :clientID &&
            машины.НомерТС LIKE :plate &&
            машины.VIN LIKE :VIN &&
            машины.Год_Выпуска LIKE :year &&
            машины.Дата LIKE :date1 &&
            машины.Марка LIKE :brand &&
            машины.Модель LIKE :model &&
            машины.Серия_СТС LIKE :CTCser &&
            машины.Номер_СТС LIKE :CTCnum &&
            машины.АвтомобильID LIKE :carID &&
            машины.Видимость = :vis
          ORDER BY машины.АвтомобильID DESC';
  $query = $pdo->prepare($sql);
  $query->execute(['surname' => $surname, 'name' => $name, 'fname' => $fname, 'phone' => $phone, 'clientID' => $clientID, 'plate' => $plate, 'VIN' => $VIN, 'year' => $year, 'date1' => $date1,
  'brand' => $brand, 'model' => $model, 'CTCser' => $CTCser, 'CTCnum' => $CTCnum, 'carID' => $carID, 'vis' => $vis]);
  }
  catch(PDOException $e){
        $return = "Your fail message: " . $e->getMessage();
        echo $return;
        exit();
  }
  $users = $query->fetchALL(PDO::FETCH_ASSOC);
  $scrollspy = "";
  setcookie('АвтомобильID', null, 1, "/");
  if(count($users) > 1) {
    $scrollspy = "scrollspy";
  }
  if (count($users) == 0) {
    echo '<div class="' . $scrollspy . '">
          <table class="text-center table table-striped " >
            <thead>
              <tr class="align-top">
              <th>АвтоID</th>
              <th>КлиентID</th>
              <th>Дата</th>
              <th>VIN</th>
              <th>НомерТС</th>
              <th>Марка</th>
              <th>Модель</th>
              <th>Год выпуска</th>
              <th>Серия СТС</th>
              <th>Номер СТС</th>
              </tr>
            </thead>
            <tbody>';
    echo '</tbody></table>';
    echo 'Автомобиль не найдена';
  }
  else {
    echo '<div class="' . $scrollspy . '">
          <table class="text-center table table-striped " >
            <thead>
              <tr class="align-top">
              <th>АвтоID</th>
              <th>КлиентID</th>
              <th>Дата</th>
              <th>VIN</th>
              <th>НомерТС</th>
              <th>Марка</th>
              <th>Модель</th>
              <th>Год выпуска</th>
              <th>Серия СТС</th>
              <th>Номер СТС</th>
              </tr>
            </thead>
            <tbody>';
    foreach ($users as $user) {
      if (count($users) == 1) {
        setcookie('АвтомобильID', $user['АвтомобильID'], time() + 3600 * 24, "/");
      }
        echo '<tr class="align-top">
        <td>' . $user['АвтомобильID'] . '</td>
                <td>' . $user['КлиентID'] . '</td>
                <td>' . $user['Дата'] . '</td>
                <td>' . $user['VIN'] . '</td>
                <td>' . $user['НомерТС'] . '</td>
                <td>' . $user['Марка'] . '</td>
                <td>' . $user['Модель'] . '</td>
                <td>' . $user['Год_Выпуска'] . '</td>
                <td>' . $user['Серия_СТС'] . '</td>
                <td>' . $user['Номер_СТС'] . '</td>
              </tr>';
      }
    echo '</tbody></table></div>';
  }
?>
