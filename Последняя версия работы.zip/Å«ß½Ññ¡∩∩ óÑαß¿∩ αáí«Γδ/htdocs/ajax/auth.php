<?php
$login = trim($_POST['login']);
$pass = trim($_POST['password']);


require_once '../mysql_connect.php';

$sql = 'SELECT `СотрудникID`, `Должность`, `Имя`, `Сотрудники_Фамилия` FROM `сотрудники` WHERE `login` = :login && `password` = :pass';
$query = $pdo->prepare($sql);
$query->execute(['login' => $login, 'pass' => $pass]);

$user = $query->fetch(PDO::FETCH_OBJ);
if($user->СотрудникID == 0)
  echo 'Неверный логин или пароль';
else {
  setcookie('Должность', $user->Должность, time() + 3600 * 24, "/");
  setcookie('СотрудникID', $user->СотрудникID, time() + 3600 * 24, "/");
  setcookie('Имя', $user->Имя, time() + 3600 * 24, "/");
  setcookie('Фамилия', $user->Фамилия, time() + 3600 * 24, "/");
  echo "Все готово";
}
?>
