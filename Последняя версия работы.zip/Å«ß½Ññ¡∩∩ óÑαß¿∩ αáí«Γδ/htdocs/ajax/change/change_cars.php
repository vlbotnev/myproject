<?php
$clientID = trim($_POST['changeclientID']);
$checkVIN = trim($_POST['changeVIN']);
$plate = trim($_POST['changeplate']);
$brand = trim($_POST['changebrand']);
$model = trim($_POST['changemodel']);
$year = trim($_POST['changeyear']);
$CTCser = trim($_POST['changeCTCser']);
$CTCnum = trim($_POST['changeCTCnum']);

$carID = $_COOKIE['АвтомобильID'];

require_once '../../mysql_connect.php';

$sql = 'SELECT * FROM `машины` WHERE `АвтомобильID` = :carID';
$query = $pdo->prepare($sql);
$query->execute(['carID' => $carID]);
$users = $query->fetch(PDO::FETCH_ASSOC);

if(strlen($clientID) == 0) {
  $clientID = $users['КлиентID'];
}
if (strlen($checkVIN) == 0) {
  $checkVIN = $users['VIN'];
}
if (strlen($plate) == 0) {
  $plate = $users['НомерТС'];
}
if (strlen($brand) == 0) {
  $brand = $users['Марка'];
}
if (strlen($model) == 0) {
  $model = $users['Модель'];
}
if (strlen($year) == 0) {
  $year = $users['Год_Выпуска'];
}
if (strlen($CTCser) == 0) {
  $CTCser = $users['Серия_СТС'];
}
if (strlen($CTCnum) == 0) {
  $CTCnum = $users['Номер_СТС'];
}

$today = $users['Дата'];
$vis = 1;

$sql = 'UPDATE `машины` SET `КлиентID` = :clientID, `VIN` = :checkVIN, `НомерТС` = :plate, `Марка` = :brand,
`Модель` = :model, `Год_Выпуска` = :year, `Серия_СТС` = :CTCser, `Номер_СТС` = :CTCnum, `Видимость` = :vis, `Дата` = :today WHERE `АвтомобильID` = :carID';
$query = $pdo->prepare($sql);
$query->execute(['clientID' => $clientID, 'checkVIN' => $checkVIN, 'plate' => $plate, 'brand' => $brand,
'model' => $model, 'year' => $year, 'CTCser' => $CTCser, 'CTCnum' => $CTCnum, 'vis' => $vis, 'today' => $today, 'carID' => $carID]);

echo "Все готово";
?>
