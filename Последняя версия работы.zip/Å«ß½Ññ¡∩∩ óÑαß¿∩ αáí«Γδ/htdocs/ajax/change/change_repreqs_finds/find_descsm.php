<?php
  require '../../../mysql_connect.php';

  $id = $_COOKIE['Запрос_На_РемонтID'];

  $sql = 'SELECT `Описание_Крктк` FROM `запрос_на_ремонт`
          WHERE запрос_на_ремонт.Запрос_На_РемонтID = :id';
  $query = $pdo->prepare($sql);
  $query->execute(['id' => $id]);
  $users = $query->fetch(PDO::FETCH_ASSOC);
  echo $users['Описание_Крктк'];
?>
