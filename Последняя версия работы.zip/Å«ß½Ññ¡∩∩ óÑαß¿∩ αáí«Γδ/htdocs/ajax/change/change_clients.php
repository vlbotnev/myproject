<?php
$name = trim($_POST['name']);
$surname = trim($_POST['surname']);
$fname = trim($_POST['fname']);
$phone = trim($_POST['phone']);

$clientID = $_COOKIE['КлиентID'];

require_once '../../mysql_connect.php';

$sql = 'SELECT * FROM `клиенты` WHERE `КлиентID` = :clientID';
$query = $pdo->prepare($sql);
$query->execute(['clientID' => $clientID]);
$users = $query->fetch(PDO::FETCH_ASSOC);

if(strlen($name) == 0) {
  $name = $users['Имя'];
}
if (strlen($surname) == 0) {
  $surname = $users['Фамилия'];
}
if (strlen($fname) == 0) {
  $fname = $users['Отчество'];
}
if (strlen($phone) == 0) {
  $phone = $users['Телефон'];
}

$today = $users['Дата'];
$vis = 1;

$sql = 'UPDATE `клиенты` SET `Имя` = :name, `Фамилия` = :surname, `Отчество` = :fname, `Телефон` = :phone, `Видимость` = :vis, `Дата` = :today WHERE `КлиентID` = :clientID';
$query = $pdo->prepare($sql);
$query->execute(['name' => $name, 'surname' => $surname, 'fname' => $fname, 'phone' => $phone, 'vis' => $vis, 'today' => $today, 'clientID' => $clientID]);

echo "Все готово";
?>
