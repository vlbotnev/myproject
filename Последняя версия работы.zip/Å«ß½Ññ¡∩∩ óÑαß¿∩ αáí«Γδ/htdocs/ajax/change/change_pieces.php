<?php
  $new_piece = $_POST['new_piece'];
  $amount = $_POST['amount'];



  require_once '../../mysql_connect.php';

  $id = $_COOKIE['Запрос_На_РемонтID'];


  $sql = 'SELECT * FROM `запчасти_для_ремонта_temp` WHERE запчасти_для_ремонта_temp.ЗапчастьID = :new_piece';
  $query = $pdo->prepare($sql);
  $query->execute(['new_piece' => $new_piece]);
  $check = $query->fetch(PDO::FETCH_ASSOC);
  try{
    $sql = 'SELECT склад.Количество, склад.Название FROM склад WHERE склад.ЗапчастьID = :new_piece';
    $query = $pdo->prepare($sql);
    $query->execute(['new_piece' => $new_piece]);
    $amountstorage = $query->fetch(PDO::FETCH_ASSOC);
  }
  catch(PDOException $e){
    $return = "Your fail message: " . $e->getMessage();
    echo $return;
    exit();
  }
  if (count($check) == 1) {
    if ($amountstorage['Количество'] >= $amount) {
      if (strlen($new_piece) != 0 && strlen($amount) != 0) {
        $sql = 'INSERT INTO `запчасти_для_ремонта_temp` ( `ЗапчастьID`, `Количество_temp` ) VALUES( :new_piece, :amount )';
        $query = $pdo->prepare($sql);
        $query->execute(['new_piece' => $new_piece, 'amount' => $amount]);
      }
    }
    else {
      echo "На складе столько нет";
      exit();
    }
  }
  else {
    $amount = $amount + $check['Количество_temp'];
    if ($amountstorage['Количество'] >= $amount) {
      if (strlen($new_piece) != 0 && strlen($amount) != 0) {
        $sql = 'UPDATE `запчасти_для_ремонта_temp` SET `Количество_temp` = :amount WHERE `запчасти_для_ремонта_temp`.`ЗапчастьID` = :new_piece';
        $query = $pdo->prepare($sql);
        $query->execute(['new_piece' => $new_piece, 'amount' => $amount]);
      }
    }
    else {
      echo "На складе не хватает: " . $amountstorage['Название'] . "</br>" . "Количество на складе: " . $amountstorage['Количество'] . "</br>";
    }
  }

  $sql = 'SELECT * FROM `запчасти_для_ремонта_temp`
          INNER JOIN склад ON запчасти_для_ремонта_temp.ЗапчастьID = склад.ЗапчастьID';
  $query = $pdo->prepare($sql);
  $query->execute();
  $users = $query->fetchALL(PDO::FETCH_ASSOC);
  if (count($users) == 0) {
    echo "Здесь будут отображаться выбранные запчасти";
  }
  else {
    foreach ($users as $user) {
      echo "Название: " . $user['Название'] . " " . "Кол-во: " . $user['Количество_temp'] . '</br>';
    }
  }
?>
