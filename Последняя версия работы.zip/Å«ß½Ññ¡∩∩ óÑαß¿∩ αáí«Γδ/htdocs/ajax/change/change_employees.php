<?php
  $changesurname = trim($_POST['changesurname']);
  $changename = trim($_POST['changename']);
  $changefname = trim($_POST['changefname']);
  $changephone = trim($_POST['changephone']);
  $changelogin = trim($_POST['changelogin']);
  $changepassword = trim($_POST['changepassword']);
  $changepassser = trim($_POST['changepassser']);
  $changepassnum = trim($_POST['changepassnum']);

  $id = $_COOKIE['СотрудникID_check'];


  require '../../mysql_connect.php';


  try{
    $sql = 'SELECT * FROM `сотрудники` WHERE `СотрудникID` = :id';
    $query = $pdo->prepare($sql);
    $query->execute(['id' => $id]);
    $user = $query->fetch(PDO::FETCH_ASSOC);
  }
  catch(PDOException $e){
        $return = "Your fail message: " . $e->getMessage();
        echo $return;
        exit();
  }

  $changedol = trim($_POST['changedol']);
  if ($changedol == "0") {
    $changedol = "";
  }

  if (strlen($changesurname) == 0) {
    $changesurname = $user['Сотрудники_Фамилия'];
  }
  if(strlen($changename) == 0) {
    $changename = $user['Имя'];
  }
  if (strlen($changefname) == 0) {
    $changefname = $user['Отчество'];
  }
  if (strlen($changephone) == 0 ) {
    $changephone = $user['Телефон'];
  }
  if (strlen($changedol) == 0 ) {
    $changedol = $user['Должность'];
  }
  if (strlen($changelogin)  == 0) {
    $changelogin = $user['login'];
  }
  if (strlen($changepassword)  == 0) {
    $changepassword = $user['password'];
  }
  if (strlen($changepassser)  == 0) {
    $changepassser = $user['Серия_Паспорта'];
  }
  if (strlen($changepassnum)  == 0) {
    $changepassnum = $user['Номер_Паспорта'];
  }

  try {
  $sql = 'UPDATE `сотрудники` SET `login` = :changelogin, `password` = :changepassword, `Сотрудники_Фамилия` = :changesurname, `Имя` = :changename, `Отчество` = :changefname,
  `Телефон` = :changephone, `Серия_Паспорта` = :changepassser, `Номер_Паспорта` = :changepassnum, `Должность` = :changedol WHERE `СотрудникID` = :id';
  $query = $pdo->prepare($sql);
  $query->execute(['changelogin' => $changelogin, 'changepassword' => $changepassword, 'changesurname' => $changesurname, 'changename' => $changename, 'changefname' => $changefname,
  'changephone' => $changephone, 'changepassser' => $changepassser, 'changepassnum' => $changepassnum, 'changedol' => $changedol, 'id' => $id]);
  }
  catch(PDOException $e){
        $return = "Your fail message: " . $e->getMessage();
        echo $return;
        exit();
  }
  echo 'Все готово';

  ?>
