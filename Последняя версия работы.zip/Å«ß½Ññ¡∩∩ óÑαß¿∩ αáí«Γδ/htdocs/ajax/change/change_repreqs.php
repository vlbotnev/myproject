<?php
  $descfull = $_POST['descfull'];
  $descsm = $_POST['descsm'];
  $masterID = $_POST['masterID'];
  $statusID = $_POST['statusID'];

  $id = $_COOKIE['Запрос_На_РемонтID'];


  require '../../mysql_connect.php';

  $sql = 'DELETE FROM `запчасти_для_ремонта` WHERE `запчасти_для_ремонта`.`Запрос_На_РемонтID` = :id';
  $query = $pdo->prepare($sql);
  $query->execute(['id' => $id]);


  $sql = 'SELECT * FROM `запчасти_для_ремонта_temp`';
  $query = $pdo->prepare($sql);
  $query->execute();


  $users = $query->fetchALL(PDO::FETCH_ASSOC);

  foreach ($users as $user) {
      $sql = 'INSERT INTO `запчасти_для_ремонта` ( `Запрос_На_РемонтID`, `ЗапчастьID`, `Количество_Для_Ремонта`) VALUES (:repreqID, :pieceID, :amount)';
      $query = $pdo->prepare($sql);
      $query->execute(['repreqID' => $id, 'pieceID' => $user['ЗапчастьID'], 'amount' => $user['Количество_temp'] ]);
  }

  $sql = 'TRUNCATE TABLE `запчасти_для_ремонта_temp`';
  $query = $pdo->prepare($sql);
  $query->execute();


  try{
  $sql = 'SELECT * FROM `запрос_на_ремонт` WHERE `Запрос_На_РемонтID` = :id';
  $query = $pdo->prepare($sql);
  $query->execute(['id' => $id]);
  $users = $query->fetch(PDO::FETCH_ASSOC);
  }
  catch(PDOException $e){
        $return = "Your fail message: " . $e->getMessage();
        echo $return;
        exit();
  }




  if(strlen($descfull) == 0) {
    $descfull = $users['Описание_Полн'];
  }
  if (strlen($descsm) == 0) {
    $descsm = $users['Описание_Крктк'];
  }
  if (strlen($masterID) == 0) {
    $masterID = $users['СотрудникID_Мастер'];
  }
  if (strlen($statusID) == 0) {
    $statusID = $users['СтатусID'];
  }

  $carID = $users['АвтомобильID'];
  $managerID = $users['СотрудникID_Менеджер'];
  $today = $users['Дата'];
  $vis = 1;

  try{
  $sql = 'UPDATE `запрос_на_ремонт` SET
          `АвтомобильID` = :carID,
          `Описание_Полн` = :descfull,
          `Описание_Крктк` = :descsm,
          `СотрудникID_Мастер` = :masterID,
          `СотрудникID_Менеджер` = :managerID,
          `СтатусID` = :statusID,
          `Дата` = :today,
          `Видимость` = :vis
           WHERE `Запрос_На_РемонтID` = :id';
  $query = $pdo->prepare($sql);
  $query->execute([ 'carID' => $carID,
                    'descfull' => $descfull,
                    'descsm' => $descsm,
                    'masterID' => $masterID,
                    'managerID' => $managerID,
                    'statusID' => $statusID,
                    'today' => $today,
                    'vis' => $vis,
                    'id' => $id]);
  }
  catch(PDOException $e){
        $return = "Your fail message: " . $e->getMessage();
        echo $return;
        exit();
  }

  echo "Все готово";

?>
