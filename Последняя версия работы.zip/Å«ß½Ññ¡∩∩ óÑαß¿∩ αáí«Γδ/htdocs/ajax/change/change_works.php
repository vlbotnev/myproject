<?php
  require_once '../../mysql_connect.php';
  $new_work = $_POST['new_work'];

  $id = $_COOKIE['Запрос_На_РемонтID'];

  if (strlen($new_work) != 0) {
    require_once '../../mysql_connect.php';
    $sql = 'INSERT INTO `работы_по_ремонту` ( `РаботаID`, `Запрос_На_РемонтID`  ) VALUES( :new_work, :id )';
    $query = $pdo->prepare($sql);
    $query->execute(['new_work' => $new_work, 'id' => $id]);
  }

  $sql = 'SELECT * FROM `работы_по_ремонту`
          INNER JOIN прайс_лист_работ ON работы_по_ремонту.РаботаID = прайс_лист_работ.РаботаID
          WHERE работы_по_ремонту.Запрос_На_РемонтID = :id';
  $query = $pdo->prepare($sql);
  $query->execute(['id' => $id]);
  $users = $query->fetchALL(PDO::FETCH_ASSOC);
  if (count($users) == 0) {
    echo "Здесь будут отображаться выбранные работы";
  }
  else {
    foreach ($users as $user) {
      echo "Название: " . $user['Название'] . '</br>';
    }
  }
?>
