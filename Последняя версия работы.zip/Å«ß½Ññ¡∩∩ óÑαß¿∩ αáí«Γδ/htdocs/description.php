<?php
$repreqID = trim($_COOKIE['Запрос_На_РемонтID']);

if($_COOKIE['Запрос_На_РемонтID'] != '') {

require_once 'mysql_connect.php';

$sql = 'SELECT * FROM `запрос_на_ремонт` WHERE `Запрос_На_РемонтID` = :repreqID';
$query = $pdo->prepare($sql);
$query->execute(['repreqID' => $repreqID]);
$users = $query->fetch(PDO::FETCH_ASSOC);

echo $users['Описание_Полн'];

}
else {
  echo 'cookie найдены';
}
?>
