<?php
  $clientid = $_POST['clientid'];
  setcookie('КлиентIDhelp', $clientid, time() + 3600 * 24, "/");
?>
