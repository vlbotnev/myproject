<?php
  $autoid = $_POST['autoid'];
  setcookie('АвтомобильIDhelp', $autoid, time() + 3600 * 24, "/");
?>
