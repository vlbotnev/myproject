<!DOCTYPE html>
<html lang="ru">
<head>
  <?php
    $website_title = 'ИС.Авторизация';
    require 'blocks/head.php';

  ?>
</head>
<body class="bg-light text-center">
  <main class="container mt-5">
    <div class="row">
      <div class="col-md-4">
      </div>
      <div class="col-md-4 mt-5">
        <?php
          if($_COOKIE['СотрудникID'] == ''):
        ?>
        <form>
          <h1 class="h3 mt-5 mb-3 fw-normal w-75 mx-auto">Пожалуйста войдите</h1>

          <input type="text" name="login" id="login" class="form-control w-75 mx-auto mt-3" placeholder="Логин" required="" autofocus="">
          <input type="password" name="password" id="password" class="w-75 mx-auto form-control mt-3" placeholder="Пароль" required="">

          <div class="w-75 mx-auto alert alert-danger mt-2" id="auth_errorBlock"></div>
          <button class="w-75 btn btn-lg btn-primary mt-3" id="auth_user" type="button">Войти</button>
        </form>
        <?php
          else:
        ?>
        <h4><?php
          header("Location: index.php");
        ?></h4>
        <?php
          endif;
        ?>
      </div>
    </div>
  </main>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  <script>
    $('#auth_user').click(function () {
      var login = $('#login').val();
      var password = $('#password').val();

      $.ajax({
        url: 'ajax/auth.php',
        type: 'POST',
        cache: false,
        data: {'login' : login, 'password' : password},
        dataType: 'html',
        success: function (data) {
          if(data == 'Все готово') {
            $('#auth_user').text('Все готово');
            $('#errorBlock').hide();
            document.location.reload(true);
          }
          else {
            $('#errorBlock').show();
            $('#errorBlock').text(data);
          }
        }
      });
    });
  </script>
</body>
</html>
