<!DOCTYPE html>
<html lang="ru">
<head>
  <?php
    $website_title = 'ИС.Клиенты';
    require '../blocks/head.php';
  ?>
</head>
<body class="bg-light text-start">
  <?php
  if($_COOKIE['СотрудникID'] == '') {
    header("Location: ../auth.php");
  }
  ?>
  <header class="container d-flex flex-column flex-md-row align-items-center p-3 px-md-6 mb-3 bg-body border-bottom shadow-sm">
    <div class="mt-1 mb-1 my-0 me-md-auto fw-normal text-start">Форма: Клиенты</div>
    <a class="p-2 text-dark me-4" href="../index.php">На главную</a>
    <button class="btn btn-outline-primary" id="exit_btn">Выйти</button>
  </header>
  <main class="container mt-5">
    <div class="row">
      <div class="col-md-10">
        <form id="change_form">
          <div class="row mb-3 rounded-3 shadow">
              <h2 class="h4 fw-normal  mb-3 text-start mt-3">Изменение данных клиента</h2>
            <div class="col-md-2">
              <input type="text" name="changesurname" id="changesurname" class="mt-3 mb-3 w-100 mx-auto form-control" placeholder="Фамииля">
            </div>
            <div class="col-md-2">
              <input type="text" name="changename" id="changename" class="mt-3  w-100 mx-auto form-control" placeholder="Имя">
            </div>
            <div class="col-md-2">
              <input type="text" name="changefname" id="changefname" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="Отчество">
            </div>
            <div class="col-md-2">
              <input type="text" name="changephone" id="changephone" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="Телефон" maxlength="12">
            </div>
          </div>
        </form>
        <form id="new_form">
          <h2 class="h4 fw-normal mb-3">Поиск/добавление клиента </h2>
          <div class="row">
            <div class="col-md-3">
              <input type="text" name="checksurname" id="checksurname" class="mt-3 mb-3 w-100 mx-auto form-control" placeholder="Фамииля">
              <input type="text" name="checkname" id="checkname" class="mt-3  w-100 mx-auto form-control" placeholder="Имя">
            </div>
            <div class="col-md-3">
              <input type="text" name="checkfname" id="checkfname" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="Отчество">
              <input type="text" name="checkphone" id="checkphone" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="Телефон" maxlength="12">
            </div>
            <div class="col-md-3">
              <input type="text" name="checkclientID" id="checkclientID" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="КлиентID">
              <input type="text" name="checkdate" id="checkdate" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="Дата добавления" maxlength="19">
            </div>
          </div>
        </form>
        <div class="shadow mt" id="table_clients">
          <?php require_once  '../tables/clients_table.php'; ?>
        </div>
    </div>
    <div class="col-md-2">
        <button type="button" id="reset_btn" class=" mb-2 w-100 mx-auto btn btn-outline-primary">Очистить фильтр</button>
        <button class="w-100 btn btn-lg btn-primary mt-3" id="new_save_btn" type="button">Сохранить</button>
        <button class="w-100 btn btn-lg btn-primary mt-3" id="new_back_btn" type="button">Назад</button>
        <button class="w-100 btn btn-lg btn-primary mt-3" id="change_save_btn" type="button">Сохранить</button>
        <button class="w-100 btn btn-lg btn-primary mt-3" id="change_back_btn" type="button">Назад</button>
        <div class="alert alert-primary alert-dismissible fade show mt-2 h-auto" id="change_successBlock" role="alert"></div>
        <div class="h-auto alert alert-danger mt-2 text-start" role="alert" id="change_errorBlock"></div>
        <button class="w-100 btn btn-lg btn-primary mt-3" id="new_btn" type="button">Добавить</button>
        <div class="alert alert-primary alert-dismissible fade show mt-2 h-auto" id="new_successBlock" role="alert"></div>
        <div class="h-auto alert alert-danger mt-2 text-start" role="alert" id="new_errorBlock"></div>
        <button class="w-100 btn btn-lg btn-primary mt-3" id="change_btn" type="button">Изменить</button>
        <div class="h-auto alert alert-danger mt-2 text-start" role="alert" id="change_errorBlock1"></div>
        <button class="w-100 btn btn-lg btn-primary mt-3" id="del_btn" type="button">Удалить</button>
        <div class="h-auto alert alert-danger mt-2 text-start" role="alert" id="delete_errorBlock"></div>
        <div class="alert alert-primary alert-dismissible fade show mt-2 h-auto" id="delete_successBlock" role="alert"></div>
        <button class="w-100 btn btn btn-success mt-3" id="new_sugg_btn" type="button">Добавить автомобиль</button>
      </div>
    </div>
  </main>
  <script>
    function get_cookie ( cookie_name ) {
      var results = document.cookie.match ( '(^|;) ?' + cookie_name + '=([^;]*)(;|$)' );

      if ( results )
       return ( unescape ( results[2] ) );
      else
       return null;
    }

    $('#new_sugg_btn').click(function() {
      var clientid = get_cookie("КлиентID");
      $.ajax({
        type: "POST",
        url: "../redirects/clients-cars.php",
        data: { 'clientid' : clientid },
        success: function(data) {
          window.location.href='cars.php';
          document.getElementById("new_form").reset();
          document.getElementById("change_form").reset();
        }
      });
    });
    $('#reset_btn').click(function() {
      document.getElementById("new_form").reset();
      $.ajax({
          type: "POST",
          url: "../tables/clients_table.php",
          data: { },
          success: function(data) {
            var clientid = get_cookie("КлиентID");
            if (clientid != null) {
                $('#new_sugg_btn').show();
            }
            else {
              $('#new_sugg_btn').hide();
            }
              $("#table_clients").html(data).show();
          }
      });
    });
    $('#checkphone').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9+]/)){
        return false;
      };
    })
    $('#checkname').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[a-zA-Z \\u0400-\\u04FF]/)){
        return false;
      };
    })
    $('#checksurname').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[a-zA-Z \\u0400-\\u04FF]/)){
        return false;
      };
    })
    $('#checkfname').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[a-zA-Z \\u0400-\\u04FF]/)){
        return false;
      };
    })
    $('#checkclientID').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9]/)){
        return false;
      };
    })
    $('#checkdate').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9-: ]/)){
        return false;
      };
    })

    $('#changephone').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9+]/)){
        return false;
      };
    })
    $('#changename').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[a-zA-Z \\u0400-\\u04FF]/)){
        return false;
      };
    })
    $('#changesurname').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[a-zA-Z \\u0400-\\u04FF]/)){
        return false;
      };
    })
    $('#changefname').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[a-zA-Z \\u0400-\\u04FF]/)){
        return false;
      };
    })
    $('#changeclientID').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9]/)){
        return false;
      };
    })
    $('#changedate').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9-: ]/)){
        return false;
      };
    })

    $("#checkname").keyup(function() {
      var phone = $('#checkphone').val();
      var name = $('#checkname').val();
      var surname = $('#checksurname').val();
      var fname = $('#checkfname').val();
      var clientID = $('#checkclientID').val();
      var date = $('#checkdate').val();

      $.ajax({
          type: "POST",
          url: "../ajax/find/find_clients.php",
          data: {'phone' : phone, 'name' : name, 'surname' : surname, 'fname' : fname, 'clientID' : clientID, 'date' : date},
          success: function(data) {
            var clientid = get_cookie("КлиентID");
            if (clientid != null) {
                $('#new_sugg_btn').show();
            }
            else {
              $('#new_sugg_btn').hide();
            }
            $("#table_clients").html(data).show();

          }
      });

    });
    $("#checksurname").keyup(function() {
      var phone = $('#checkphone').val();
      var name = $('#checkname').val();
      var surname = $('#checksurname').val();
      var fname = $('#checkfname').val();
      var clientID = $('#checkclientID').val();
      var date = $('#checkdate').val();

      $.ajax({
          type: "POST",
          url: "../ajax/find/find_clients.php",
          data: {'phone' : phone, 'name' : name, 'surname' : surname, 'fname' : fname, 'clientID' : clientID, 'date' : date},
          success: function(data) {
            var clientid = get_cookie("КлиентID");
            if (clientid != null) {
                $('#new_sugg_btn').show();
            }
            else {
              $('#new_sugg_btn').hide();
            }
              $("#table_clients").html(data).show();
          }

      });
    });
    $("#checkfname").keyup(function() {
      var phone = $('#checkphone').val();
      var name = $('#checkname').val();
      var surname = $('#checksurname').val();
      var fname = $('#checkfname').val();
      var clientID = $('#checkclientID').val();
      var date = $('#checkdate').val();

      $.ajax({
          type: "POST",
          url: "../ajax/find/find_clients.php",
          data: {'phone' : phone, 'name' : name, 'surname' : surname, 'fname' : fname, 'clientID' : clientID, 'date' : date},
          success: function(data) {
            var clientid = get_cookie("КлиентID");
            if (clientid != null) {
                $('#new_sugg_btn').show();
            }
            else {
              $('#new_sugg_btn').hide();
            }
              $("#table_clients").html(data).show();
          }

      });
    });
    $("#checkphone").keyup(function() {
      var phone = $('#checkphone').val();
      var name = $('#checkname').val();
      var surname = $('#checksurname').val();
      var fname = $('#checkfname').val();
      var clientID = $('#checkclientID').val();
      var date = $('#checkdate').val();

      $.ajax({
          type: "POST",
          url: "../ajax/find/find_clients.php",
          data: {'phone' : phone, 'name' : name, 'surname' : surname, 'fname' : fname, 'clientID' : clientID, 'date' : date},
          success: function(data) {
            var clientid = get_cookie("КлиентID");
            if (clientid != null) {
                $('#new_sugg_btn').show();
            }
            else {
              $('#new_sugg_btn').hide();
            }
              $("#table_clients").html(data).show();
          }

      });
    });
    $("#checkclientID").keyup(function() {
      var phone = $('#checkphone').val();
      var name = $('#checkname').val();
      var surname = $('#checksurname').val();
      var fname = $('#checkfname').val();
      var clientID = $('#checkclientID').val();
      var date = $('#checkdate').val();

      $.ajax({
          type: "POST",
          url: "../ajax/find/find_clients.php",
          data: {'phone' : phone, 'name' : name, 'surname' : surname, 'fname' : fname, 'clientID' : clientID, 'date' : date},
          success: function(data) {
            var clientid = get_cookie("КлиентID");
            if (clientid != null) {
                $('#new_sugg_btn').show();
            }
            else {
              $('#new_sugg_btn').hide();
            }
              $("#table_clients").html(data).show();
          }

      });
    });
    $("#checkdate").keyup(function() {
      var phone = $('#checkphone').val();
      var name = $('#checkname').val();
      var surname = $('#checksurname').val();
      var fname = $('#checkfname').val();
      var clientID = $('#checkclientID').val();
      var date = $('#checkdate').val();

      $.ajax({
          type: "POST",
          url: "../ajax/find/find_clients.php",
          data: {'phone' : phone, 'name' : name, 'surname' : surname, 'fname' : fname, 'clientID' : clientID, 'date' : date},
          success: function(data) {
            var clientid = get_cookie("КлиентID");
            if (clientid != null) {
                $('#new_sugg_btn').show();
            }
            else {
              $('#new_sugg_btn').hide();
            }
              $("#table_clients").html(data).show();
          }
      });
    });

    $('#exit_btn').click(function () {
      $.ajax({
        url: '../ajax/exit.php',
        type: 'POST',
        cache: false,
        data: {},
        dataType: 'html',
        success: function (data) {
          document.location.reload(true);
        }
      });
    });

    $('#new_btn').click(function () {
      var phone = $('#checkphone').val();
      var name = $('#checkname').val();
      var surname = $('#checksurname').val();
      var fname = $('#checkfname').val();
      var clientID = $('#checkclientID').val();
      var date = $('#checkdate').val();

      $.ajax({
        url: '../ajax/new/new_clients.php',
        type: 'POST',
        cache: false,
        data: {'phone' : phone, 'name' : name, 'surname' : surname, 'fname' : fname},
        dataType: 'html',
        success: function (data) {
          if(data == 'Все готово') {
            $('#new_errorBlock').hide();
            $('#new_successBlock').text("Клиент успешно добавлен!").show();
            $(function(){
	             $("#new_successBlock").delay(3000).slideUp(300);
            });
            $('#new_sugg_btn').show();
            $(function(){
	             $("#new_sugg_btn").delay(20000).slideUp(300);
            });

            $.ajax({
                type: "POST",
                url: "../ajax/find/find_clients.php",
                data: {'phone' : phone, 'name' : name, 'surname' : surname, 'fname' : fname, 'clientID' : clientID, 'date' : date},
                success: function(data) {
                    $("#table_clients").html(data).show();
                }
            });
           }
          else {
            $('#new_errorBlock').show();
            $(function(){
               $("#new_errorBlock").delay(5000).slideUp(300);
             });
            $('#new_errorBlock').text(data);
          }
        }
      });
    });
    $('#change_btn').click(function() {
      $.ajax({
          type: "POST",
          url: "../ajax/find_cookies/cookies_clients.php",
          data: { },
          success: function(data) {
              if (data == "cookie клиента найдены") {
                $('#new_form').hide();
                $('#new_btn').hide();
                $('#change_btn').hide();
                $('#del_btn').hide();
                $('#reset_btn').hide();
                $('#change_form').show();
                $('#change_save_btn').show();
                $('#change_back_btn').show();
              }
              else {
                $('#change_errorBlock1').show();
                $(function(){
                   $("#change_errorBlock1").delay(5000).slideUp(300);
                 });
                $('#change_errorBlock1').text(data);
              }
          }
      });
    });
    $('#change_back_btn').click(function() {
      $('#new_form').show();
      $('#new_btn').show();
      $('#change_btn').show();
      $('#del_btn').show();
      $('#reset_btn').show();
      $('#change_form').hide();
      $('#change_save_btn').hide();
      $('#change_back_btn').hide();
    });
    $('#change_save_btn').click(function() {
      var phone = $('#changephone').val();
      var name = $('#changename').val();
      var surname = $('#changesurname').val();
      var fname = $('#changefname').val();

      $.ajax({
          type: "POST",
          url: "../ajax/change/change_clients.php",
          data: {'phone' : phone, 'name' : name, 'surname' : surname, 'fname' : fname },
          success: function(data) {
              if (data == 'Все готово') {
                document.getElementById("change_form").reset();
                $('#change_errorBlock').hide();
                $('#change_successBlock').text("Данные клиента успешно обновленны!").show();
                $(function(){
    	             $("#change_successBlock").delay(3000).slideUp(300);
                });
                $.ajax({
                    type: "POST",
                    url: "../tables/clients_table.php",
                    data: { },
                    success: function(data) {
                        $("#table_clients").html(data).show();
                    }
                });
                $('#new_form').show();
                $('#new_btn').show();
                $('#change_btn').show();
                $('#del_btn').show();
                $('#reset_btn').show();
                $('#change_form').hide();
                $('#change_save_btn').hide();
                $('#change_back_btn').hide();
              }
              else {
                $('#change_errorBlock').show();
                $(function(){
                   $("#change_errorBlock").delay(5000).slideUp(300);
                 });
                $('#change_errorBlock').text(data);
            }
          }
      });
    });

    $('#del_btn').click(function() {
      $.ajax({
          type: "POST",
          url: "../ajax/delete/delete_clients.php",
          data: {},
          success: function(result) {
              if (result == 'Все готово') {
                document.getElementById("new_form").reset();
                $('#delete_errorBlock').hide();
                $('#delete_successBlock').text("Сотрудник успешно удален").show();
                $(function(){
    	             $("#delete_successBlock").delay(3000).slideUp(300);
                });
                $.ajax({
                    type: "POST",
                    url: "../tables/clients_table.php",
                    data: { },
                    success: function(result) {
                        $("#table_clients").html(result).show();
                    }
                });
              }
              else {
                $('#delete_errorBlock').show();
                $(function(){
                   $("#delete_errorBlock").delay(5000).slideUp(300);
                 });
                $('#delete_errorBlock').text(result);
              }
          }
      });
    })
  </script>
</body>
</html>
