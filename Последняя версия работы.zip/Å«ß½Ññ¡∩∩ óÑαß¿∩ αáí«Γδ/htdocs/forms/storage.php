<!DOCTYPE html>
<html lang="ru">
<head>
  <?php
    $website_title = 'ИС.Склад';
    require '../blocks/head.php';
  ?>
</script>
</head>
<body class="bg-light text-start">
  <?php
  if($_COOKIE['СотрудникID'] == '') {
    header("Location: ../auth.php");
  }
  ?>
  <header class="container d-flex flex-column flex-md-row align-items-center p-3 px-md-6 mb-3 bg-body border-bottom shadow-sm">
    <div class="mt-1 mb-1 my-0 me-md-auto fw-normal text-start">Форма: Склад</div>
    <a class="p-2 text-dark me-4" href="../index.php">На главную</a>
    <button class="btn btn-outline-primary" id="exit_btn">Выйти</button>
  </header>
  <main class="container mt-5">
    <form id="add_form" class="">
        <div class="mb-3 text-center rounded-3 shadow container">
        <div class="row">
          <div class="row">
            <div class="col-md-5 text-start mt-3">
            <h2 class="h4 fw-normal mb-3">Добавление новой запчасти на склад</h2>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <textarea class="form-control mb-3" id="name" rows="1" placeholder="Название"></textarea>
            </div>
            <div class="form-group">
              <textarea class="form-control mb-3" id="desc" rows="3" placeholder="Описание"></textarea>
            </div>
            <input type="text" name="checkclientID" id="checkclientID" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="Цена продажи">
            <input type="text" name="checkclientID" id="checkclientID" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="Количество">
          </div>
            <div class="col-md-3">
              <select class="" id="new_work" name="city" placeholder="Добавить работу">
                <option value=""></option>
                <?php require '../tables/works_price.php'; ?>
              </select>
              <div class="mt-4">
              <select class="" id="del_work" name="city" placeholder="Удалить работу">
                <option value=""></option>
                <?php require '../tables/works_price.php'; ?>
              </select>
              </div>
            </div>
            <div class="col-md-5">
              <div class="form-control text-muted text-start h-auto" id="hide">Здесь будут отображаться выбранные работы</div>
              <div class="form-control text-muted text-start h-auto" id="works">Здесь будут отображаться выбранные работы</div>
            </div>
        </div>
        <div class="row">
          <div class="col-md-4">
          </div>
          <div class="col-md-3">
            <input type="text" name="checkamount" id="checkamount" class=" mb-3 form-control w-100 mx-auto" placeholder="Колличество">
            <select class="" id="new_piece" name="" placeholder="Добавить запчасть">
              <option value=""></option>
              <?php require '../tables/piece.php'; ?>
            </select>
            <div class="mt-4">
            <select class="" id="del_piece" name="" placeholder="Удалить запчасть">
              <option value=""></option>
              <?php require '../tables/piece.php'; ?>
            </select>
            </div>
          </div>
          <div class="col-md-5">
            <div class="form-control text-muted text-start h-auto" id="pieces">
              Здесь будут отображаться выбранные запчасти
            </div>
          </div>
          <div class="col-md-3 text-start">

            <div><br></div>
          </div>
        </div>
      </div>
    </form>
    <form id="change_form" class="">
        <div class="mb-3 text-center rounded-3 shadow container">
        <div class="row">
          <div class="row">
            <div class="col-md-5 text-start mt-3">
            <h2 class="h4 fw-normal mb-3">Изменение данных заказа</h2>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <textarea class="form-control mb-3" id="changedescsm" rows="1" placeholder="Описание краткое"></textarea>
            </div>
            <div class="form-group">
              <textarea class="form-control mb-3" id="changedescfull" rows="3" placeholder="Описание полное"></textarea>
            </div>

          </div>
            <div class="col-md-3">
              <select class="" id="change_work" name="city" placeholder="Добавить работу">
                <option value=""></option>
                <?php require '../tables/works_price.php'; ?>
              </select>
              <div class="mt-4">
              <select class="" id="change_del_work" name="city" placeholder="Удалить работу">
                <option value=""></option>
                <?php require '../tables/works_price.php'; ?>
              </select>
              </div>
            </div>
            <div class="col-md-5">
              <div class="form-control text-muted text-start h-auto" id="hide">Здесь будут отображаться выбранные работы</div>
              <div class="form-control text-muted text-start h-auto" id="change_works">Здесь будут отображаться выбранные работы</div>
            </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <h2 class="h5 fw-normal mb-3 text-start">Изменение мастера</h2>
            <select class="" id="change_master" name="city" placeholder="Добавить мастера">
              <option value=""></option>
              <?php require '../tables/masters_table.php'; ?>
            </select>
            <h2 class="h5 fw-normal mt-3 mb-3 text-start">Изменение статуса</h2>
            <select class="" id="change_status" name="city" placeholder="Поменять статус">
              <option value=""></option>
              <?php require '../tables/statuses_table.php'; ?>
            </select>
          </div>
          <div class="col-md-3">
            <input type="text" name="checkamount" id="changeamount" class=" mb-3 form-control w-100 mx-auto" placeholder="Колличество">
            <select class="" id="change_piece" name="" placeholder="Добавить запчасть">
              <option value=""></option>
              <?php require '../tables/piece.php'; ?>
            </select>
            <div class="mt-4">
            <select class="" id="change_del_piece" name="" placeholder="Удалить запчасть">
              <option value=""></option>
              <?php require '../tables/piece.php'; ?>
            </select>
            </div>
          </div>
          <div class="col-md-5">
            <div class="form-control text-muted text-start h-auto" id="change_pieces">Здесь будут отображаться выбранные запчасти</div>
          </div>
          <div class="col-md-3 text-start">

            <div><br></div>
          </div>
        </div>
      </div>
    </form>
        <div class="row">
          <div class="col-md-10">
            <form id="find_form">
              <h2 class="h4 fw-normal mb-3">Поиск заявки </h2>
              <div class="row">
                <div class="col-md-2">
                  <input type="text" name="checkclientID" id="checkclientID" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="КлиентID">
                  <input type="text" name="checkcarID" id="checkcarID" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="МашинаID">
                </div>
                <div class="col-md-2">
                  <input type="text" name="checksurname" id="checksurname" class="mt-3 mb-3 w-100 mx-auto form-control" placeholder="Фамииля">
                  <input type="text" name="checkbrand" id="checkbrand" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="Марка">
                </div>
                <div class="col-md-2">
                  <input type="text" name="checkname" id="checkname" class="mt-3  w-100 mx-auto form-control" placeholder="Имя">
                  <input type="text" name="checkmodel" id="checkmodel" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="Модель">
                </div>
                <div class="col-md-2">
                  <input type="text" name="checkphone" id="checkphone" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="Телефон" maxlength="12">
                  <input type="text" name="checkplate" id="checkplate" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="НомерТС" maxlength="9">
                </div>
                <div class="col-md-2">
                  <input type="text" name="checkplate" id="checkdate" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="Дата заявки с">
                  <input type="text" name="checkplate" id="checkdate1" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="Дата заявки по">
                </div>
                <div class="col-md-2">
                  <div class="mt-3">
                    <select class="mt-3" id="checkmaster" name="city" placeholder="мастер">
                      <option value=""></option>
                      <?php require '../tables/masters_table.php'; ?>
                    </select>
                  </div>
                  <div class="mt-4">
                    <select class="" id="checkmanager" name="city" placeholder="Менеджер">
                      <option value=""></option>
                      <?php require '../tables/managers_table.php'; ?>
                    </select>
                  </div>
                  <div class="mt-3">
                    <select class="mt-3" id="checkstatus" name="city" placeholder="мастер">
                      <option value=""></option>
                      <?php require '../tables/statuses_table.php'; ?>
                    </select>
                  </div>
                </div>
              </div>
            </form>
            <div class="shadow mt" id="table_cars">
                <?php require  '../tables/cars_table.php'?>
            </div>
          </div>
            <div class="col-md-2">
                <button class="w-100 btn btn-lg btn-primary mt-3" id="new_save_btn" type="button">Сохранить</button>
                <button class="w-100 btn btn-lg btn-primary mt-3" id="new_back_btn" type="button">Назад</button>
                <button class="w-100 btn btn-lg btn-primary mt-3" id="change_save_btn" type="button">Сохранить</button>
                <button class="w-100 btn btn-lg btn-primary mt-3" id="change_back_btn" type="button">Назад</button>
                <button type="button" id="reset_btn" class="mt-3 mb-3 w-100 mx-auto btn btn-outline-primary">Очистить фильтр</button>
                <button class="w-100 btn btn-lg btn-primary mt-3" id="new_btn" type="button">Добавить</button>
                <div class="h-auto alert alert-danger mt-2 text-start" role="alert" id="new_errorBlock"></div>
                <button class="w-100 btn btn-lg btn-primary mt-3" id="change_btn" type="button">Изменить</button>
                <button class="w-100 btn btn-lg btn-primary mt-3" id="del_btn" type="button">Удалить</button>
                <div class="h-auto alert alert-danger mt-2 text-start" role="alert" id="new_save_errorBlock"></div>

              </div>
          </div>
        <div class=row>
          <div class="col-md-10 mt-3">
            <div class="shadow mt" id="table_repreqs">
                <?php require  '../tables/repreqs_table.php'?>
            </div>
            <div id="info_div" class="container shadow">
              <div class="row">
                <div class="col-md-4">
                  <h2 class="h6 fw-normal mb-3 mt-3">Краткое описание</h2>
                  <div class="form-control text-muted text-start h-auto mb-3" id="info_descsm">Пример</div>
                  <h2 class="h6 fw-normal mb-3 mt-3">Полное описание</h2>
                  <div class="form-control text-muted text-start h-auto mb-3" id="info_descfull">Пример</div>
                  <h2 class="h6 fw-normal mb-3 mt-3">Дата</h2>
                  <div class="form-control text-muted text-start h-auto mb-3" id="info_data">Пример</div>
                </div>
                <div class="col-md-3">
                  <h2 class="h6 fw-normal mb-3 mt-3">Мастер</h2>
                  <div class="form-control text-muted text-start h-auto mb-3" id="info_master">Пример</div>
                  <h2 class="h6 fw-normal mb-3 mt-3">Менеджер</h2>
                  <div class="form-control text-muted text-start h-auto mb-3" id="info_manager">Пример</div>
                  <h2 class="h6 fw-normal mb-3 mt-3">Статус</h2>
                  <div class="form-control text-muted text-start h-auto mb-3" id="info_Status">Пример</div>
                </div>
                <div class="col-md-5">
                  <h2 class="h6 fw-normal mb-3 mt-3">Работы</h2>
                  <div class="form-control text-muted text-start h-auto mb-3" id="info_works">Пример</div>
                  <h2 class="h6 fw-normal mb-3 mt-3">Запчасти</h2>
                  <div class="form-control text-muted text-start h-auto mb-3" id="info_pieces">Пример</div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-2">
            <div class="alert alert-primary alert-dismissible fade show mt-2 h-auto" id="change_successBlock" role="alert"></div>
            <div class="h-auto alert alert-danger mt-2 text-start" role="alert" id="change_errorBlock"></div>
            <div class="h-auto alert alert-danger mt-2 text-start" role="alert" id="new_save_errorBlock"></div>
            <div class="alert alert-primary alert-dismissible fade show  mt-2 mx-auto h-auto" id="new_save_successBlock" role="alert"></div>
            <div class="h-auto alert alert-danger mt-2 text-start" role="alert" id="delete_errorBlock"></div>
            <div class="alert alert-primary alert-dismissible fade show mt-2 h-auto" id="delete_successBlock" role="alert"></div>
            <form id="find_repreq">
              <input type="text" name="checkrepreqID" id="checkrepreqID" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="Запрос на ремонт ID">
            </form>
          </div>
        </div>
      </main>
      <script>
      function get_cookie ( cookie_name ) {
        var results = document.cookie.match ( '(^|;) ?' + cookie_name + '=([^;]*)(;|$)' );

        if ( results )
         return ( unescape ( results[2] ) );
        else
         return null;
      }
      $(document).ready(function () {
        $.ajax({
          type: "POST",
          url: "../ajax/delete/delete_pieces_temp.php",
          data: {  },
          success: function(data) {
          }
        });
        $.ajax({
          type: "POST",
          url: "../ajax/delete/delete_works_temp.php",
          data: {  },
          success: function(data) {
          }
        });
      });
      $(document).ready(function(){
      	$('#new_work').chosen({
      		width: '100%',
      		no_results_text: 'Совпадений не найдено',
      		placeholder_text_single: 'Добавить работу'
      	});
        $('#del_work').chosen({
      		width: '100%',
      		no_results_text: 'Совпадений не найдено',
      		placeholder_text_single: 'Удалить работу'
      	});
        $('#new_piece').chosen({
      		width: '100%',
      		no_results_text: 'Совпадений не найдено',
      		placeholder_text_single: 'Добавить запчасть'
      	});
        $('#del_piece').chosen({
      		width: '100%',
      		no_results_text: 'Совпадений не найдено',
      		placeholder_text_single: 'Удалить запчасть'
      	});
        $('#new_master').chosen({
          width: '100%',
      		no_results_text: 'Совпадений не найдено',
      		placeholder_text_single: 'Выбрать мастера'
        });
        $('#change_work').chosen({
          width: '100%',
      		no_results_text: 'Совпадений не найдено',
      		placeholder_text_single: 'Добавить работу'
        });
        $('#change_del_work').chosen({
          width: '100%',
          no_results_text: 'Совпадений не найдено',
          placeholder_text_single: 'Удалить работу'
        });
        $('#change_piece').chosen({
          width: '100%',
          no_results_text: 'Совпадений не найдено',
          placeholder_text_single: 'Добавить запчасть'
        });
        $('#change_del_piece').chosen({
          width: '100%',
          no_results_text: 'Совпадений не найдено',
          placeholder_text_single: 'Удалить запчасть'
        });
        $('#change_master').chosen({
          width: '100%',
          no_results_text: 'Совпадений не найдено',
          placeholder_text_single: 'Выбрать мастера'
        });
        $('#change_status').chosen({
          width: '100%',
          no_results_text: 'Совпадений не найдено',
          placeholder_text_single: 'Выбрать статус'
        });
        $('#checkmaster').chosen({
          width: '100%',
          no_results_text: 'Совпадений не найдено',
          placeholder_text_single: 'Мастер'
        });
        $('#checkmanager').chosen({
          width: '100%',
          no_results_text: 'Совпадений не найдено',
          placeholder_text_single: 'Менеджер'
        });
        $('#checkstatus').chosen({
          width: '100%',
          no_results_text: 'Совпадений не найдено',
          placeholder_text_single: 'Статус'
        });
      });

      $('#change_btn').click(function(){

        $.ajax({
            type: "POST",
            url: "../ajax/find_cookies/cookies_repreqs.php",
            data: { },
            success: function(data) {
                if (data == "cookie заказа найдены") {
                  $('#info_div').hide();
                  $('#new_btn').hide();
                  $('#reset_btn').hide();
                  $('#del_btn').hide();
                  $('#checkrepreqID').hide();
                  $('#change_btn').hide();
                  $('#find_form').hide();
                  $('#change_form').show();
                  $('#change_save_btn').show();
                  $('#change_back_btn').show();
                  $.ajax({
                    type: "POST",
                    url: "../ajax/change/change_repreqs_finds/find_status.php",
                    data: { },
                    success: function(result) {
                      $('#change_status').val(result).trigger("chosen:updated");
                    }
                  });
                  $.ajax({
                      type: "POST",
                      url: "../tables/repreqs-pieces_table.php",
                      data: {  },
                      success: function(data) {
                        $('#change_pieces').html(data);
                        $('#change_piece').val('').trigger("chosen:updated");
                      }
                  });
                  $.ajax({
                      type: "POST",
                      url: "../tables/repreqs-works_table.php",
                      data: {  },
                      success: function(data) {
                        $('#change_works').html(data);
                        $('#change_work').val('').trigger("chosen:updated");
                      }
                  });
                  $.ajax({
                      type: "POST",
                      url: "../ajax/change/change_repreqs_finds/find_master.php",
                      data: {  },
                      success: function(data) {
                        $('#change_master').val(data).trigger("chosen:updated");
                      }
                  });
                  $.ajax({
                      type: "POST",
                      url: "../ajax/change/change_repreqs_finds/find_descfull.php",
                      data: {  },
                      success: function(data) {
                        $('#changedescfull').val(data);
                      }
                  });
                  $.ajax({
                      type: "POST",
                      url: "../ajax/change/change_repreqs_finds/find_descsm.php",
                      data: {  },
                      success: function(data) {
                        $('#changedescsm').val(data);
                      }
                  });
                }
                else {
                  $('#change_errorBlock').show();
                  $(function(){
                     $("#change_errorBlock").delay(5000).slideUp(300);
                   });
                  $('#change_errorBlock').text(data);
                }
            }
        });
      });
      $('#change_back_btn').click(function(){
        $.ajax({
            type: "POST",
            url: "../delete/delete_pieces_temp.php",
            data: {  },
            success: function(result) {
            }
        });
        $('#info_div').show();
        $('#new_btn').show();
        $('#reset_btn').show();
        $('#del_btn').show();
        $('#checkrepreqID').show();
        $('#change_btn').show();
        $('#find_form').show();
        $('#change_form').hide();
        $('#change_save_btn').hide();
        $('#change_back_btn').hide();
      });
      $('#change_save_btn').click(function(){
        var descfull = $('#changedescfull').val();
        var descsm = $('#changedescsm').val();
        var masterID = $('#change_master').val();
        var statusID = $('#change_status').val();
        var works = document.getElementById("change_works").innerHTML;
        var checkworks = document.getElementById("hide").innerHTML;
        if (works == checkworks) {
          $('#new_save_errorBlock').show();
          $('#new_save_errorBlock').text('Оставьте минимум одну работу');
          $(function(){
             $("#new_save_errorBlock").delay(5000).slideUp(300);
           });
         }
         else {
          $.ajax({
              type: "POST",
              url: "../ajax/change/change_repreqs.php",
              data: { 'descfull' : descfull, 'descsm' :descsm, 'masterID' : masterID, 'statusID' : statusID },
              success: function(data) {
                if (data == 'Все готово') {
                  $('#info_div').hide();
                  $('#new_btn').show();
                  $('#reset_btn').show();
                  $('#del_btn').show();
                  $('#checkrepreqID').show();
                  $('#change_btn').show();
                  $('#find_form').show();
                  $('#change_form').hide();
                  $('#change_save_btn').hide();
                  $('#change_back_btn').hide();
                  $('#change_errorBlock').hide();
                  $('#change_successBlock').text("Данные заказа обновленны").show();
                  $(function(){
                     $("#change_successBlock").delay(3000).slideUp(300);
                  });
                  document.getElementById("find_form").reset();
                  document.getElementById("find_repreq").reset();
                  $('#checkmaster').val('').trigger('chosen:updated');
                  $('#checkmanager').val('').trigger('chosen:updated');
                  $('#checkstatus').val('').trigger('chosen:updated');
                  $.ajax({
                      type: "POST",
                      url: "../tables/cars_table.php",
                      data: {  },
                      success: function(result) {
                          $("#table_cars").html(result).show();
                      }
                  });
                  $.ajax({
                      type: "POST",
                      url: "../tables/repreqs_table.php",
                      data: {  },
                      success: function(result) {
                          $("#table_repreqs").html(result).show();
                      }
                  });
                  $.ajax({
                      type: "POST",
                      url: "../delete/delete_pieces_temp.php",
                      data: {  },
                      success: function(result) {
                      }
                  });
                }
                else {
                  $('#new_save_errorBlock').show();
                  $('#new_save_errorBlock').text(data);
                  $(function(){
                     $("#new_save_errorBlock").delay(5000).slideUp(300);
                   });
              }
            }
          })
        }
      })

      $('#change_del_work').change(function (){
        var del_work = $('#change_del_work').val();
        $.ajax({
            type: "POST",
            url: "../ajax/delete/del_works.php",
            data: { 'del_work' : del_work },
            success: function(data) {
              $('#change_works').html(data);
              $('#change_del_work').val('').trigger('chosen:updated');
            }
        });
      });
      $('#change_work').change(function (){
        var new_work = $('#change_work').val();
        $.ajax({
            type: "POST",
            url: "../ajax/change/change_works.php",
            data: { 'new_work' : new_work },
            success: function(data) {
              $('#change_works').html(data);
              $('#change_work').val('').trigger('chosen:updated');
            }
        });
      });

      $('#change_piece').change(function(){
        var amount = $('#changeamount').val();
        var new_piece = $('#change_piece').val();
        $.ajax({
            type: "POST",
            url: "../ajax/change/change_pieces.php",
            data: { 'new_piece' : new_piece, 'amount' : amount },
            success: function(data) {
              $('#changeamount').val('').trigger('chosen:updated');
              $('#change_pieces').html(data);
              $('#change_piece').val('').trigger('chosen:updated');
            }
        });
      });
      $('#change_del_piece').change(function(){
        var amount = $('#changeamount').val();
        var del_piece = $('#change_del_piece').val();
        $.ajax({
            type: "POST",
            url: "../ajax/delete/del_pieces_temp.php",
            data: { 'del_piece' : del_piece, 'amount' : amount },
            success: function(data) {
              $('#change_pieces').html(data);
              $('#changeamount').val('').trigger('chosen:updated');
              $('#change_del_piece').val('').trigger('chosen:updated');
            }
        });
      });

      $('#new_work').change(function (){
        var new_work = $('#new_work').val();
        $.ajax({
            type: "POST",
            url: "../ajax/new/new_works_temp.php",
            data: { 'new_work' : new_work },
            success: function(data) {
              $('#works').html(data);
              $('#new_work').val('').trigger('chosen:updated');
            }
        });
      });
      $('#del_work').change(function (){
        var del_work = $('#del_work').val();
        $.ajax({
            type: "POST",
            url: "../ajax/delete/del_works_temp.php",
            data: { 'del_work' : del_work },
            success: function(data) {
              $('#works').html(data);
              $('#del_work').val('').trigger('chosen:updated');
            }
        });
      });

      $('#new_piece').change(function (){
        var amount = $('#checkamount').val();
        var new_piece = $('#new_piece').val();
        $.ajax({
            type: "POST",
            url: "../ajax/new/new_pieces_temp.php",
            data: { 'new_piece' : new_piece, 'amount' : amount },
            success: function(data) {
              $('#checkamount').val('').trigger('chosen:updated');
              $('#pieces').html(data);
              $('#new_piece').val('').trigger('chosen:updated');
            }
        });
      });
      $('#del_piece').change(function (){
        var amount = $('#checkamount').val();
        var del_piece = $('#del_piece').val();
        $.ajax({
            type: "POST",
            url: "../ajax/delete/del_pieces_temp.php",
            data: { 'del_piece' : del_piece, 'amount' : amount },
            success: function(data) {
              $('#pieces').html(data);
              $('#checkamount').val('').trigger('chosen:updated');
              $('#del_piece').val('').trigger('chosen:updated');
            }
        });
      });

      $('#new_btn').click(function() {

        var new_btn = 1;
        $.ajax({
            type: "POST",
            url: "../ajax/delete/delete_pieces_temp.php",
            data: {  },
            success: function(result) {
            }
        });
        document.getElementById('descfull').value='';
        document.getElementById('descsm').value='';
        $.ajax({
            type: "POST",
            url: "../ajax/find_cookies/cookies_cars.php",
            data: { },
            success: function(data) {
                if(data == 'cookie автомобиля найдены') {
                  $('#info_div').hide();
                  $('#find_form').hide();
                  $('#new_btn').hide();
                  $('#change_btn').hide();
                  $('#del_btn').hide();
                  $('#reset_btn').hide();
                  $('#checkrepreqID').hide();
                  $('#new_save_btn').show();
                  $('#new_back_btn').show();
                  $('#add_form').show();
                  $.ajax({
                      type: "POST",
                      url: "../ajax/new/new_works_temp.php",
                      data: { 'new_btn' : new_btn },
                      success: function(result) {
                        $('#works').html(result);
                        $('#new_work').val('').trigger('chosen:updated');
                      }
                  });
                  $.ajax({
                      type: "POST",
                      url: "../ajax/new/new_pieces_temp.php",
                      data: {  },
                      success: function(result) {
                        $('#pieces').html(result);
                        $('#new_piece').val('').trigger('chosen:updated');
                      }
                  });
                }
                else {
                  $('#new_errorBlock').show();
                  $('#new_errorBlock').text(data);
                  $(function(){
                     $("#new_errorBlock").delay(5000).slideUp(300);
                   });
                }
            }
        });
      });
      $('#new_back_btn').click(function(){
        $('#info_div').show();
        $('#find_form').show();
        $('#new_btn').show();
        $('#change_btn').show();
        $('#del_btn').show();
        $('#reset_btn').show();
        $('#checkrepreqID').show();
        $('#new_save_btn').hide();
        $('#new_back_btn').hide();
        $('#add_form').hide();
        $.ajax({
            type: "POST",
            url: "../ajax/delete/delete_works_temp.php",
            data: {  },
            success: function(data) {
            }
        });
        $.ajax({
            type: "POST",
            url: "../ajax/delete/delete_pieces_temp.php",
            data: {  },
            success: function(data) {
            }
        });

      });
      $('#new_save_btn').click(function(){
        var descfull = $('#descfull').val();
        var descsm = $('#descsm').val();
        var masterID = $('#new_master').val();
        var works = document.getElementById("works").innerHTML;
        var checkworks = document.getElementById("hide").innerHTML;
        if (works == checkworks) {
          $('#new_save_errorBlock').show();
          $('#new_save_errorBlock').text('Добавьте минимум одну работу');
          $(function(){
             $("#new_save_errorBlock").delay(5000).slideUp(300);
           });
         }
         else {
          $.ajax({
              type: "POST",
              url: "../ajax/new/new_repreqs.php",
              data: { 'descfull' : descfull, 'descsm' :descsm, 'masterID' : masterID },
              success: function(data) {
                if (data == 'Все готово') {
                  $('#info_div').hide();
                  $('#find_form').show();
                  $('#new_btn').show();
                  $('#change_btn').show();
                  $('#del_btn').show();
                  $('#reset_btn').show();
                  $('#checkrepreqID').show();
                  $('#new_save_btn').hide();
                  $('#new_back_btn').hide();
                  $('#add_form').hide();
                  $('#new_save_successBlock').text("Заказ успешно добавлен").show();
                  $(function(){
                     $("#new_save_successBlock").delay(5000).slideUp(300);
                   });
                   document.getElementById("find_form").reset();
                   document.getElementById("find_repreq").reset();
                   $('#checkmaster').val('').trigger('chosen:updated');
                   $('#checkmanager').val('').trigger('chosen:updated');
                   $('#checkstatus').val('').trigger('chosen:updated');
                   $.ajax({
                       type: "POST",
                       url: "../ajax/find/find_repreqs-cars.php",
                       data: {   },
                       success: function(yeah) {
                           $.ajax({
                               type: "POST",
                               url: "../ajax/find/find_repreqs.php",
                               data: {   },
                               success: function(yeah) {
                                   $("#table_repreqs").html(yeah).show();
                               }
                           });
                           $("#table_cars").html(yeah).show();
                       }
                   });
                }
                else {
                  $('#new_save_errorBlock').show();
                  $('#new_save_errorBlock').text(data);
                  $(function(){
                     $("#new_save_errorBlock").delay(5000).slideUp(300);
                   });
              }
            }
          });
        }
      });

      $('#reset_btn').click(function() {
        document.getElementById("find_form").reset();
        document.getElementById("find_repreq").reset();
        $('#checkmaster').val('').trigger('chosen:updated');
        $('#checkmanager').val('').trigger('chosen:updated');
        $('#checkstatus').val('').trigger('chosen:updated');
        $.ajax({
            type: "POST",
            url: "../tables/cars_table.php",
            data: {  },
            success: function(data) {
              var repreqIDhelp = get_cookie("Запрос_На_РемонтID");
              if (repreqIDhelp != null) {
                  $('#info_div').show();
              }
              else {
                $('#info_div').hide();
              }
                $("#table_cars").html(data).show();
            }
        });
        $.ajax({
            type: "POST",
            url: "../tables/repreqs_table.php",
            data: {  },
            success: function(data) {
              var repreqIDhelp = get_cookie("Запрос_На_РемонтID");
              if (repreqIDhelp != null) {
                  $('#info_div').show();
              }
              else {
                $('#info_div').hide();
              }
                $("#table_repreqs").html(data).show();
            }
        });
      });

      $('#checkCTCser').on('keydown', function(e){
        if(e.key.length == 1 && e.key.match(/[^0-9]/)){
          return false;
        };
      })
      $('#checkCTCnum').on('keydown', function(e){
        if(e.key.length == 1 && e.key.match(/[^0-9]/)){
          return false;
        };
      })
      $('#checkclientID').on('keydown', function(e){
        if(e.key.length == 1 && e.key.match(/[^0-9]/)){
          return false;
        };
      })
      $('#checkyear').on('keydown', function(e){
        if(e.key.length == 1 && e.key.match(/[^0-9]/)){
          return false;
        };
      })
      $('#checkVIN').on('keydown', function(e){
        if(e.key.length == 1 && e.key.match(/[^0-9^A-Z]/)){
          return false;
        };
      })
      $('#checkplate').on('keydown', function(e){
        if(e.key.length == 1 && e.key.match(/[^0-9^[АВЕКМНОРСТУХ]/)){
          return false;
        };
      })
      $('#checkcarID').on('keydown', function(e){
        if(e.key.length == 1 && e.key.match(/[^0-9]/)){
          return false;
        };
      })
      $('#checkdate').on('keydown', function(e){
        if(e.key.length == 1 && e.key.match(/[^0-9-: ]/)){
          return false;
        };
      })

      $('#checkphone').on('keydown', function(e){
        if(e.key.length == 1 && e.key.match(/[^0-9+]/)){
          return false;
        };
      })
      $('#checkname').on('keydown', function(e){
        if(e.key.length == 1 && e.key.match(/[a-zA-Z \\u0400-\\u04FF]/)){
          return false;
        };
      })
      $('#checksurname').on('keydown', function(e){
        if(e.key.length == 1 && e.key.match(/[a-zA-Z \\u0400-\\u04FF]/)){
          return false;
        };
      })
      $('#checkfname').on('keydown', function(e){
        if(e.key.length == 1 && e.key.match(/[a-zA-Z \\u0400-\\u04FF]/)){
          return false;
        };
      })
      $('#checkclientID_client').on('keydown', function(e){
        if(e.key.length == 1 && e.key.match(/[^0-9]/)){
          return false;
        };
      })
      $('#checkdate_client').on('keydown', function(e){
        if(e.key.length == 1 && e.key.match(/[^0-9-: ]/)){
          return false;
        };
      })
      $('#checksurname').on('keydown', function(e){
        if(e.key.length == 1 && e.key.match(/[a-zA-Z \\u0400-\\u04FF]/)){
          return false;
        };
      })

      $("#checkclientID").keyup(function() {
        document.getElementById("find_repreq").reset();
        var phone = $('#checkphone').val();
        var name = $('#checkname').val();
        var surname = $('#checksurname').val();
        var fname = $('#checkfname').val();
        var clientID = $('#checkclientID').val();
        var plate = $('#checkplate').val();
        var brand = $('#checkbrand').val();
        var model = $('#checkmodel').val();
        var carID = $('#checkcarID').val();

        $.ajax({
            type: "POST",
            url: "../ajax/find/find_repreqs-cars.php",
            data: { 'phone' : phone, 'name' :name, 'surname' : surname, 'fname' :fname, 'clientID' : clientID, 'plate' :plate, 'brand' : brand, 'model' :model, 'carID' :carID  },
            success: function(data) {
              var repreqIDhelp = get_cookie("Запрос_На_РемонтID");
              if (repreqIDhelp != null) {
                  $('#info_div').show();
              }
              else {
                $('#info_div').hide();
              }
              $("#table_cars").html(data).show();
              $.ajax({
                  type: "POST",
                  url: "../ajax/find/find_repreqs.php",
                  data: { 'phone' : phone, 'name' :name, 'surname' : surname, 'fname' :fname, 'clientID' : clientID, 'plate' :plate, 'brand' : brand, 'model' :model, 'carID' :carID  },
                  success: function(data) {
                    var repreqIDhelp = get_cookie("Запрос_На_РемонтID");
                    if (repreqIDhelp != null) {
                        $('#info_div').show();
                    }
                    else {
                      $('#info_div').hide();
                    }
                      $("#table_repreqs").html(data).show();
                  }
              });
            }
        });
      });
      $("#checkcarID").keyup(function() {
        document.getElementById("find_repreq").reset();
        var phone = $('#checkphone').val();
        var name = $('#checkname').val();
        var surname = $('#checksurname').val();
        var fname = $('#checkfname').val();
        var clientID = $('#checkclientID').val();
        var plate = $('#checkplate').val();
        var brand = $('#checkbrand').val();
        var model = $('#checkmodel').val();
        var carID = $('#checkcarID').val();

        $.ajax({
            type: "POST",
            url: "../ajax/find/find_repreqs-cars.php",
            data: { 'phone' : phone, 'name' :name, 'surname' : surname, 'fname' :fname, 'clientID' : clientID, 'plate' :plate, 'brand' : brand, 'model' :model, 'carID' :carID  },
            success: function(data) {
              var repreqIDhelp = get_cookie("Запрос_На_РемонтID");
              if (repreqIDhelp != null) {
                  $('#info_div').show();

              }
              else {
                $('#info_div').hide();
              }
              $("#table_cars").html(data).show();
              $.ajax({
                  type: "POST",
                  url: "../ajax/find/find_repreqs.php",
                  data: { 'phone' : phone, 'name' :name, 'surname' : surname, 'fname' :fname, 'clientID' : clientID, 'plate' :plate, 'brand' : brand, 'model' :model, 'carID' :carID  },
                  success: function(data) {
                    var repreqIDhelp = get_cookie("Запрос_На_РемонтID");
                    if (repreqIDhelp != null) {
                        $('#info_div').show();
                        $.ajax({
                          type: "POST",
                          url: "../ajax/change/change_repreqs_finds/find_status.php",
                          data: { },
                          success: function(result) {
                            $('#info_Status').text(result);
                          }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../tables/repreqs-pieces_table.php",
                            data: {  },
                            success: function(result) {
                              $('#info_pieces').html(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../tables/repreqs-works_table.php",
                            data: {  },
                            success: function(result) {
                              $('#info_works').html(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_master_surname.php",
                            data: {  },
                            success: function(result) {
                              $('#info_master').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_manager_surname.php",
                            data: {  },
                            success: function(result) {
                              $('#info_manager').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_data.php",
                            data: {  },
                            success: function(result) {
                              $('#info_data').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_descfull.php",
                            data: {  },
                            success: function(result) {
                              $('#info_descfull').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_descsm.php",
                            data: {  },
                            success: function(result) {
                              $('#info_descsm').text(result);
                            }
                        });
                    }
                    else {
                      $('#info_div').hide();
                    }
                      $("#table_repreqs").html(data).show();
                  }
              });
            }
        });
      });
      $("#checksurname").keyup(function() {
        document.getElementById("find_repreq").reset();
        var phone = $('#checkphone').val();
        var name = $('#checkname').val();
        var surname = $('#checksurname').val();
        var fname = $('#checkfname').val();
        var clientID = $('#checkclientID').val();
        var plate = $('#checkplate').val();
        var brand = $('#checkbrand').val();
        var model = $('#checkmodel').val();
        var carID = $('#checkcarID').val();

        $.ajax({
            type: "POST",
            url: "../ajax/find/find_repreqs-cars.php",
            data: { 'phone' : phone, 'name' :name, 'surname' : surname, 'fname' :fname, 'clientID' : clientID, 'plate' :plate, 'brand' : brand, 'model' :model, 'carID' :carID  },
            success: function(data) {
              var repreqIDhelp = get_cookie("Запрос_На_РемонтID");
              if (repreqIDhelp != null) {
                  $('#info_div').show();
              }
              else {
                $('#info_div').hide();
              }
              $("#table_cars").html(data).show();
              $.ajax({
                  type: "POST",
                  url: "../ajax/find/find_repreqs.php",
                  data: { 'phone' : phone, 'name' :name, 'surname' : surname, 'fname' :fname, 'clientID' : clientID, 'plate' :plate, 'brand' : brand, 'model' :model, 'carID' :carID  },
                  success: function(data) {
                    var repreqIDhelp = get_cookie("Запрос_На_РемонтID");
                    if (repreqIDhelp != null) {
                        $('#info_div').show();
                        $.ajax({
                          type: "POST",
                          url: "../ajax/change/change_repreqs_finds/find_status.php",
                          data: { },
                          success: function(result) {
                            $('#info_Status').text(result);
                          }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../tables/repreqs-pieces_table.php",
                            data: {  },
                            success: function(result) {
                              $('#info_pieces').html(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../tables/repreqs-works_table.php",
                            data: {  },
                            success: function(result) {
                              $('#info_works').html(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_master_surname.php",
                            data: {  },
                            success: function(result) {
                              $('#info_master').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_manager_surname.php",
                            data: {  },
                            success: function(result) {
                              $('#info_manager').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_data.php",
                            data: {  },
                            success: function(result) {
                              $('#info_data').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_descfull.php",
                            data: {  },
                            success: function(result) {
                              $('#info_descfull').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_descsm.php",
                            data: {  },
                            success: function(result) {
                              $('#info_descsm').text(result);
                            }
                        });
                    }
                    else {
                      $('#info_div').hide();
                    }
                      $("#table_repreqs").html(data).show();
                  }
              });
            }
        });
      });
      $("#checkbrand").keyup(function() {
        document.getElementById("find_repreq").reset();
        var phone = $('#checkphone').val();
        var name = $('#checkname').val();
        var surname = $('#checksurname').val();
        var fname = $('#checkfname').val();
        var clientID = $('#checkclientID').val();
        var plate = $('#checkplate').val();
        var brand = $('#checkbrand').val();
        var model = $('#checkmodel').val();
        var carID = $('#checkcarID').val();

        $.ajax({
            type: "POST",
            url: "../ajax/find/find_repreqs-cars.php",
            data: { 'phone' : phone, 'name' :name, 'surname' : surname, 'fname' :fname, 'clientID' : clientID, 'plate' :plate, 'brand' : brand, 'model' :model, 'carID' :carID  },
            success: function(data) {
              var repreqIDhelp = get_cookie("Запрос_На_РемонтID");
              if (repreqIDhelp != null) {
                  $('#info_div').show();
              }
              else {
                $('#info_div').hide();
              }
              $("#table_cars").html(data).show();
              $.ajax({
                  type: "POST",
                  url: "../ajax/find/find_repreqs.php",
                  data: { 'phone' : phone, 'name' :name, 'surname' : surname, 'fname' :fname, 'clientID' : clientID, 'plate' :plate, 'brand' : brand, 'model' :model, 'carID' :carID  },
                  success: function(data) {
                    var repreqIDhelp = get_cookie("Запрос_На_РемонтID");
                    if (repreqIDhelp != null) {
                        $('#info_div').show();
                        $.ajax({
                          type: "POST",
                          url: "../ajax/change/change_repreqs_finds/find_status.php",
                          data: { },
                          success: function(result) {
                            $('#info_Status').text(result);
                          }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../tables/repreqs-pieces_table.php",
                            data: {  },
                            success: function(result) {
                              $('#info_pieces').html(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../tables/repreqs-works_table.php",
                            data: {  },
                            success: function(result) {
                              $('#info_works').html(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_master_surname.php",
                            data: {  },
                            success: function(result) {
                              $('#info_master').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_manager_surname.php",
                            data: {  },
                            success: function(result) {
                              $('#info_manager').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_data.php",
                            data: {  },
                            success: function(result) {
                              $('#info_data').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_descfull.php",
                            data: {  },
                            success: function(result) {
                              $('#info_descfull').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_descsm.php",
                            data: {  },
                            success: function(result) {
                              $('#info_descsm').text(result);
                            }
                        });
                    }
                    else {
                      $('#info_div').hide();
                    }
                      $("#table_repreqs").html(data).show();
                  }
              });
            }
        });
      });
      $("#checkname").keyup(function() {
        document.getElementById("find_repreq").reset();
        var phone = $('#checkphone').val();
        var name = $('#checkname').val();
        var surname = $('#checksurname').val();
        var fname = $('#checkfname').val();
        var clientID = $('#checkclientID').val();
        var plate = $('#checkplate').val();
        var brand = $('#checkbrand').val();
        var model = $('#checkmodel').val();
        var carID = $('#checkcarID').val();

        $.ajax({
            type: "POST",
            url: "../ajax/find/find_repreqs-cars.php",
            data: { 'phone' : phone, 'name' :name, 'surname' : surname, 'fname' :fname, 'clientID' : clientID, 'plate' :plate, 'brand' : brand, 'model' :model, 'carID' :carID  },
            success: function(data) {
              var repreqIDhelp = get_cookie("Запрос_На_РемонтID");
              if (repreqIDhelp != null) {
                  $('#info_div').show();
              }
              else {
                $('#info_div').hide();
              }
              $("#table_cars").html(data).show();
              $.ajax({
                  type: "POST",
                  url: "../ajax/find/find_repreqs.php",
                  data: { 'phone' : phone, 'name' :name, 'surname' : surname, 'fname' :fname, 'clientID' : clientID, 'plate' :plate, 'brand' : brand, 'model' :model, 'carID' :carID  },
                  success: function(data) {
                    var repreqIDhelp = get_cookie("Запрос_На_РемонтID");
                    if (repreqIDhelp != null) {
                        $('#info_div').show();
                        $.ajax({
                          type: "POST",
                          url: "../ajax/change/change_repreqs_finds/find_status.php",
                          data: { },
                          success: function(result) {
                            $('#info_Status').text(result);
                          }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../tables/repreqs-pieces_table.php",
                            data: {  },
                            success: function(result) {
                              $('#info_pieces').html(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../tables/repreqs-works_table.php",
                            data: {  },
                            success: function(result) {
                              $('#info_works').html(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_master_surname.php",
                            data: {  },
                            success: function(result) {
                              $('#info_master').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_manager_surname.php",
                            data: {  },
                            success: function(result) {
                              $('#info_manager').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_data.php",
                            data: {  },
                            success: function(result) {
                              $('#info_data').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_descfull.php",
                            data: {  },
                            success: function(result) {
                              $('#info_descfull').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_descsm.php",
                            data: {  },
                            success: function(result) {
                              $('#info_descsm').text(result);
                            }
                        });
                    }
                    else {
                      $('#info_div').hide();
                    }
                      $("#table_repreqs").html(data).show();
                  }
              });
            }
        });
      });
      $("#checkmodel").keyup(function() {
        document.getElementById("find_repreq").reset();
        var phone = $('#checkphone').val();
        var name = $('#checkname').val();
        var surname = $('#checksurname').val();
        var fname = $('#checkfname').val();
        var clientID = $('#checkclientID').val();
        var plate = $('#checkplate').val();
        var brand = $('#checkbrand').val();
        var model = $('#checkmodel').val();
        var carID = $('#checkcarID').val();

        $.ajax({
            type: "POST",
            url: "../ajax/find/find_repreqs-cars.php",
            data: { 'phone' : phone, 'name' :name, 'surname' : surname, 'fname' :fname, 'clientID' : clientID, 'plate' :plate, 'brand' : brand, 'model' :model, 'carID' :carID  },
            success: function(data) {
              var repreqIDhelp = get_cookie("Запрос_На_РемонтID");
              if (repreqIDhelp != null) {
                  $('#info_div').show();
              }
              else {
                $('#info_div').hide();
              }
              $("#table_cars").html(data).show();
              $.ajax({
                  type: "POST",
                  url: "../ajax/find/find_repreqs.php",
                  data: { 'phone' : phone, 'name' :name, 'surname' : surname, 'fname' :fname, 'clientID' : clientID, 'plate' :plate, 'brand' : brand, 'model' :model, 'carID' :carID  },
                  success: function(data) {
                    var repreqIDhelp = get_cookie("Запрос_На_РемонтID");
                    if (repreqIDhelp != null) {
                        $('#info_div').show();
                        $.ajax({
                          type: "POST",
                          url: "../ajax/change/change_repreqs_finds/find_status.php",
                          data: { },
                          success: function(result) {
                            $('#info_Status').text(result);
                          }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../tables/repreqs-pieces_table.php",
                            data: {  },
                            success: function(result) {
                              $('#info_pieces').html(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../tables/repreqs-works_table.php",
                            data: {  },
                            success: function(result) {
                              $('#info_works').html(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_master_surname.php",
                            data: {  },
                            success: function(result) {
                              $('#info_master').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_manager_surname.php",
                            data: {  },
                            success: function(result) {
                              $('#info_manager').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_data.php",
                            data: {  },
                            success: function(result) {
                              $('#info_data').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_descfull.php",
                            data: {  },
                            success: function(result) {
                              $('#info_descfull').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_descsm.php",
                            data: {  },
                            success: function(result) {
                              $('#info_descsm').text(result);
                            }
                        });
                    }
                    else {
                      $('#info_div').hide();
                    }
                      $("#table_repreqs").html(data).show();
                  }
              });
            }
        });
      });
      $("#checkphone").keyup(function() {
        document.getElementById("find_repreq").reset();
        var phone = $('#checkphone').val();
        var name = $('#checkname').val();
        var surname = $('#checksurname').val();
        var fname = $('#checkfname').val();
        var clientID = $('#checkclientID').val();
        var plate = $('#checkplate').val();
        var brand = $('#checkbrand').val();
        var model = $('#checkmodel').val();
        var carID = $('#checkcarID').val();

        $.ajax({
            type: "POST",
            url: "../ajax/find/find_repreqs-cars.php",
            data: { 'phone' : phone, 'name' :name, 'surname' : surname, 'fname' :fname, 'clientID' : clientID, 'plate' :plate, 'brand' : brand, 'model' :model, 'carID' :carID  },
            success: function(data) {
              var repreqIDhelp = get_cookie("Запрос_На_РемонтID");
              if (repreqIDhelp != null) {
                  $('#info_div').show();
              }
              else {
                $('#info_div').hide();
              }
              $("#table_cars").html(data).show();
              $.ajax({
                  type: "POST",
                  url: "../ajax/find/find_repreqs.php",
                  data: { 'phone' : phone, 'name' :name, 'surname' : surname, 'fname' :fname, 'clientID' : clientID, 'plate' :plate, 'brand' : brand, 'model' :model, 'carID' :carID  },
                  success: function(data) {
                    var repreqIDhelp = get_cookie("Запрос_На_РемонтID");
                    if (repreqIDhelp != null) {
                        $('#info_div').show();
                        $.ajax({
                          type: "POST",
                          url: "../ajax/change/change_repreqs_finds/find_status.php",
                          data: { },
                          success: function(result) {
                            $('#info_Status').text(result);
                          }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../tables/repreqs-pieces_table.php",
                            data: {  },
                            success: function(result) {
                              $('#info_pieces').html(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../tables/repreqs-works_table.php",
                            data: {  },
                            success: function(result) {
                              $('#info_works').html(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_master_surname.php",
                            data: {  },
                            success: function(result) {
                              $('#info_master').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_manager_surname.php",
                            data: {  },
                            success: function(result) {
                              $('#info_manager').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_data.php",
                            data: {  },
                            success: function(result) {
                              $('#info_data').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_descfull.php",
                            data: {  },
                            success: function(result) {
                              $('#info_descfull').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_descsm.php",
                            data: {  },
                            success: function(result) {
                              $('#info_descsm').text(result);
                            }
                        });
                    }
                    else {
                      $('#info_div').hide();
                    }
                      $("#table_repreqs").html(data).show();
                  }
              });
            }
        });
      });
      $("#checkplate").keyup(function() {
        document.getElementById("find_repreq").reset();
        var phone = $('#checkphone').val();
        var name = $('#checkname').val();
        var surname = $('#checksurname').val();
        var fname = $('#checkfname').val();
        var clientID = $('#checkclientID').val();
        var plate = $('#checkplate').val();
        var brand = $('#checkbrand').val();
        var model = $('#checkmodel').val();
        var carID = $('#checkcarID').val();

        $.ajax({
            type: "POST",
            url: "../ajax/find/find_repreqs-cars.php",
            data: { 'phone' : phone, 'name' :name, 'surname' : surname, 'fname' :fname, 'clientID' : clientID, 'plate' :plate, 'brand' : brand, 'model' :model, 'carID' :carID  },
            success: function(data) {
              var repreqIDhelp = get_cookie("Запрос_На_РемонтID");
              if (repreqIDhelp != null) {
                  $('#info_div').show();
              }
              else {
                $('#info_div').hide();
              }
              $("#table_cars").html(data).show();
              $.ajax({
                  type: "POST",
                  url: "../ajax/find/find_repreqs.php",
                  data: { 'phone' : phone, 'name' :name, 'surname' : surname, 'fname' :fname, 'clientID' : clientID, 'plate' :plate, 'brand' : brand, 'model' :model, 'carID' :carID  },
                  success: function(data) {
                    var repreqIDhelp = get_cookie("Запрос_На_РемонтID");
                    if (repreqIDhelp != null) {
                        $('#info_div').show();
                        $.ajax({
                          type: "POST",
                          url: "../ajax/change/change_repreqs_finds/find_status.php",
                          data: { },
                          success: function(result) {
                            $('#info_Status').text(result);
                          }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../tables/repreqs-pieces_table.php",
                            data: {  },
                            success: function(result) {
                              $('#info_pieces').html(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../tables/repreqs-works_table.php",
                            data: {  },
                            success: function(result) {
                              $('#info_works').html(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_master_surname.php",
                            data: {  },
                            success: function(result) {
                              $('#info_master').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_manager_surname.php",
                            data: {  },
                            success: function(result) {
                              $('#info_manager').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_data.php",
                            data: {  },
                            success: function(result) {
                              $('#info_data').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_descfull.php",
                            data: {  },
                            success: function(result) {
                              $('#info_descfull').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_descsm.php",
                            data: {  },
                            success: function(result) {
                              $('#info_descsm').text(result);
                            }
                        });
                    }
                    else {
                      $('#info_div').hide();
                    }
                      $("#table_repreqs").html(data).show();
                  }
              });
            }
        });
      });
      $("#checkrepreqID").keyup(function() {
        var phone = $('#checkphone').val();
        var name = $('#checkname').val();
        var surname = $('#checksurname').val();
        var fname = $('#checkfname').val();
        var clientID = $('#checkclientID').val();
        var plate = $('#checkplate').val();
        var brand = $('#checkbrand').val();
        var model = $('#checkmodel').val();
        var carID = $('#checkcarID').val();
        var repreqID = $('#checkrepreqID').val();

        $.ajax({
            type: "POST",
            url: "../ajax/find/find_repreqs-cars.php",
            data: { 'phone' : phone, 'name' :name, 'surname' : surname, 'fname' :fname, 'clientID' : clientID, 'plate' :plate, 'brand' : brand, 'model' :model, 'carID' :carID, 'repreqID' : repreqID  },
            success: function(data) {
              var repreqIDhelp = get_cookie("Запрос_На_РемонтID");
              if (repreqIDhelp != null) {
                  $('#info_div').show();
              }
              else {
                $('#info_div').hide();
              }
              $("#table_cars").html(data).show();
              $.ajax({
                  type: "POST",
                  url: "../ajax/find/find_repreqs.php",
                  data: { 'phone' : phone, 'name' :name, 'surname' : surname, 'fname' :fname, 'clientID' : clientID, 'plate' :plate, 'brand' : brand, 'model' :model, 'carID' :carID, 'repreqID' : repreqID  },
                  success: function(data) {
                    var repreqIDhelp = get_cookie("Запрос_На_РемонтID");
                    if (repreqIDhelp != null) {
                        $('#info_div').show();
                        $.ajax({
                          type: "POST",
                          url: "../ajax/change/change_repreqs_finds/find_status.php",
                          data: { },
                          success: function(result) {
                            $('#info_Status').text(result);
                          }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../tables/repreqs-pieces_table.php",
                            data: {  },
                            success: function(result) {
                              $('#info_pieces').html(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../tables/repreqs-works_table.php",
                            data: {  },
                            success: function(result) {
                              $('#info_works').html(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_master_surname.php",
                            data: {  },
                            success: function(result) {
                              $('#info_master').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_manager_surname.php",
                            data: {  },
                            success: function(result) {
                              $('#info_manager').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_data.php",
                            data: {  },
                            success: function(result) {
                              $('#info_data').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_descfull.php",
                            data: {  },
                            success: function(result) {
                              $('#info_descfull').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_descsm.php",
                            data: {  },
                            success: function(result) {
                              $('#info_descsm').text(result);
                            }
                        });
                    }
                    else {
                      $('#info_div').hide();
                    }
                      $("#table_repreqs").html(data).show();
                  }
              });
            }
        });
      });
      $("#checkdate").keyup(function() {
        var phone = $('#checkphone').val();
        var name = $('#checkname').val();
        var surname = $('#checksurname').val();
        var fname = $('#checkfname').val();
        var clientID = $('#checkclientID').val();
        var plate = $('#checkplate').val();
        var brand = $('#checkbrand').val();
        var model = $('#checkmodel').val();
        var carID = $('#checkcarID').val();
        var repreqID = $('#checkrepreqID').val();
        var checkdate = $('#checkdate').val();
        var checkmaster = $('#checkmaster').val();
        var checkmanager = $('#checkmanager').val();
        var checkstatus = $('#checkstatus').val();

        $.ajax({
            type: "POST",
            url: "../ajax/find/find_repreqs-cars.php",
            data: { 'phone' : phone,
                    'name' :name,
                    'surname' : surname,
                    'fname' :fname,
                    'clientID' : clientID,
                    'plate' :plate,
                    'brand' : brand,
                    'model' :model,
                    'carID' :carID,
                    'repreqID' : repreqID,
                    'checkdate' : checkdate,
                    'checkmaster' : checkmaster,
                    'checkmanager' : checkmanager,
                    'checkstatus' : checkstatus   },
            success: function(data) {
              var repreqIDhelp = get_cookie("Запрос_На_РемонтID");
              if (repreqIDhelp != null) {
                  $('#info_div').show();
              }
              else {
                $('#info_div').hide();
              }
              $("#table_cars").html(data).show();
              $.ajax({
                  type: "POST",
                  url: "../ajax/find/find_repreqs.php",
                  data: { 'phone' : phone,
                          'name' :name,
                          'surname' : surname,
                          'fname' :fname,
                          'clientID' : clientID,
                          'plate' :plate,
                          'brand' : brand,
                          'model' :model,
                          'carID' :carID,
                          'repreqID' : repreqID,
                          'checkdate' : checkdate,
                          'checkmaster' : checkmaster,
                          'checkmanager' : checkmanager,
                          'checkstatus' : checkstatus  },
                  success: function(data) {
                    var repreqIDhelp = get_cookie("Запрос_На_РемонтID");
                    if (repreqIDhelp != null) {
                        $('#info_div').show();
                        $.ajax({
                          type: "POST",
                          url: "../ajax/change/change_repreqs_finds/find_status.php",
                          data: { },
                          success: function(result) {
                            $('#info_Status').text(result);
                          }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../tables/repreqs-pieces_table.php",
                            data: {  },
                            success: function(result) {
                              $('#info_pieces').html(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../tables/repreqs-works_table.php",
                            data: {  },
                            success: function(result) {
                              $('#info_works').html(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_master_surname.php",
                            data: {  },
                            success: function(result) {
                              $('#info_master').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_manager_surname.php",
                            data: {  },
                            success: function(result) {
                              $('#info_manager').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_data.php",
                            data: {  },
                            success: function(result) {
                              $('#info_data').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_descfull.php",
                            data: {  },
                            success: function(result) {
                              $('#info_descfull').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_descsm.php",
                            data: {  },
                            success: function(result) {
                              $('#info_descsm').text(result);
                            }
                        });
                    }
                    else {
                      $('#info_div').hide();
                    }
                      $("#table_repreqs").html(data).show();
                  }
              });
            }
        });
      });
      $("#checkmaster").change(function() {
        var phone = $('#checkphone').val();
        var name = $('#checkname').val();
        var surname = $('#checksurname').val();
        var fname = $('#checkfname').val();
        var clientID = $('#checkclientID').val();
        var plate = $('#checkplate').val();
        var brand = $('#checkbrand').val();
        var model = $('#checkmodel').val();
        var carID = $('#checkcarID').val();
        var repreqID = $('#checkrepreqID').val();
        var checkdate = $('#checkdate').val();
        var checkmaster = $('#checkmaster').val();
        var checkmanager = $('#checkmanager').val();
        var checkstatus = $('#checkstatus').val();

        $.ajax({
            type: "POST",
            url: "../ajax/find/find_repreqs-cars.php",
            data: { 'phone' : phone,
                    'name' :name,
                    'surname' : surname,
                    'fname' :fname,
                    'clientID' : clientID,
                    'plate' :plate,
                    'brand' : brand,
                    'model' :model,
                    'carID' :carID,
                    'repreqID' : repreqID,
                    'checkdate' : checkdate,
                    'checkmaster' : checkmaster,
                    'checkmanager' : checkmanager,
                    'checkstatus' : checkstatus   },
            success: function(data) {
              var repreqIDhelp = get_cookie("Запрос_На_РемонтID");
              if (repreqIDhelp != null) {
                  $('#info_div').show();
              }
              else {
                $('#info_div').hide();
              }
              $("#table_cars").html(data).show();
              $.ajax({
                  type: "POST",
                  url: "../ajax/find/find_repreqs.php",
                  data: { 'phone' : phone,
                          'name' :name,
                          'surname' : surname,
                          'fname' :fname,
                          'clientID' : clientID,
                          'plate' :plate,
                          'brand' : brand,
                          'model' :model,
                          'carID' :carID,
                          'repreqID' : repreqID,
                          'checkdate' : checkdate,
                          'checkmaster' : checkmaster,
                          'checkmanager' : checkmanager,
                          'checkstatus' : checkstatus  },
                  success: function(data) {
                    var repreqIDhelp = get_cookie("Запрос_На_РемонтID");
                    if (repreqIDhelp != null) {
                        $('#info_div').show();
                        $.ajax({
                          type: "POST",
                          url: "../ajax/change/change_repreqs_finds/find_status.php",
                          data: { },
                          success: function(result) {
                            $('#info_Status').text(result);
                          }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../tables/repreqs-pieces_table.php",
                            data: {  },
                            success: function(result) {
                              $('#info_pieces').html(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../tables/repreqs-works_table.php",
                            data: {  },
                            success: function(result) {
                              $('#info_works').html(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_master_surname.php",
                            data: {  },
                            success: function(result) {
                              $('#info_master').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_manager_surname.php",
                            data: {  },
                            success: function(result) {
                              $('#info_manager').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_data.php",
                            data: {  },
                            success: function(result) {
                              $('#info_data').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_descfull.php",
                            data: {  },
                            success: function(result) {
                              $('#info_descfull').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_descsm.php",
                            data: {  },
                            success: function(result) {
                              $('#info_descsm').text(result);
                            }
                        });
                    }
                    else {
                      $('#info_div').hide();
                    }
                      $("#table_repreqs").html(data).show();
                  }
              });
            }
        });
      });
      $("#checkmanager").change(function() {
        var phone = $('#checkphone').val();
        var name = $('#checkname').val();
        var surname = $('#checksurname').val();
        var fname = $('#checkfname').val();
        var clientID = $('#checkclientID').val();
        var plate = $('#checkplate').val();
        var brand = $('#checkbrand').val();
        var model = $('#checkmodel').val();
        var carID = $('#checkcarID').val();
        var repreqID = $('#checkrepreqID').val();
        var checkdate = $('#checkdate').val();
        var checkmaster = $('#checkmaster').val();
        var checkmanager = $('#checkmanager').val();
        var checkstatus = $('#checkstatus').val();

        $.ajax({
            type: "POST",
            url: "../ajax/find/find_repreqs-cars.php",
            data: { 'phone' : phone,
                    'name' :name,
                    'surname' : surname,
                    'fname' :fname,
                    'clientID' : clientID,
                    'plate' :plate,
                    'brand' : brand,
                    'model' :model,
                    'carID' :carID,
                    'repreqID' : repreqID,
                    'checkdate' : checkdate,
                    'checkmaster' : checkmaster,
                    'checkmanager' : checkmanager,
                    'checkstatus' : checkstatus   },
            success: function(data) {
              var repreqIDhelp = get_cookie("Запрос_На_РемонтID");
              if (repreqIDhelp != null) {
                  $('#info_div').show();
              }
              else {
                $('#info_div').hide();
              }
              $("#table_cars").html(data).show();
              $.ajax({
                  type: "POST",
                  url: "../ajax/find/find_repreqs.php",
                  data: { 'phone' : phone,
                          'name' :name,
                          'surname' : surname,
                          'fname' :fname,
                          'clientID' : clientID,
                          'plate' :plate,
                          'brand' : brand,
                          'model' :model,
                          'carID' :carID,
                          'repreqID' : repreqID,
                          'checkdate' : checkdate,
                          'checkmaster' : checkmaster,
                          'checkmanager' : checkmanager,
                          'checkstatus' : checkstatus  },
                  success: function(data) {
                    var repreqIDhelp = get_cookie("Запрос_На_РемонтID");
                    if (repreqIDhelp != null) {
                        $('#info_div').show();
                        $.ajax({
                          type: "POST",
                          url: "../ajax/change/change_repreqs_finds/find_status.php",
                          data: { },
                          success: function(result) {
                            $('#info_Status').text(result);
                          }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../tables/repreqs-pieces_table.php",
                            data: {  },
                            success: function(result) {
                              $('#info_pieces').html(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../tables/repreqs-works_table.php",
                            data: {  },
                            success: function(result) {
                              $('#info_works').html(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_master_surname.php",
                            data: {  },
                            success: function(result) {
                              $('#info_master').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_manager_surname.php",
                            data: {  },
                            success: function(result) {
                              $('#info_manager').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_data.php",
                            data: {  },
                            success: function(result) {
                              $('#info_data').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_descfull.php",
                            data: {  },
                            success: function(result) {
                              $('#info_descfull').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_descsm.php",
                            data: {  },
                            success: function(result) {
                              $('#info_descsm').text(result);
                            }
                        });
                    }
                    else {
                      $('#info_div').hide();
                    }
                      $("#table_repreqs").html(data).show();
                  }
              });
            }
        });
      });
      $("#checkstatus").change(function() {
        var phone = $('#checkphone').val();
        var name = $('#checkname').val();
        var surname = $('#checksurname').val();
        var fname = $('#checkfname').val();
        var clientID = $('#checkclientID').val();
        var plate = $('#checkplate').val();
        var brand = $('#checkbrand').val();
        var model = $('#checkmodel').val();
        var carID = $('#checkcarID').val();
        var repreqID = $('#checkrepreqID').val();
        var checkdate = $('#checkdate').val();
        var checkmaster = $('#checkmaster').val();
        var checkmanager = $('#checkmanager').val();
        var checkstatus = $('#checkstatus').val();

        $.ajax({
            type: "POST",
            url: "../ajax/find/find_repreqs-cars.php",
            data: { 'phone' : phone,
                    'name' :name,
                    'surname' : surname,
                    'fname' :fname,
                    'clientID' : clientID,
                    'plate' :plate,
                    'brand' : brand,
                    'model' :model,
                    'carID' :carID,
                    'repreqID' : repreqID,
                    'checkdate' : checkdate,
                    'checkmaster' : checkmaster,
                    'checkmanager' : checkmanager,
                    'checkstatus' : checkstatus   },
            success: function(data) {
              var repreqIDhelp = get_cookie("Запрос_На_РемонтID");
              if (repreqIDhelp != null) {
                  $('#info_div').show();
              }
              else {
                $('#info_div').hide();
              }
              $("#table_cars").html(data).show();
              $.ajax({
                  type: "POST",
                  url: "../ajax/find/find_repreqs.php",
                  data: { 'phone' : phone,
                          'name' :name,
                          'surname' : surname,
                          'fname' :fname,
                          'clientID' : clientID,
                          'plate' :plate,
                          'brand' : brand,
                          'model' :model,
                          'carID' :carID,
                          'repreqID' : repreqID,
                          'checkdate' : checkdate,
                          'checkmaster' : checkmaster,
                          'checkmanager' : checkmanager,
                          'checkstatus' : checkstatus  },
                  success: function(data) {
                    var repreqIDhelp = get_cookie("Запрос_На_РемонтID");
                    if (repreqIDhelp != null) {
                        $('#info_div').show();
                        $.ajax({
                          type: "POST",
                          url: "../ajax/change/change_repreqs_finds/find_status.php",
                          data: { },
                          success: function(result) {
                            $('#info_Status').text(result);
                          }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../tables/repreqs-pieces_table.php",
                            data: {  },
                            success: function(result) {
                              $('#info_pieces').html(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../tables/repreqs-works_table.php",
                            data: {  },
                            success: function(result) {
                              $('#info_works').html(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_master_surname.php",
                            data: {  },
                            success: function(result) {
                              $('#info_master').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_manager_surname.php",
                            data: {  },
                            success: function(result) {
                              $('#info_manager').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_data.php",
                            data: {  },
                            success: function(result) {
                              $('#info_data').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_descfull.php",
                            data: {  },
                            success: function(result) {
                              $('#info_descfull').text(result);
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "../ajax/change/change_repreqs_finds/find_descsm.php",
                            data: {  },
                            success: function(result) {
                              $('#info_descsm').text(result);
                            }
                        });
                    }
                    else {
                      $('#info_div').hide();
                    }
                      $("#table_repreqs").html(data).show();
                  }
              });
            }
        });
      });

      $('#exit_btn').click(function () {
        $.ajax({
          url: '../ajax/exit.php',
          type: 'POST',
          cache: false,
          data: {},
          dataType: 'html',
          success: function (data) {
            document.location.reload(true);
          }
        });
      });

      $('#del_btn').click(function() {
        $.ajax({
            type: "POST",
            url: "../ajax/delete/delete_repreqs.php",
            data: {},
            success: function(data) {
                if (data == 'Все готово') {
                  if (document.getElementById("new_form") != null) {
                    document.getElementById("new_form").reset();
                  }
                  if (document.getElementById("find_repreq") != null) {
                    document.getElementById("find_repreq").reset();
                  }
                  $('#delete_errorBlock').hide();
                  $('#delete_successBlock').text("Заказ успешно удален").show();
                  $(function(){
      	             $("#delete_successBlock").delay(3000).slideUp(300);
                  });
                  $('#info_div').hide();
                  $.ajax({
                      type: "POST",
                      url: "../tables/cars_table.php",
                      data: { },
                      success: function(result) {
                          $("#table_cars").html(result).show();
                      }
                  });
                  $.ajax({
                      type: "POST",
                      url: "../tables/repreqs_table.php",
                      data: { },
                      success: function(result) {
                          $("#table_repreqs").html(result).show();
                      }
                  });
                }
                else {
                  $('#delete_errorBlock').show();
                  $(function(){
                     $("#delete_errorBlock").delay(5000).slideUp(300);
                   });
                  $('#delete_errorBlock').text(data);
                }
            }
        });
      })
      </script>
</body>
</html>
