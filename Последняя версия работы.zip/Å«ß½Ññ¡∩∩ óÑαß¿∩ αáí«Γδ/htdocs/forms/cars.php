<!DOCTYPE html>
<html lang="ru">
<head>
  <?php
    $website_title = 'ИС.Автомобили';
    require '../blocks/head.php';
  ?>
</head>
<body class="bg-light text-start">
  <?php
  if($_COOKIE['СотрудникID'] == '') {
    header("Location: ../auth.php");
  }
  if($_COOKIE['КлиентIDhelp'] != '') {
    require '../mysql_connect.php';
    $sql = 'SELECT * FROM клиенты WHERE клиенты.КлиентID = :id && клиенты.Видимость = :vis';
    $query = $pdo->prepare($sql);
    $query->execute(['id' => $_COOKIE['КлиентIDhelp'],  'vis' => 1]);
    $users = $query->fetch(PDO::FETCH_ASSOC);
    setcookie('КлиентIDhelp', $clientid, time() - 3600 * 24, "/");
  }
  ?>
  <header class="container d-flex flex-column flex-md-row align-items-center p-3 px-md-6 mb-3 bg-body border-bottom shadow-sm">
    <div class="mt-1 mb-1 my-0 me-md-auto fw-normal text-start">Форма: Автомобили</div>
    <a class="p-2 text-dark me-4" href="../index.php">На главную</a>
    <button class="btn btn-outline-primary" id="exit_btn">Выйти</button>
  </header>
  <main class="container mt-5">
    <div class="row">
      <div class="col-md-10">
        <form id="change_form">
          <div class="row mb-3 text-center rounded-3 shadow">
            <div class="row">
              <div class="col-md-5 text-start mt-3">
              <h2 class="h4 fw-normal mb-3">Изменение данных автомобиля</h2>
              </div>
              <div class="col-md-5 text-end">
              </div>
            </div>
            <div class="col-md-2">
              <input type="text" name="changeclientID" id="changeclientID" class="mt-3 mx-auto form-control" value="" placeholder="КлиентID">
              <input type="text" name="changeVIN" id="changeVIN" class="mt-3 mx-auto form-control" placeholder="VIN" maxlength="17">
            </div>
            <div class="col-md-2">
              <input type="text" name="changeplate" id="changeplate" class="mt-3 mx-auto form-control" placeholder="НомерТС" maxlength="9">
              <input type="text" name="changeyear" id="changeyear" class="mt-3 mx-auto form-control" placeholder="Год выпуска" maxlength="4">
            </div>
            <div class="col-md-2">
              <input type="text" name="changebrand" id="changebrand" class="mt-3 mx-auto form-control" placeholder="Марка">
              <input type="text" name="changemodel" id="changemodel" class="mt-3 mx-auto form-control" placeholder="Модель">
            </div>
            <div class="col-md-2">
              <input type="text" name="changeCTCser" id="changeCTCser" class="mt-3 mx-auto form-control" placeholder="Серия СТС" maxlength="4">
              <input type="text" name="changeCTCnum" id="changeCTCnum" class="mt-3 mb-3 mx-auto form-control" placeholder="Номер СТС" maxlength="6">
            </div>
          </div>
        </form>
        <form id="new_form">
          <h2 class="h4 fw-normal mb-3">Поиск/добавление автомобиля </h2>
          <div class="row text-start">
            <div class="col-md-2">
              <input type="text" name="checkdate" id="checkdate" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="Дата регистрации">
              <input type="text" name="checkplate" id="checkplate" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="НомерТС" maxlength="9">
              <input type="text" name="checksurname" id="checksurname" class="mt-3 mb-3 w-100 mx-auto form-control" placeholder="Фамииля" value="<?php echo $users['Фамилия']; ?>">
            </div>
            <div class="col-md-2">
              <input type="text" name="checkVIN" id="checkVIN" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="VIN" maxlength="17">
              <input type="text" name="checkyear" id="checkyear" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="Год выпуска" maxlength="4">
              <input type="text" name="checkname" id="checkname" class="mt-3  w-100 mx-auto form-control" placeholder="Имя" value="<?php echo $users['Имя']; ?>">
            </div>
            <div class="col-md-2">
              <input type="text" name="checkbrand" id="checkbrand" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="Марка">
              <input type="text" name="checkmodel" id="checkmodel" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="Модель">
              <input type="text" name="checkfname" id="checkfname" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="Отчество" value="<?php echo $users['Отчество']; ?>">
            </div>
            <div class="col-md-2">
              <input type="text" name="checkCTCser" id="checkCTCser" class="mt-3  w-100 mx-auto form-control" placeholder="Серия СТС" maxlength="4">
              <input type="text" name="checkCTCnum" id="checkCTCnum" class="mt-3  w-100 mx-auto form-control" placeholder="Номер СТС" maxlength="6">
              <input type="text" name="checkphone" id="checkphone" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="Телефон" maxlength="12" value="<?php echo $users['Телефон']; ?>">
            </div>
            <div class="col-md-2">
              <input type="text" name="checkcarID" id="checkcarID" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="МашинаID">
              <input type="text" name="checkclientID" id="checkclientID" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="КлиентID" value="<?php echo $users['КлиентID']; ?>">
            </div>
            </div>
        </form>
        <div class="shadow mt-1" id="table_cars">
          <?php require  '../tables/cars_table.php'; ?>
        </div>
        <div class="shadow mt-4" id="table_clients">
          <?php require '../tables/clients_table.php'; ?>
        </div>
      </div>
      <div class="col-md-2">
          <button type="button" id="reset_btn" class=" mb-2 w-100 mx-auto btn btn-outline-primary">Очистить фильтр</button>
          <button class="w-100 btn btn-lg btn-primary mt-3" id="new_save_btn" type="button">Сохранить</button>
          <button class="w-100 btn btn-lg btn-primary mt-3" id="new_back_btn" type="button">Назад</button>
          <button class="w-100 btn btn-lg btn-primary mt-3" id="change_save_btn" type="button">Сохранить</button>
          <button class="w-100 btn btn-lg btn-primary mt-3" id="change_back_btn" type="button">Назад</button>
          <div class="alert alert-primary alert-dismissible fade show mt-2 h-auto" id="change_successBlock" role="alert"></div>
          <div class="h-auto alert alert-danger mt-2 text-start" role="alert" id="change_errorBlock"></div>
          <button class="w-100 btn btn-lg btn-primary mt-3" id="new_btn" type="button">Добавить</button>
          <div class="alert alert-primary alert-dismissible fade show mt-2 h-auto" id="new_successBlock" role="alert"></div>
          <div class="h-auto alert alert-danger mt-2 text-start" role="alert" id="new_errorBlock"></div>
          <button class="w-100 btn btn-lg btn-primary mt-3" id="change_btn" type="button">Изменить</button>
          <div class="h-auto alert alert-danger mt-2 text-start" role="alert" id="change_errorBlock1"></div>
          <button class="w-100 btn btn-lg btn-primary mt-3" id="del_btn" type="button">Удалить</button>
          <div class="h-auto alert alert-danger mt-2 text-start" role="alert" id="delete_errorBlock"></div>
          <div class="alert alert-primary alert-dismissible fade show mt-2 h-auto" id="delete_successBlock" role="alert"></div>
          <button class="w-100 btn btn btn-success mt-3" id="new_sugg_btn" type="button">Добавить заявку на ремонт</button>
        </div>
      </div>
  </main>
  <script>
    function get_cookie ( cookie_name ) {
      var results = document.cookie.match ( '(^|;) ?' + cookie_name + '=([^;]*)(;|$)' );

      if ( results )
       return ( unescape ( results[2] ) );
      else
       return null;
    }
    $(document).ready(function () {
      var checkplate = $('#checkplate').val();
      var checkVIN = $('#checkVIN').val();
      var checksurname = $('#checksurname').val();
      var checkyear = $('#checkyear').val();
      var checkdate = $('#checkdate').val();
      var checkname = $('#checkname').val();
      var checkbrand = $('#checkbrand').val();
      var checkmodel = $('#checkmodel').val();
      var checkfname = $('#checkfname').val();
      var checkCTCser = $('#checkCTCser').val();
      var checkCTCnum = $('#checkCTCnum').val();
      var checkphone = $('#checkphone').val();
      var checkcarID = $('#checkcarID').val();
      var checkclientID = $('#checkclientID').val();
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
              $("#table_cars").html(data).show();
          }
      });
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars-clients.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
              $("#table_clients").html(data).show();
          }
      });
    });

    $('#new_sugg_btn').click(function() {
      var autoid = get_cookie("АвтомобильID");
      $.ajax({
        type: "POST",
        url: "../redirects/cars-repreqs.php",
        data: { 'autoid' : autoid },
        success: function(data) {
          window.location.href='reprequests.php';
          document.getElementById("new_form").reset();
          document.getElementById("change_form").reset();
        }
      });
    });

    $('#new_repreq_btn').click(function() {
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cookie.php",
          data: { },
          success: function(data) {
              if (data == "cookie найдены") {
                document.getElementById("new_form").reset();
                document.getElementById("find_form").reset();
                window.location.href = 'reprequests.php';
              }
              else {
                $('#new_repreq_errorBlock').show();
                $(function(){
                   $("#new_repreq_errorBlock").delay(5000).slideUp(300);
                 });
              }
          }
      });
    });

    $('#reset_btn').click(function() {
      document.getElementById("new_form").reset();
      $.ajax({
          type: "POST",
          url: "../tables/cars_table.php",
          data: { },
          success: function(data) {
            var autoid = get_cookie("АвтомобильID");
            if (autoid != null) {
                $('#new_sugg_btn').show();
            }
            else {
              $('#new_sugg_btn').hide();
            }
              $("#table_cars").html(data).show();
          }
      });
      $.ajax({
          type: "POST",
          url: "../tables/clients_table.php",
          data: { },
          success: function(data) {
              $("#table_clients").html(data).show();
          }
      });
    });

    $('#checkCTCser').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9]/)){
        return false;
      };
    })
    $('#checkCTCnum').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9]/)){
        return false;
      };
    })
    $('#checkclientID').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9]/)){
        return false;
      };
    })
    $('#checkyear').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9]/)){
        return false;
      };
    })
    $('#checkVIN').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9^A-Z]/)){
        return false;
      };
    })
    $('#checkplate').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9^[АВЕКМНОРСТУХ]/)){
        return false;
      };
    })
    $('#checkcarID').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9]/)){
        return false;
      };
    })
    $('#checkdate').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9-: ]/)){
        return false;
      };
    })
    $('#checkphone').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9+]/)){
        return false;
      };
    })
    $('#checkname').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[a-zA-Z \\u0400-\\u04FF]/)){
        return false;
      };
    })
    $('#checksurname').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[a-zA-Z \\u0400-\\u04FF]/)){
        return false;
      };
    })
    $('#checkfname').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[a-zA-Z \\u0400-\\u04FF]/)){
        return false;
      };
    })

    $('#changeCTCser').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9]/)){
        return false;
      };
    })
    $('#changeCTCnum').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9]/)){
        return false;
      };
    })
    $('#changeclientID').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9]/)){
        return false;
      };
    })
    $('#changeyear').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9]/)){
        return false;
      };
    })
    $('#changeVIN').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9^A-Z]/)){
        return false;
      };
    })
    $('#changeplate').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9^[АВЕКМНОРСТУХ]/)){
        return false;
      };
    })
    $('#changecarID').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9]/)){
        return false;
      };
    })
    $('#changedate').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9-: ]/)){
        return false;
      };
    })

    $("#checkplate").keyup(function() {
      var checkplate = $('#checkplate').val();
      var checkVIN = $('#checkVIN').val();
      var checksurname = $('#checksurname').val();
      var checkyear = $('#checkyear').val();
      var checkdate = $('#checkdate').val();
      var checkname = $('#checkname').val();
      var checkbrand = $('#checkbrand').val();
      var checkmodel = $('#checkmodel').val();
      var checkfname = $('#checkfname').val();
      var checkCTCser = $('#checkCTCser').val();
      var checkCTCnum = $('#checkCTCnum').val();
      var checkphone = $('#checkphone').val();
      var checkcarID = $('#checkcarID').val();
      var checkclientID = $('#checkclientID').val();
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
            var autoid = get_cookie("АвтомобильID");
            if (autoid != null) {
                $('#new_sugg_btn').show();
            }
            else {
              $('#new_sugg_btn').hide();
            }
            $("#table_cars").html(data).show();
          }
      });
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars-clients.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
              $("#table_clients").html(data).show();
          }
      });
    });
    $("#checkVIN").keyup(function() {
      var checkplate = $('#checkplate').val();
      var checkVIN = $('#checkVIN').val();
      var checksurname = $('#checksurname').val();
      var checkyear = $('#checkyear').val();
      var checkdate = $('#checkdate').val();
      var checkname = $('#checkname').val();
      var checkbrand = $('#checkbrand').val();
      var checkmodel = $('#checkmodel').val();
      var checkfname = $('#checkfname').val();
      var checkCTCser = $('#checkCTCser').val();
      var checkCTCnum = $('#checkCTCnum').val();
      var checkphone = $('#checkphone').val();
      var checkcarID = $('#checkcarID').val();
      var checkclientID = $('#checkclientID').val();
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
            var autoid = get_cookie("АвтомобильID");
            if (autoid != null) {
                $('#new_sugg_btn').show();
            }
            else {
              $('#new_sugg_btn').hide();
            }
            $("#table_cars").html(data).show();
          }
      });
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars-clients.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
              $("#table_clients").html(data).show();
          }
      });
    });
    $("#checksurname").keyup(function() {
      var checkplate = $('#checkplate').val();
      var checkVIN = $('#checkVIN').val();
      var checksurname = $('#checksurname').val();
      var checkyear = $('#checkyear').val();
      var checkdate = $('#checkdate').val();
      var checkname = $('#checkname').val();
      var checkbrand = $('#checkbrand').val();
      var checkmodel = $('#checkmodel').val();
      var checkfname = $('#checkfname').val();
      var checkCTCser = $('#checkCTCser').val();
      var checkCTCnum = $('#checkCTCnum').val();
      var checkphone = $('#checkphone').val();
      var checkcarID = $('#checkcarID').val();
      var checkclientID = $('#checkclientID').val();
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
            var autoid = get_cookie("АвтомобильID");
            if (autoid != null) {
                $('#new_sugg_btn').show();
            }
            else {
              $('#new_sugg_btn').hide();
            }
            $("#table_cars").html(data).show();
          }
      });
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars-clients.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
              $("#table_clients").html(data).show();
          }
      });
    });
    $("#checkyear").keyup(function() {
      var checkplate = $('#checkplate').val();
      var checkVIN = $('#checkVIN').val();
      var checksurname = $('#checksurname').val();
      var checkyear = $('#checkyear').val();
      var checkdate = $('#checkdate').val();
      var checkname = $('#checkname').val();
      var checkbrand = $('#checkbrand').val();
      var checkmodel = $('#checkmodel').val();
      var checkfname = $('#checkfname').val();
      var checkCTCser = $('#checkCTCser').val();
      var checkCTCnum = $('#checkCTCnum').val();
      var checkphone = $('#checkphone').val();
      var checkcarID = $('#checkcarID').val();
      var checkclientID = $('#checkclientID').val();
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
            var autoid = get_cookie("АвтомобильID");
            if (autoid != null) {
                $('#new_sugg_btn').show();
            }
            else {
              $('#new_sugg_btn').hide();
            }
            $("#table_cars").html(data).show();
          }
      });
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars-clients.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
              $("#table_clients").html(data).show();
          }
      });
    });
    $("#checkdate").keyup(function() {
      var checkplate = $('#checkplate').val();
      var checkVIN = $('#checkVIN').val();
      var checksurname = $('#checksurname').val();
      var checkyear = $('#checkyear').val();
      var checkdate = $('#checkdate').val();
      var checkname = $('#checkname').val();
      var checkbrand = $('#checkbrand').val();
      var checkmodel = $('#checkmodel').val();
      var checkfname = $('#checkfname').val();
      var checkCTCser = $('#checkCTCser').val();
      var checkCTCnum = $('#checkCTCnum').val();
      var checkphone = $('#checkphone').val();
      var checkcarID = $('#checkcarID').val();
      var checkclientID = $('#checkclientID').val();
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
            var autoid = get_cookie("АвтомобильID");
            if (autoid != null) {
                $('#new_sugg_btn').show();
            }
            else {
              $('#new_sugg_btn').hide();
            }
            $("#table_cars").html(data).show();
          }
      });
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars-clients.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
              $("#table_clients").html(data).show();
          }
      });
    });
    $("#checkname").keyup(function() {
      var checkplate = $('#checkplate').val();
      var checkVIN = $('#checkVIN').val();
      var checksurname = $('#checksurname').val();
      var checkyear = $('#checkyear').val();
      var checkdate = $('#checkdate').val();
      var checkname = $('#checkname').val();
      var checkbrand = $('#checkbrand').val();
      var checkmodel = $('#checkmodel').val();
      var checkfname = $('#checkfname').val();
      var checkCTCser = $('#checkCTCser').val();
      var checkCTCnum = $('#checkCTCnum').val();
      var checkphone = $('#checkphone').val();
      var checkcarID = $('#checkcarID').val();
      var checkclientID = $('#checkclientID').val();
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
            var autoid = get_cookie("АвтомобильID");
            if (autoid != null) {
                $('#new_sugg_btn').show();
            }
            else {
              $('#new_sugg_btn').hide();
            }
            $("#table_cars").html(data).show();
          }
      });
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars-clients.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
              $("#table_clients").html(data).show();
          }
      });
    });
    $("#checkbrand").keyup(function() {
      var checkplate = $('#checkplate').val();
      var checkVIN = $('#checkVIN').val();
      var checksurname = $('#checksurname').val();
      var checkyear = $('#checkyear').val();
      var checkdate = $('#checkdate').val();
      var checkname = $('#checkname').val();
      var checkbrand = $('#checkbrand').val();
      var checkmodel = $('#checkmodel').val();
      var checkfname = $('#checkfname').val();
      var checkCTCser = $('#checkCTCser').val();
      var checkCTCnum = $('#checkCTCnum').val();
      var checkphone = $('#checkphone').val();
      var checkcarID = $('#checkcarID').val();
      var checkclientID = $('#checkclientID').val();
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
            var autoid = get_cookie("АвтомобильID");
            if (autoid != null) {
                $('#new_sugg_btn').show();
            }
            else {
              $('#new_sugg_btn').hide();
            }
            $("#table_cars").html(data).show();
          }
      });
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars-clients.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
              $("#table_clients").html(data).show();
          }
      });
    });
    $("#checkmodel").keyup(function() {
      var checkplate = $('#checkplate').val();
      var checkVIN = $('#checkVIN').val();
      var checksurname = $('#checksurname').val();
      var checkyear = $('#checkyear').val();
      var checkdate = $('#checkdate').val();
      var checkname = $('#checkname').val();
      var checkbrand = $('#checkbrand').val();
      var checkmodel = $('#checkmodel').val();
      var checkfname = $('#checkfname').val();
      var checkCTCser = $('#checkCTCser').val();
      var checkCTCnum = $('#checkCTCnum').val();
      var checkphone = $('#checkphone').val();
      var checkcarID = $('#checkcarID').val();
      var checkclientID = $('#checkclientID').val();
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
            var autoid = get_cookie("АвтомобильID");
            if (autoid != null) {
                $('#new_sugg_btn').show();
            }
            else {
              $('#new_sugg_btn').hide();
            }
            $("#table_cars").html(data).show();
          }
      });
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars-clients.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
              $("#table_clients").html(data).show();
          }
      });
    });
    $("#checkfname").keyup(function() {
      var checkplate = $('#checkplate').val();
      var checkVIN = $('#checkVIN').val();
      var checksurname = $('#checksurname').val();
      var checkyear = $('#checkyear').val();
      var checkdate = $('#checkdate').val();
      var checkname = $('#checkname').val();
      var checkbrand = $('#checkbrand').val();
      var checkmodel = $('#checkmodel').val();
      var checkfname = $('#checkfname').val();
      var checkCTCser = $('#checkCTCser').val();
      var checkCTCnum = $('#checkCTCnum').val();
      var checkphone = $('#checkphone').val();
      var checkcarID = $('#checkcarID').val();
      var checkclientID = $('#checkclientID').val();
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
            var autoid = get_cookie("АвтомобильID");
            if (autoid != null) {
                $('#new_sugg_btn').show();
            }
            else {
              $('#new_sugg_btn').hide();
            }
            $("#table_cars").html(data).show();
          }
      });
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars-clients.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
              $("#table_clients").html(data).show();
          }
      });
    });
    $("#checkCTCser").keyup(function() {
      var checkplate = $('#checkplate').val();
      var checkVIN = $('#checkVIN').val();
      var checksurname = $('#checksurname').val();
      var checkyear = $('#checkyear').val();
      var checkdate = $('#checkdate').val();
      var checkname = $('#checkname').val();
      var checkbrand = $('#checkbrand').val();
      var checkmodel = $('#checkmodel').val();
      var checkfname = $('#checkfname').val();
      var checkCTCser = $('#checkCTCser').val();
      var checkCTCnum = $('#checkCTCnum').val();
      var checkphone = $('#checkphone').val();
      var checkcarID = $('#checkcarID').val();
      var checkclientID = $('#checkclientID').val();
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
            var autoid = get_cookie("АвтомобильID");
            if (autoid != null) {
                $('#new_sugg_btn').show();
            }
            else {
              $('#new_sugg_btn').hide();
            }
            $("#table_cars").html(data).show();
          }
      });
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars-clients.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
              $("#table_clients").html(data).show();
          }
      });
    });
    $("#checkCTCnum").keyup(function() {
      var checkplate = $('#checkplate').val();
      var checkVIN = $('#checkVIN').val();
      var checksurname = $('#checksurname').val();
      var checkyear = $('#checkyear').val();
      var checkdate = $('#checkdate').val();
      var checkname = $('#checkname').val();
      var checkbrand = $('#checkbrand').val();
      var checkmodel = $('#checkmodel').val();
      var checkfname = $('#checkfname').val();
      var checkCTCser = $('#checkCTCser').val();
      var checkCTCnum = $('#checkCTCnum').val();
      var checkphone = $('#checkphone').val();
      var checkcarID = $('#checkcarID').val();
      var checkclientID = $('#checkclientID').val();
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
            var autoid = get_cookie("АвтомобильID");
            if (autoid != null) {
                $('#new_sugg_btn').show();
            }
            else {
              $('#new_sugg_btn').hide();
            }
            $("#table_cars").html(data).show();
          }
      });
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars-clients.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
              $("#table_clients").html(data).show();
          }
      });
    });
    $("#checkphone").keyup(function() {
      var checkplate = $('#checkplate').val();
      var checkVIN = $('#checkVIN').val();
      var checksurname = $('#checksurname').val();
      var checkyear = $('#checkyear').val();
      var checkdate = $('#checkdate').val();
      var checkname = $('#checkname').val();
      var checkbrand = $('#checkbrand').val();
      var checkmodel = $('#checkmodel').val();
      var checkfname = $('#checkfname').val();
      var checkCTCser = $('#checkCTCser').val();
      var checkCTCnum = $('#checkCTCnum').val();
      var checkphone = $('#checkphone').val();
      var checkcarID = $('#checkcarID').val();
      var checkclientID = $('#checkclientID').val();
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
            var autoid = get_cookie("АвтомобильID");
            if (autoid != null) {
                $('#new_sugg_btn').show();
            }
            else {
              $('#new_sugg_btn').hide();
            }
            $("#table_cars").html(data).show();
          }
      });
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars-clients.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
              $("#table_clients").html(data).show();
          }
      });
    });
    $("#checkcarID").keyup(function() {
      var checkplate = $('#checkplate').val();
      var checkVIN = $('#checkVIN').val();
      var checksurname = $('#checksurname').val();
      var checkyear = $('#checkyear').val();
      var checkdate = $('#checkdate').val();
      var checkname = $('#checkname').val();
      var checkbrand = $('#checkbrand').val();
      var checkmodel = $('#checkmodel').val();
      var checkfname = $('#checkfname').val();
      var checkCTCser = $('#checkCTCser').val();
      var checkCTCnum = $('#checkCTCnum').val();
      var checkphone = $('#checkphone').val();
      var checkcarID = $('#checkcarID').val();
      var checkclientID = $('#checkclientID').val();
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
            var autoid = get_cookie("АвтомобильID");
            if (autoid != null) {
                $('#new_sugg_btn').show();
            }
            else {
              $('#new_sugg_btn').hide();
            }
            $("#table_cars").html(data).show();
          }
      });
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars-clients.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
              $("#table_clients").html(data).show();
          }
      });
    });
    $("#checkclientID").keyup(function() {
      var checkplate = $('#checkplate').val();
      var checkVIN = $('#checkVIN').val();
      var checksurname = $('#checksurname').val();
      var checkyear = $('#checkyear').val();
      var checkdate = $('#checkdate').val();
      var checkname = $('#checkname').val();
      var checkbrand = $('#checkbrand').val();
      var checkmodel = $('#checkmodel').val();
      var checkfname = $('#checkfname').val();
      var checkCTCser = $('#checkCTCser').val();
      var checkCTCnum = $('#checkCTCnum').val();
      var checkphone = $('#checkphone').val();
      var checkcarID = $('#checkcarID').val();
      var checkclientID = $('#checkclientID').val();
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
            var autoid = get_cookie("АвтомобильID");
            if (autoid != null) {
                $('#new_sugg_btn').show();
            }
            else {
              $('#new_sugg_btn').hide();
            }
            $("#table_cars").html(data).show();
          }
      });
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_cars-clients.php",
          data: { 'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID },
          success: function(data) {
              $("#table_clients").html(data).show();
          }
      });
    });

    $('#exit_btn').click(function () {
      $.ajax({
        url: '../ajax/exit.php',
        type: 'POST',
        cache: false,
        data: {},
        dataType: 'html',
        success: function (data) {
          document.location.reload(true);
        }
      });
    });

    $('#new_btn').click(function () {
      var checkplate = $('#checkplate').val();
      var checkVIN = $('#checkVIN').val();
      var checksurname = $('#checksurname').val();
      var checkyear = $('#checkyear').val();
      var checkdate = $('#checkdate').val();
      var checkname = $('#checkname').val();
      var checkbrand = $('#checkbrand').val();
      var checkmodel = $('#checkmodel').val();
      var checkfname = $('#checkfname').val();
      var checkCTCser = $('#checkCTCser').val();
      var checkCTCnum = $('#checkCTCnum').val();
      var checkphone = $('#checkphone').val();
      var checkcarID = $('#checkcarID').val();
      var checkclientID = $('#checkclientID').val();
      var check = 1;

      if(!checkplate.match(/^[АВЕКМНОРСТУХ]\d{3}[АВЕКМНОРСТУХ]{2}\d{2,3}$/)) {
        $('#new_errorBlock').show();
        $('#new_errorBlock').text('НомерТС введен некорректно');
        $(function(){
           $("#new_errorBlock").delay(3000).slideUp(300);
        });
        check = 0;
      }
      if (check == 1) {
        $.ajax({
          url: '../ajax/new/new_cars.php',
          type: 'POST',
          cache: false,
          data: {'checkplate' : checkplate,
                  'checkVIN' : checkVIN,
                  'checksurname' : checksurname,
                  'checkyear' : checkyear,
                  'checkdate' : checkdate,
                  'checkname' : checkname,
                  'checkbrand' : checkbrand,
                  'checkmodel' : checkmodel,
                  'checkfname' : checkfname,
                  'checkCTCser' : checkCTCser,
                  'checkCTCnum' : checkCTCnum,
                  'checkphone' : checkphone,
                  'checkcarID' : checkcarID,
                  'checkclientID' : checkclientID},
          dataType: 'html',
          success: function (data) {
            if(data == 'Все готово') {
              $('#new_errorBlock').hide();
              $('#new_successBlock').text("Автомобиль успешно добавлен").show();
              $(function(){
  	             $("#new_successBlock").delay(3000).slideUp(300);
              });
              $.ajax({
                  type: "POST",
                  url: "../ajax/find/find_cars.php",
                  data: { 'checkplate' : checkplate,
                          'checkVIN' : checkVIN,
                          'checksurname' : checksurname,
                          'checkyear' : checkyear,
                          'checkdate' : checkdate,
                          'checkname' : checkname,
                          'checkbrand' : checkbrand,
                          'checkmodel' : checkmodel,
                          'checkfname' : checkfname,
                          'checkCTCser' : checkCTCser,
                          'checkCTCnum' : checkCTCnum,
                          'checkphone' : checkphone,
                          'checkcarID' : checkcarID,
                          'checkclientID' : checkclientID },
                  success: function(data) {
                      $("#table_cars").html(data).show();
                  }
              });
             }
            else {
              $('#new_errorBlock').show();
              $(function(){
                 $("#new_errorBlock").delay(5000).slideUp(300);
               });
              $('#new_errorBlock').text(data);
            }
          }
      });
      }
    });

    $('#change_btn').click(function() {
      $.ajax({
          type: "POST",
          url: "../ajax/find_cookies/cookies_cars.php",
          data: { },
          success: function(data) {
              if (data == "cookie автомобиля найдены") {
                $('#new_form').hide();
                $('#new_btn').hide();
                $('#change_btn').hide();
                $('#del_btn').hide();
                $('#reset_btn').hide();
                $('#change_form').show();
                $('#change_save_btn').show();
                $('#change_back_btn').show();
              }
              else {
                $('#change_errorBlock1').show();
                $(function(){
                   $("#change_errorBlock1").delay(5000).slideUp(300);
                 });
                $('#change_errorBlock1').text(data);
              }
          }
      });
    });
    $('#change_back_btn').click(function() {
      $('#new_form').show();
      $('#new_btn').show();
      $('#change_btn').show();
      $('#del_btn').show();
      $('#reset_btn').show();
      $('#change_form').hide();
      $('#change_save_btn').hide();
      $('#change_back_btn').hide();
    });
    $('#change_save_btn').click(function() {
      var changeclientID = $('#changeclientID').val();
      var changeVIN = $('#changeVIN').val();
      var changeplate = $('#changeplate').val();
      var changeyear = $('#changeyear').val();
      var changebrand = $('#changebrand').val();
      var changemodel = $('#changemodel').val();
      var changeCTCser = $('#changeCTCser').val();
      var changeCTCnum = $('#changeCTCnum').val();

      $.ajax({
          type: "POST",
          url: "../ajax/change/change_cars.php",
          data: { 'changeclientID' : changeclientID,
                  'changeVIN' : changeVIN,
                  'changeplate' : changeplate,
                  'changeyear' : changeyear,
                  'changebrand' : changebrand,
                  'changemodel' : changemodel,
                  'changeCTCser' : changeCTCser,
                  'changeCTCnum' : changeCTCnum },
          success: function(data) {
              if (data == 'Все готово') {
                document.getElementById("change_form").reset();
                document.getElementById("new_form").reset();
                $('#change_errorBlock').hide();
                $('#change_successBlock').text("Данные автомобиля успешно обновленны!").show();
                $(function(){
    	             $("#change_successBlock").delay(3000).slideUp(300);
                });
                $.ajax({
                    type: "POST",
                    url: "../tables/cars_table.php",
                    data: { },
                    success: function(data) {
                        $("#table_cars").html(data).show();
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "../tables/clients_table.php",
                    data: { },
                    success: function(data) {
                        $("#table_clients").html(data).show();
                    }
                });
                $('#new_form').show();
                $('#new_btn').show();
                $('#change_btn').show();
                $('#del_btn').show();
                $('#reset_btn').show();
                $('#change_form').hide();
                $('#change_save_btn').hide();
                $('#change_back_btn').hide();
              }
              else {
                $('#change_errorBlock').show();
                $(function(){
                   $("#change_errorBlock").delay(5000).slideUp(300);
                 });
                $('#change_errorBlock').text(data);
            }
          }
      });
    });

    $('#del_btn').click(function() {
      $.ajax({
          type: "POST",
          url: "../ajax/delete/delete_cars.php",
          data: {},
          success: function(result) {
              if (result == 'Все готово') {
                document.getElementById("new_form").reset();
                $('#delete_errorBlock').hide();
                $('#delete_successBlock').text("Машина успешно удалена").show();
                $(function(){
                   $("#delete_successBlock").delay(3000).slideUp(300);
                });
                $.ajax({
                    type: "POST",
                    url: "../tables/cars_table.php",
                    data: { },
                    success: function(result) {
                        $("#table_cars").html(result).show();
                    }
                });
              }
              else {
                $('#delete_errorBlock').show();
                $(function(){
                   $("#delete_errorBlock").delay(5000).slideUp(300);
                 });
                $('#delete_errorBlock').text(result);
              }
          }
      });
    })
  </script>
</body>
</html>
