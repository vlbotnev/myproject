<!DOCTYPE html>
<html lang="ru">
<head>
  <?php
    $website_title = 'ИС.ЗавкиПокупка';
    require '../blocks/head.php';
  ?>
</head>
<body class="bg-light text-start">
  <?php
  if($_COOKIE['СотрудникID'] == '') {
    header("Location: ../auth.php");
  }
  ?>
  <header class="container d-flex flex-column flex-md-row align-items-center p-3 px-md-6 mb-3 bg-body border-bottom shadow-sm">
    <div class="mt-1 mb-1 my-0 me-md-auto fw-normal text-start">Форма: Заявки на покупку</div>
    <a class="p-2 text-dark me-4" href="../index.php">На главную</a>
    <button class="btn btn-outline-primary" id="exit_btn">Выйти</button>
  </header>
  <main class="container mt-4">
    <div class="row">
      <div class="col-md-10">
        <form id="change_form" >
          <div class="row text-center rounded-3 shadow">
            <h2 class="h4 fw-normal mb-3 text-start mt-3">Изменение данных заявки </h2>
            <div class="col-md-2">
              <input type="text" name="changesurname" id="changesurname" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="Фамилия">
              <input type="text" name="changename" id="changename" class="mt-3 mb-4 form-control w-100 mx-auto" placeholder="Имя">
            </div>
            <div class="col-md-10">
              <div class="row">
                <div class="col-md-3">
                  <input type="text" name="changefname" id="changefname" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="Отчество">
                  <input type="text" name="changephone" id="changephone" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="Телефон" maxlength="12">
                </div>
                <div class="col-md-3">
                  <input type="text" name="changelogin" id="changelogin" class="mt-3  w-100 mx-auto form-control" placeholder="login">
                  <input type="text" name="changepassword" id="changepassword" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="password">
                </div>
                <div class="col-md-3">
                  <input type="text" name="changepassser" id="changepassser" class="mt-3 mb-3 w-100 mx-auto form-control" placeholder="Серия паспорта" maxlength="4">
                  <input type="text" name="changepassnum" id="changepassnum" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="Номер паспорта" maxlength="6">
                </div>
                <div class="col-md-3">
                  <select class="form-select mt-3 mb-3" id="changedol" name="checkdol" placeholder="Добавить мастера">
                    <option value="0" selected>Должность</option>
                    <option value="Администратор" id="Администратор">Администратор</option>
                    <option value="Бухгалтер" id="Бухгалтер">Бухгалтер</option>
                    <option value="Работник склада" id="Работник склада">Работник склада</option>
                    <option value="Менеджер" id="Менеджер">Менеджер</option>
                    <option value="Мастер" id="Мастер">Мастер</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        </form>
        <form id="new_form">
          <div class="row">
            <h2 class="h4 fw-normal mb-3">Поиск/добавление заявки </h2>
              <div class="col-md-5">
                <input type="text" name="checkdate" id="checkdate" class="mt-3 mb-3 form-control w-100 mx-auto" placeholder="Дата" maxlength="19">
                <select class="form-select mt-3 mb-3" id="checkdol" name="checkdol" placeholder="Добавить статус">
                  <option value="0" selected>Статус</option>
                  <option value="Администратор" id="Администратор">Новая</option>
                  <option value="Бухгалтер" id="Бухгалтер">Оплачена</option>
                  <option value="Работник склада" id="Работник склада">В пути</option>
                  <option value="Менеджер" id="Менеджер">Прибыла</option>
                  <option value="Мастер" id="Мастер">Закрыта</option>
                </select>
              </div>
              <div class="form-group col-md-5 mt-3">
                <textarea class="form-control mb-3" id="checkdesc" rows="3" placeholder="Описание"></textarea>
              </div>

          </div>
        </form>
        <div class="shadow mt" id="table_employees">
            <?php require_once  '../tables/employees_table.php'?>
        </div>
      </div>
      <div class="col-md-2">
        <button type="button" id="reset_btn" class=" mb-2 w-100 mx-auto btn btn-outline-primary">Очистить фильтр</button>
        <button class="w-100 btn btn-lg btn-primary mt-3" id="new_save_btn" type="button">Сохранить</button>
        <button class="w-100 btn btn-lg btn-primary mt-3" id="new_back_btn" type="button">Назад</button>
        <button class="w-100 btn btn-lg btn-primary mt-3" id="change_save_btn" type="button">Сохранить</button>
        <button class="w-100 btn btn-lg btn-primary mt-3" id="change_back_btn" type="button">Назад</button>
        <div class="alert alert-primary alert-dismissible fade show mt-2 h-auto" id="change_successBlock" role="alert"></div>
        <div class="h-auto alert alert-danger mt-2 text-start" role="alert" id="change_errorBlock"></div>
        <button class="w-100 btn btn-lg btn-primary mt-3" id="new_btn" type="button">Добавить</button>
        <div class="alert alert-primary alert-dismissible fade show mt-2 h-auto" id="new_successBlock" role="alert"></div>
        <div class="h-auto alert alert-danger mt-2 text-start" role="alert" id="new_errorBlock"></div>
        <button class="w-100 btn btn-lg btn-primary mt-3" id="change_btn" type="button">Изменить</button>
        <div class="h-auto alert alert-danger mt-2 text-start" role="alert" id="change_errorBlock1"></div>
        <button class="w-100 btn btn-lg btn-primary mt-3" id="del_btn" type="button">Удалить</button>
        <div class="h-auto alert alert-danger mt-2 text-start" role="alert" id="delete_errorBlock"></div>
        <div class="alert alert-primary alert-dismissible fade show mt-2 h-auto" id="delete_successBlock" role="alert"></div>
      </div>
    </div>
  </main>
  <script>

    $('#reset_btn').click(function() {
      document.getElementById("new_form").reset();
      var checkdol = $('#checkdol').val();
      var checksurname = $('#checksurname').val();
      var checkname = $('#checkname').val();
      var checkfname = $('#checkfname').val();
      var checkphone = $('#checkphone').val();
      var checklogin = $('#checklogin').val();
      var checkpassword = $('#checkpassword').val();
      var checkpassser = $('#checkpassser').val();
      var checkpassnum = $('#checkpassnum').val();
      var employeeID = $('#checkemployeeID').val();
      var checkdate = $('#checkdate').val();

      $.ajax({
          type: "POST",
          url: "../ajax/find/find_employees.php",
          data: {'checksurname' : checksurname, 'checkname' : checkname, 'checkfname' : checkfname, 'checkphone' : checkphone,
          'checklogin' : checklogin, 'checkpassword' : checkpassword, 'checkpassser' : checkpassser, 'checkpassnum' : checkpassnum, 'employeeID' : employeeID, 'checkdate' : checkdate, 'checkdol' : checkdol},
          success: function(data) {
              $("#table_employees").html(data).show();
          }
      });
    });

    $('#checkphone').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9+]/)){
        return false;
      };
    })
    $('#checkname').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[a-zA-Z \\u0400-\\u04FF]/)){
        return false;
      };
    })
    $('#checksurname').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[a-zA-Z \\u0400-\\u04FF]/)){
        return false;
      };
    })
    $('#checkfname').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[a-zA-Z \\u0400-\\u04FF]/)){
        return false;
      };
    })
    $('#checkdate').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9-: ]/)){
        return false;
      };
    })
    $('#checkpassser').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9]/)){
        return false;
      };
    })
    $('#checkpassnum').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9]/)){
        return false;
      };
    })
    $('#checkemployeeID').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9]/)){
        return false;
      };
    })


    $('#changephone').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9+]/)){
        return false;
      };
    })
    $('#changename').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[a-zA-Z \\u0400-\\u04FF]/)){
        return false;
      };
    })
    $('#changesurname').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[a-zA-Z \\u0400-\\u04FF]/)){
        return false;
      };
    })
    $('#changefname').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[a-zA-Z \\u0400-\\u04FF]/)){
        return false;
      };
    })
    $('#changedate').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9-: ]/)){
        return false;
      };
    })
    $('#changepassser').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9]/)){
        return false;
      };
    })
    $('#changepassnum').on('keydown', function(e){
      if(e.key.length == 1 && e.key.match(/[^0-9]/)){
        return false;
      };
    })



    $("#checkdate").keyup(function() {
      var checkdol = $('#checkdol').val();
      var checksurname = $('#checksurname').val();
      var checkname = $('#checkname').val();
      var checkfname = $('#checkfname').val();
      var checkphone = $('#checkphone').val();
      var checklogin = $('#checklogin').val();
      var checkpassword = $('#checkpassword').val();
      var checkpassser = $('#checkpassser').val();
      var checkpassnum = $('#checkpassnum').val();
      var employeeID = $('#checkemployeeID').val();
      var checkdate = $('#checkdate').val();

      $.ajax({
          type: "POST",
          url: "../ajax/find/find_employees.php",
          data: {'checksurname' : checksurname, 'checkname' : checkname, 'checkfname' : checkfname, 'checkphone' : checkphone,
          'checklogin' : checklogin, 'checkpassword' : checkpassword, 'checkpassser' : checkpassser, 'checkpassnum' : checkpassnum, 'employeeID' : employeeID, 'checkdate' : checkdate, 'checkdol' : checkdol},
          success: function(data) {
              $('#table_employees').html(data);
          }
      });
    });
    $("#checksurname").keyup(function() {
      var checkdol = $('#checkdol').val();
      var checksurname = $('#checksurname').val();
      var checkname = $('#checkname').val();
      var checkfname = $('#checkfname').val();
      var checkphone = $('#checkphone').val();
      var checklogin = $('#checklogin').val();
      var checkpassword = $('#checkpassword').val();
      var checkpassser = $('#checkpassser').val();
      var checkpassnum = $('#checkpassnum').val();
      var employeeID = $('#checkemployeeID').val();
      var checkdate = $('#checkdate').val();

      $.ajax({
          type: "POST",
          url: "../ajax/find/find_employees.php",
          data: {'checksurname' : checksurname, 'checkname' : checkname, 'checkfname' : checkfname, 'checkphone' : checkphone,
          'checklogin' : checklogin, 'checkpassword' : checkpassword, 'checkpassser' : checkpassser, 'checkpassnum' : checkpassnum, 'employeeID' : employeeID, 'checkdate' : checkdate, 'checkdol' : checkdol},
          success: function(data) {
              $('#table_employees').html(data);
          }
      });
    });
    $("#checkname").keyup(function() {
      var checkdol = $('#checkdol').val();
      var checksurname = $('#checksurname').val();
      var checkname = $('#checkname').val();
      var checkfname = $('#checkfname').val();
      var checkphone = $('#checkphone').val();
      var checklogin = $('#checklogin').val();
      var checkpassword = $('#checkpassword').val();
      var checkpassser = $('#checkpassser').val();
      var checkpassnum = $('#checkpassnum').val();
      var employeeID = $('#checkemployeeID').val();
      var checkdate = $('#checkdate').val();
      $.ajax({
          type: "POST",
          url: "../ajax/find/find_employees.php",
          data: {'checksurname' : checksurname, 'checkname' : checkname, 'checkfname' : checkfname, 'checkphone' : checkphone,
          'checklogin' : checklogin, 'checkpassword' : checkpassword, 'checkpassser' : checkpassser, 'checkpassnum' : checkpassnum, 'employeeID' : employeeID, 'checkdate' : checkdate, 'checkdol' : checkdol},
          success: function(data) {
              $("#table_employees").html(data).show();
          }
      });
    });
    $("#checkfname").keyup(function() {
      var checkdol = $('#checkdol').val();
      var checksurname = $('#checksurname').val();
      var checkname = $('#checkname').val();
      var checkfname = $('#checkfname').val();
      var checkphone = $('#checkphone').val();
      var checklogin = $('#checklogin').val();
      var checkpassword = $('#checkpassword').val();
      var checkpassser = $('#checkpassser').val();
      var checkpassnum = $('#checkpassnum').val();
      var employeeID = $('#checkemployeeID').val();
      var checkdate = $('#checkdate').val();

      $.ajax({
          type: "POST",
          url: "../ajax/find/find_employees.php",
          data: {'checksurname' : checksurname, 'checkname' : checkname, 'checkfname' : checkfname, 'checkphone' : checkphone,
          'checklogin' : checklogin, 'checkpassword' : checkpassword, 'checkpassser' : checkpassser, 'checkpassnum' : checkpassnum, 'employeeID' : employeeID, 'checkdate' : checkdate, 'checkdol' : checkdol},
          success: function(data) {
              $("#table_employees").html(data).show();
          }
      });
    });
    $("#checkphone").keyup(function() {
      var checkdol = $('#checkdol').val();
      var checksurname = $('#checksurname').val();
      var checkname = $('#checkname').val();
      var checkfname = $('#checkfname').val();
      var checkphone = $('#checkphone').val();
      var checklogin = $('#checklogin').val();
      var checkpassword = $('#checkpassword').val();
      var checkpassser = $('#checkpassser').val();
      var checkpassnum = $('#checkpassnum').val();
      var employeeID = $('#checkemployeeID').val();
      var checkdate = $('#checkdate').val();

      $.ajax({
          type: "POST",
          url: "../ajax/find/find_employees.php",
          data: {'checksurname' : checksurname, 'checkname' : checkname, 'checkfname' : checkfname, 'checkphone' : checkphone,
          'checklogin' : checklogin, 'checkpassword' : checkpassword, 'checkpassser' : checkpassser, 'checkpassnum' : checkpassnum, 'employeeID' : employeeID, 'checkdate' : checkdate, 'checkdol' : checkdol},
          success: function(data) {
              $("#table_employees").html(data).show();
          }
      });
    });
    $("#checklogin").keyup(function(){
      var checkdol = $('#checkdol').val();
      var checksurname = $('#checksurname').val();
      var checkname = $('#checkname').val();
      var checkfname = $('#checkfname').val();
      var checkphone = $('#checkphone').val();
      var checklogin = $('#checklogin').val();
      var checkpassword = $('#checkpassword').val();
      var checkpassser = $('#checkpassser').val();
      var checkpassnum = $('#checkpassnum').val();
      var employeeID = $('#checkemployeeID').val();
      var checkdate = $('#checkdate').val();

      $.ajax({
          type: "POST",
          url: "../ajax/find/find_employees.php",
          data: {'checksurname' : checksurname, 'checkname' : checkname, 'checkfname' : checkfname, 'checkphone' : checkphone,
          'checklogin' : checklogin, 'checkpassword' : checkpassword, 'checkpassser' : checkpassser, 'checkpassnum' : checkpassnum, 'employeeID' : employeeID, 'checkdate' : checkdate, 'checkdol' : checkdol},
          success: function(data) {
              $("#table_employees").html(data).show();
          }
      });
    });
    $("#checkpassword").keyup(function(){
      var checkdol = $('#checkdol').val();
      var checksurname = $('#checksurname').val();
      var checkname = $('#checkname').val();
      var checkfname = $('#checkfname').val();
      var checkphone = $('#checkphone').val();
      var checklogin = $('#checklogin').val();
      var checkpassword = $('#checkpassword').val();
      var checkpassser = $('#checkpassser').val();
      var checkpassnum = $('#checkpassnum').val();
      var employeeID = $('#checkemployeeID').val();
      var checkdate = $('#checkdate').val();

      $.ajax({
          type: "POST",
          url: "../ajax/find/find_employees.php",
          data: {'checksurname' : checksurname, 'checkname' : checkname, 'checkfname' : checkfname, 'checkphone' : checkphone,
          'checklogin' : checklogin, 'checkpassword' : checkpassword, 'checkpassser' : checkpassser, 'checkpassnum' : checkpassnum, 'employeeID' : employeeID, 'checkdate' : checkdate, 'checkdol' : checkdol},
          success: function(data) {
              $("#table_employees").html(data).show();
          }
      });
    });
    $("#checkpassser").keyup(function(){
      var checkdol = $('#checkdol').val();
      var checksurname = $('#checksurname').val();
      var checkname = $('#checkname').val();
      var checkfname = $('#checkfname').val();
      var checkphone = $('#checkphone').val();
      var checklogin = $('#checklogin').val();
      var checkpassword = $('#checkpassword').val();
      var checkpassser = $('#checkpassser').val();
      var checkpassnum = $('#checkpassnum').val();
      var employeeID = $('#checkemployeeID').val();
      var checkdate = $('#checkdate').val();

      $.ajax({
          type: "POST",
          url: "../ajax/find/find_employees.php",
          data: {'checksurname' : checksurname, 'checkname' : checkname, 'checkfname' : checkfname, 'checkphone' : checkphone,
          'checklogin' : checklogin, 'checkpassword' : checkpassword, 'checkpassser' : checkpassser, 'checkpassnum' : checkpassnum, 'employeeID' : employeeID, 'checkdate' : checkdate, 'checkdol' : checkdol},
          success: function(data) {
              $("#table_employees").html(data).show();
          }
      });
    });
    $("#checkpassnum").keyup(function(){
      var checkdol = $('#checkdol').val();
      var checksurname = $('#checksurname').val();
      var checkname = $('#checkname').val();
      var checkfname = $('#checkfname').val();
      var checkphone = $('#checkphone').val();
      var checklogin = $('#checklogin').val();
      var checkpassword = $('#checkpassword').val();
      var checkpassser = $('#checkpassser').val();
      var checkpassnum = $('#checkpassnum').val();
      var employeeID = $('#checkemployeeID').val();
      var checkdate = $('#checkdate').val();

      $.ajax({
          type: "POST",
          url: "../ajax/find/find_employees.php",
          data: {'checksurname' : checksurname, 'checkname' : checkname, 'checkfname' : checkfname, 'checkphone' : checkphone,
          'checklogin' : checklogin, 'checkpassword' : checkpassword, 'checkpassser' : checkpassser, 'checkpassnum' : checkpassnum, 'employeeID' : employeeID, 'checkdate' : checkdate, 'checkdol' : checkdol},
          success: function(data) {
              $("#table_employees").html(data).show();
          }
      });
    });
    $("#checkemployeeID").keyup(function(){
      var checkdol = $('#checkdol').val();
      var checksurname = $('#checksurname').val();
      var checkname = $('#checkname').val();
      var checkfname = $('#checkfname').val();
      var checkphone = $('#checkphone').val();
      var checklogin = $('#checklogin').val();
      var checkpassword = $('#checkpassword').val();
      var checkpassser = $('#checkpassser').val();
      var checkpassnum = $('#checkpassnum').val();
      var employeeID = $('#checkemployeeID').val();
      var checkdate = $('#checkdate').val();

      $.ajax({
          type: "POST",
          url: "../ajax/find/find_employees.php",
          data: {'checksurname' : checksurname, 'checkname' : checkname, 'checkfname' : checkfname, 'checkphone' : checkphone,
          'checklogin' : checklogin, 'checkpassword' : checkpassword, 'checkpassser' : checkpassser, 'checkpassnum' : checkpassnum, 'employeeID' : employeeID, 'checkdate' : checkdate, 'checkdol' : checkdol},
          success: function(data) {
              $("#table_employees").html(data).show();
          }
      });
    });
    $("#checkdol").change(function(){
      var checkdol = $('#checkdol').val();
      var checksurname = $('#checksurname').val();
      var checkname = $('#checkname').val();
      var checkfname = $('#checkfname').val();
      var checkphone = $('#checkphone').val();
      var checklogin = $('#checklogin').val();
      var checkpassword = $('#checkpassword').val();
      var checkpassser = $('#checkpassser').val();
      var checkpassnum = $('#checkpassnum').val();
      var employeeID = $('#checkemployeeID').val();
      var checkdate = $('#checkdate').val();

      $.ajax({
          type: "POST",
          url: "../ajax/find/find_employees.php",
          data: {'checksurname' : checksurname, 'checkname' : checkname, 'checkfname' : checkfname, 'checkphone' : checkphone,
          'checklogin' : checklogin, 'checkpassword' : checkpassword, 'checkpassser' : checkpassser, 'checkpassnum' : checkpassnum, 'employeeID' : employeeID, 'checkdate' : checkdate, 'checkdol' : checkdol},
          success: function(data) {
              $("#table_employees").html(data).show();
          }
      });
    });

    $('#exit_btn').click(function () {
      $.ajax({
        url: '../ajax/exit.php',
        type: 'POST',
        cache: false,
        data: {},
        dataType: 'html',
        success: function (data) {
          document.location.reload(true);
        }
      });
    });

    $('#new_btn').click(function () {
      var checkdol = $('#checkdol').val();
      var checksurname = $('#checksurname').val();
      var checkname = $('#checkname').val();
      var checkfname = $('#checkfname').val();
      var checkphone = $('#checkphone').val();
      var checklogin = $('#checklogin').val();
      var checkpassword = $('#checkpassword').val();
      var checkpassser = $('#checkpassser').val();
      var checkpassnum = $('#checkpassnum').val();
      var employeeID = $('#checkemployeeID').val();
      var checkdate = $('#checkdate').val();

      $.ajax({
          type: "POST",
          url: "../ajax/new/new_employees.php",
          data: {'checksurname' : checksurname, 'checkname' : checkname, 'checkfname' : checkfname, 'checkphone' : checkphone,
          'checklogin' : checklogin, 'checkpassword' : checkpassword, 'checkpassser' : checkpassser, 'checkpassnum' : checkpassnum, 'employeeID' : employeeID, 'checkdate' : checkdate, 'checkdol' : checkdol},
          success: function(data) {
            if (data == 'Все готово') {
              document.getElementById("new_form").reset();
              $('#new_errorBlock').hide();
              $('#new_successBlock').text("Сотрудник успешно добавлен!").show();
              $(function(){
                 $("#new_successBlock").delay(3000).slideUp(300);
              });
              $.ajax({
                  type: "POST",
                  url: "../tables/employees_table.php",
                  data: { },
                  success: function(result) {
                      $("#table_employees").html(result).show();
                  }
              });
            }
            else {
              $("#new_errorBlock").html(data).show();
              $(function(){
                 $("#new_errorBlock").delay(3000).slideUp(300);
              });
            }
          }
      });
    });

    $('#change_btn').click(function() {
      $.ajax({
          type: "POST",
          url: "../ajax/find_cookies/cookies_employees.php",
          data: { },
          success: function(data) {
              if (data == "cookie сотрудника найдены") {
                $('#new_form').hide();
                $('#new_btn').hide();
                $('#change_btn').hide();
                $('#del_btn').hide();
                $('#reset_btn').hide();
                $('#change_form').show();
                $('#change_save_btn').show();
                $('#change_back_btn').show();
              }
              else {
                $('#change_errorBlock1').show();
                $(function(){
                   $("#change_errorBlock1").delay(5000).slideUp(300);
                 });
                $('#change_errorBlock1').text(data);
              }
          }
      });
    });
    $('#change_back_btn').click(function() {
      $('#new_form').show();
      $('#new_btn').show();
      $('#change_btn').show();
      $('#del_btn').show();
      $('#reset_btn').show();
      $('#change_form').hide();
      $('#change_save_btn').hide();
      $('#change_back_btn').hide();
    });
    $('#change_save_btn').click(function() {
      var changedol = $('#changedol').val();
      var changesurname = $('#changesurname').val();
      var changename = $('#changename').val();
      var changefname = $('#changefname').val();
      var changephone = $('#changephone').val();
      var changelogin = $('#changelogin').val();
      var changepassword = $('#changepassword').val();
      var changepassser = $('#changepassser').val();
      var changepassnum = $('#changepassnum').val();

      $.ajax({
          type: "POST",
          url: "../ajax/change/change_employees.php",
          data: {'changesurname' : changesurname, 'changename' : changename, 'changefname' : changefname, 'changephone' : changephone,
          'changelogin' : changelogin, 'changepassword' : changepassword, 'changepassser' : changepassser, 'changepassnum' : changepassnum,  'changedol' : changedol},
          success: function(data) {
            if (data == 'Все готово') {
              document.getElementById("new_form").reset();
              $('#change_errorBlock').hide();
              $('#change_successBlock').text("Данные сотрудника уcпешно обновленны").show();
              $(function(){
                 $("#change_successBlock").delay(3000).slideUp(300);
              });
              $.ajax({
                  type: "POST",
                  url: "../tables/employees_table.php",
                  data: { },
                  success: function(result) {
                      $("#table_employees").html(result).show();
                  }
              });
              $('#new_form').show();
              $('#new_btn').show();
              $('#change_btn').show();
              $('#del_btn').show();
              $('#reset_btn').show();
              $('#change_form').hide();
              $('#change_save_btn').hide();
              $('#change_back_btn').hide();
            }
            else {
              $("#change_errorBlock").html(data).show();
            }
          }
      });
    });
    $('#del_btn').click(function() {
      $.ajax({
          type: "POST",
          url: "../ajax/delete/delete_employees.php",
          data: {},
          success: function(result) {
              if (result == 'Все готово') {
                document.getElementById("new_form").reset();
                $('#delete_errorBlock').hide();
                $('#delete_successBlock').text("Сотрудник успешно удален").show();
                $(function(){
    	             $("#delete_successBlock").delay(3000).slideUp(300);
                });
                $.ajax({
                    type: "POST",
                    url: "../tables/employees_table.php",
                    data: { },
                    success: function(result) {
                        $("#table_employees").html(result).show();
                    }
                });
              }
              else {
                $('#delete_errorBlock').show();
                $(function(){
                   $("#delete_errorBlock").delay(5000).slideUp(300);
                 });
                $('#delete_errorBlock').text(result);
              }
          }
      });
    })
  </script>
</body>
</html>
