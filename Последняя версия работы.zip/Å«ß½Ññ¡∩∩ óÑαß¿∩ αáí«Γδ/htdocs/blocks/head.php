<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="/css/bootstrap.min.css">
<link rel="icon" href="/img/favicon.ico">
<link rel="stylesheet" href="../css/sstyle.css">
<title><?=$website_title?></title>

<script type="text/javascript" src="../css/jquery-3.6.0.min.js"></script>
<link rel="stylesheet" href="../chosen/chosen.min.css">
<script src="../chosen/chosen.jquery.min.js"></script>
<?php date_default_timezone_set("Europe/Moscow")  ?>
