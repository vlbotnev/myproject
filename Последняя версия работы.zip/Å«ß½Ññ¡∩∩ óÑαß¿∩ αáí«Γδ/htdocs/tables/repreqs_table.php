<?php
  require_once '../mysql_connect.php';
  $vis = 1;
  try {
  $sql = 'SELECT  mas.Сотрудники_Фамилия AS master_surname,
                  man.Сотрудники_Фамилия AS manager_surname,
                  запрос_на_ремонт.Запрос_На_РемонтID,
                  запрос_на_ремонт.АвтомобильID,
                  запрос_на_ремонт.Дата, статус.Название,
                  запрос_на_ремонт.Описание_Крктк FROM запрос_на_ремонт
                  INNER JOIN статус ON запрос_на_ремонт.СтатусID = статус.СтатусID
                  INNER JOIN сотрудники AS man ON man.СотрудникID = запрос_на_ремонт.СотрудникID_Менеджер
                  INNER JOIN сотрудники AS mas ON mas.СотрудникID = запрос_на_ремонт.СотрудникID_Мастер
                  WHERE запрос_на_ремонт.Видимость = 1
                  ORDER BY `запрос_на_ремонт`.`Запрос_На_РемонтID` DESC';
  $query = $pdo->prepare($sql);
  $query->execute(['vis' => $vis]);
}
  catch(PDOException $e){
        $return = "Your fail message: " . $e->getMessage();
        echo $return;
        exit();
  }
  $users = $query->fetchALL(PDO::FETCH_ASSOC);

  /*$sql = 'SELECT * FROM сотрудники WHERE сотрудники.СотрудникID = :masterID || сотрудники.СотрудникID = :managerID ORDER BY `сотрудники`.`Должность` ASC';
  $query = $pdo->prepare($sql);*/



  setcookie('Запрос_На_РемонтID', null, 1 , "/");
  if (count($users) == 0) {
    echo '<div class="scrollspy mb-3">
          <table class="text-center table table-striped" >
            <thead>
              <tr>
              <th>#</th>
              <th>АвтоID</th>
              <th>Дата</th>
              <th>Стоимость</th>
              <th>Статус</th>
              <th>Описание краткое</th>
              <th>Мастер</th>
              <th>Менеджер</th>
              </tr>
            </thead>
            <tbody></table></div>';
    echo "заявка не найдена";
  }
  else {
    echo '<div class="scrollspy mb-3">
          <table class="text-center table table-striped" >
            <thead>
              <tr>
              <th>#</th>
              <th>АвтоID</th>
              <th>Дата</th>
              <th>Стоимость</th>
              <th>Статус</th>
              <th>Описание краткое</th>
              <th>Мастер</th>
              <th>Менеджер</th>
              </tr>
            </thead>
            <tbody>';
    foreach ($users as $user) {
      try {
      $sql = 'SELECT SUM(`склад`.`Цена_Продажи`) AS pieces FROM запрос_на_ремонт
              INNER JOIN запчасти_для_ремонта ON запчасти_для_ремонта.Запрос_На_РемонтID = запрос_на_ремонт.Запрос_На_РемонтID
              INNER JOIN склад ON склад.ЗапчастьID = запчасти_для_ремонта.ЗапчастьID
              WHERE запрос_на_ремонт.Видимость = 1 && запрос_на_ремонт.Запрос_На_РемонтID = :id';
      $query = $pdo->prepare($sql);
      $query->execute(['id' => $user['Запрос_На_РемонтID']]);
      $pieces = $query->fetch(PDO::FETCH_ASSOC);
      }
      catch(PDOException $e){
            $return = "Your fail message: " . $e->getMessage();
            echo $return;
            exit();
      }
      try {
      $sql = 'SELECT SUM(`прайс_лист_работ`.`Цена продажи`) AS works FROM запрос_на_ремонт
              INNER JOIN работы_по_ремонту ON работы_по_ремонту.Запрос_На_РемонтID = запрос_на_ремонт.Запрос_На_РемонтID
              INNER JOIN прайс_лист_работ ON прайс_лист_работ.РаботаID = работы_по_ремонту.РаботаID
              WHERE запрос_на_ремонт.Видимость = "1" && запрос_на_ремонт.Запрос_На_РемонтID = :id  ';
      $query = $pdo->prepare($sql);
      $query->execute(['id' => $user['Запрос_На_РемонтID']]);
      $works = $query->fetch(PDO::FETCH_ASSOC);
      }
      catch(PDOException $e){
            $return = "Your fail message: " . $e->getMessage();
            echo $return;
            exit();
      }
      $intworks = (int)$works['works'];
      echo '<tr>
              <td>' . $user['Запрос_На_РемонтID'] . '</td>
              <td>' . $user['АвтомобильID'] . '</td>
              <td>' . $user['Дата'] . '</td>
              <td>' . ($works['works'] + $pieces['pieces']) . '</td>
              <td>' . $user['Название'] . '</td>
              <td>' . $user['Описание_Крктк'] . '</td>
              <td>' . $user['master_surname'] . '</td>
              <td>' . $user['manager_surname'] . '</td>';
            echo '</tr>';
    }
    echo '</tbody></table></div>';
  }
?>
