<?php
  require_once '../mysql_connect.php';

  $vis = 1;
  $dol = 'Мастер';
  $sql = 'SELECT * FROM `сотрудники` WHERE `Видимость` = :vis && `Должность` = :dol';
  $query = $pdo->prepare($sql);
  $query->execute(['vis' => $vis, 'dol' => $dol]);
  $users = $query->fetchALL(PDO::FETCH_ASSOC);
  foreach ($users as $user) {
    echo '<option value="' . $user['СотрудникID'] .'">'. $user['Сотрудники_Фамилия'] .'</option>';
  }
?>
