<?php
  require_once '../mysql_connect.php';
  $vis = 1;
  $sql = 'SELECT * FROM `машины` WHERE `Видимость` = :vis ORDER BY машины.АвтомобильID DESC';
  $query = $pdo->prepare($sql);
  $query->execute(['vis' => $vis]);
  $users = $query->fetchALL(PDO::FETCH_ASSOC);
  setcookie('АвтомобильID', $user['АвтомобильID'], time() - 3600 * 24, "/");
  if (count($users) == 0) {
    echo '<div class="scrollspy">
          <table class="text-center table table-striped " >
            <thead>
              <tr class="align-top">
              <th>АвтоID</th>
              <th>КлиентID</th>
              <th>Дата</th>
              <th>VIN</th>
              <th>НомерТС</th>
              <th>Марка</th>
              <th>Модель</th>
              <th>Год выпуска</th>
              <th>Серия СТС</th>
              <th>Номер СТС</th>
              </tr>
            </thead>
            <tbody>';
            echo '</tbody></table></div>';
    echo "Автомобиль не найден";

  }
  else {
    echo '<div class="scrollspy">
          <table class="text-center table table-striped " >
            <thead>
              <tr class="align-top">
              <th>АвтоID</th>
              <th>КлиентID</th>
              <th>Дата</th>
              <th>VIN</th>
              <th>НомерТС</th>
              <th>Марка</th>
              <th>Модель</th>
              <th>Год выпуска</th>
              <th>Серия СТС</th>
              <th>Номер СТС</th>
              </tr>
            </thead>
            <tbody>';
    foreach ($users as $user) {
      echo '<tr class="align-top">
              <td>' . $user['АвтомобильID'] . '</td>
              <td>' . $user['КлиентID'] . '</td>
              <td>' . $user['Дата'] . '</td>
              <td>' . $user['VIN'] . '</td>
              <td>' . $user['НомерТС'] . '</td>
              <td>' . $user['Марка'] . '</td>
              <td>' . $user['Модель'] . '</td>
              <td>' . $user['Год_Выпуска'] . '</td>
              <td>' . $user['Серия_СТС'] . '</td>
              <td>' . $user['Номер_СТС'] . '</td>
            </tr>';
    }
    echo '</tbody></table></div>';
  }
?>
