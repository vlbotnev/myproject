<?php
  require_once '../mysql_connect.php';

  $vis = 0;
  $sql = 'SELECT * FROM `склад` WHERE `Количество` != :vis';
  $query = $pdo->prepare($sql);
  $query->execute(['vis' => $vis]);
  $users = $query->fetchALL(PDO::FETCH_ASSOC);
  foreach ($users as $user) {
    echo '<option value="' . $user['ЗапчастьID'] .'">'. $user['Название'] .'</option>';
  }
?>
