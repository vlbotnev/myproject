<?php
require_once '../mysql_connect.php';

$id = $_COOKIE['Запрос_На_РемонтID'];


$sql = 'SELECT * FROM работы_по_ремонту
        INNER JOIN прайс_лист_работ ON прайс_лист_работ.РаботаID = работы_по_ремонту.РаботаID
        WHERE работы_по_ремонту.Запрос_На_РемонтID = :id';
$query = $pdo->prepare($sql);
$query->execute(['id' => $id]);
$users = $query->fetchALL(PDO::FETCH_ASSOC);
foreach ($users as $user) {
  echo 'Название: ' . $user['Название'] . '</br>';
}
?>
