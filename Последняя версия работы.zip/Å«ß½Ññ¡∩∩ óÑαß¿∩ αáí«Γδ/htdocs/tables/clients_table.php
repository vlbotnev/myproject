<?php
  require_once '../mysql_connect.php';
  $vis = 1;
  $sql = 'SELECT * FROM `клиенты` WHERE `Видимость` = :vis ORDER BY `клиенты`.`КлиентID` DESC';
  $query = $pdo->prepare($sql);
  $query->execute(['vis' => $vis]);
  $users = $query->fetchALL(PDO::FETCH_ASSOC);
  setcookie('КлиентID', $users['КлиентID'], time() - 3600 * 24, "/");
  if (count($users) == 0) {
    echo '<div class="scrollspy">
          <table class="text-center table table-striped " >
            <thead>
              <tr class="align-top">
              <th>КлиентID</th>
              <th>Фамилия</th>
              <th>Имя</th>
              <th>Отчество</th>
              <th>Телефон</th>
              <th>Дата</th>
              </tr>
            </thead>
            <tbody>';
            echo '</tbody></table></div>';
    echo "Клиент не найден";
  }
  else {
    echo '<div class="scrollspy">
          <table class="text-center table table-striped " >
            <thead>
            <tr class="align-top">
            <th>КлиентID</th>
            <th>Фамилия</th>
            <th>Имя</th>
            <th>Отчество</th>
            <th>Телефон</th>
            <th>Дата</th>
            </tr>
            </thead>
            <tbody>';
    foreach ($users as $user) {
      echo '<tr>
              <td>' . $user['КлиентID'] . '</td>
              <td>' . $user['Фамилия'] . '</td>
              <td>' . $user['Имя'] . '</td>
              <td>' . $user['Отчество'] . '</td>
              <td>' . $user['Телефон'] . '</td>
              <td>' . $user['Дата'] . '</td>
            </tr>';
    }
    echo '</tbody></table></div>';
  }
?>
