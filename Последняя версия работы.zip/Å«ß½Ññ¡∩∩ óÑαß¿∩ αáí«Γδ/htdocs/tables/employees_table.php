<?php
  require_once '../mysql_connect.php';
  $vis = 1;
  $sql = 'SELECT * FROM `сотрудники` WHERE `Видимость` = :vis ORDER BY `сотрудники`.`СотрудникID` DESC';
  $query = $pdo->prepare($sql);
  $query->execute(['vis' => $vis]);
  $users = $query->fetchALL(PDO::FETCH_ASSOC);
  setcookie('СотрудникID_check', $users['СотрудникID'], time() - 3600 * 24, "/");
  if (count($users) == 0) {
    echo '<div class="scrollspy">
          <table class="text-center table table-striped " >
            <thead>
              <tr class="align-top>
              <th>#</th>
              <th>Фамилия</th>
              <th>Имя</th>
              <th>Отчество</th>
              <th>Телефон</th>
              <th>login</th>
              <th>password</th>
              <th>Серия паспорта</th>
              <th>Номер паспорта</th>
              <th>Должность</th>
              </tr>
            </thead>
            <tbody>';
            echo '</tbody></table></div>';
    echo "Сотрудник не найден";

  }
  else {
    echo '<div class="scrollspy">
          <table class="text-center table table-striped " >
            <thead>
            <tr class="align-top">
            <th>#</th>
            <th>Фамилия</th>
            <th>Имя</th>
            <th>Отчество</th>
            <th>Телефон</th>
            <th>login</th>
            <th>password</th>
            <th>Серия паспорта</th>
            <th>Номер паспорта</th>
            <th>Должность</th>
            </tr>
            </thead>
            <tbody>';
    foreach ($users as $user) {
      echo '<tr>
      <td>' . $user['СотрудникID'] . '</td>
              <td>' . $user['Сотрудники_Фамилия'] . '</td>
              <td>' . $user['Имя'] . '</td>
              <td>' . $user['Отчество'] . '</td>
              <td>' . $user['Телефон'] . '</td>
              <td>' . $user['login'] . '</td>
              <td>' . $user['password'] . '</td>
              <td>' . $user['Серия_Паспорта'] . '</td>
              <td>' . $user['Номер_Паспорта'] . '</td>
              <td>' . $user['Должность'] . '</td>
            </tr>';
    }
    echo '</tbody></table></div>';
  }
?>
